<?php
session_start();
include('../gms/connection/connection.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emaill = $_POST['email'];
    $passwordd = $_POST['passwordd'];

    // Query the database to check credentials
    $sql = "SELECT * FROM users WHERE email='$emaill' AND psswd='$passwordd'";
    $result = $conn->query($sql);

    if (!$result) {
        die("Error executing query: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        // Login successful
        $user_id = $result->fetch_assoc()['user_id'];
        $_SESSION['user_id'] = $user_id;
        $_SESSION['email'] = $emaill;

        // Initialize the role as empty
        $role = "";

        // Check user role
        $check_member = $conn->query("SELECT * FROM member WHERE user_id='$user_id'");
        $check_instructor = $conn->query("SELECT * FROM instructor WHERE user_id='$user_id'");
        $check_admin_staff = $conn->query("SELECT * FROM admin_staff WHERE user_id='$user_id'");

        if ($check_member->num_rows > 0) {
            $role = "member";
        } elseif ($check_instructor->num_rows > 0) {
            $role = "instructor";
        } elseif ($check_admin_staff->num_rows > 0) {
            $admin_staff_role = $check_admin_staff->fetch_assoc()['role'];
            if ($admin_staff_role == 'Admin') {
                $role = "admin";
            } else {
                $role = "staff";
            }
        }

        // Redirect based on role
        if ($role == "member") {
            $redirect_url = "member_dashboard.php";
        } elseif ($role == "instructor") {
            $redirect_url = "instructor_dashboard.php";
        } elseif ($role == "admin") {
            $redirect_url = "admin_dashboard.php";
        } else {
            $redirect_url = "home.php";
        }

        $success_message = "Login successful! Redirecting...";
        echo '<script type="text/javascript">
            setTimeout(function() {
                window.location.href = "' . $redirect_url . '";
            }, 2000);
        </script>';
    } else {
        // Login failed
        $error_message = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Gym Template">
    <meta name="keywords" content="Gym, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>The Fitness Factory</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,600,700&display=swap" rel="stylesheet">

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/barfiller.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <!--Custom Styles-->
    <style>
        body {
            background: url('img/hero/hero-1.jpg') no-repeat center center/cover;
        }

        .login-container {
            background: rgba(0, 0, 0, 0.8);
            padding: 40px;
            border-radius: 10px;
            max-width: 450px;
            margin: auto;
        }

        .btn-custom {
            background: #ff6b00;
            border: none;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
            width: 100%;
            color: white;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background: #e65c00;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .social-icons a {
            color: white;
            font-size: 20px;
            margin-right: 10px;
            transition: 0.3s;
        }

        .social-icons a:hover {
            color: #ff6b00;
        }
    </style>

</head>

<body>
    <!-- Login Form Section -->
    <section class="d-flex align-items-center vh-100">
        <div class="container">
            <div class="login-container text-center">
                <h2 class="mb-4 text-warning">LOGIN</h2>

                <?php
                if (isset($success_message)) {
                    echo '<div class="alert alert-success">' . $success_message . '</div>';
                }

                if (isset($error_message)) {
                    echo '<div class="alert alert-danger">' . $error_message . '</div>';
                }

                if (isset($_GET['error'])) {
                    echo '<div class="alert alert-danger">'.htmlspecialchars($_GET['error']).'</div>';
                }
                ?>

                <form action="" method="POST">
                    <div class="mb-3">
                        <input type="email" name="email" class="form-control py-3" placeholder="Email Address" required>
                    </div>
                    <div class="mb-3">
                        <input type="password" name="passwordd" class="form-control py-3" placeholder="Password" required>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <input type="checkbox" id="remember-me">
                            <label for="remember-me" class="small">Remember me</label>
                        </div>
                        <a href="#" class="small text-white">Forgot Password?</a>
                    </div>

                    <button type="submit" class="btn-custom">Login</button>

                    <p class="mt-3">Don't have an account? <a href="register.php" class="text-warning">Sign Up</a></p>
                </form>

            </div>
        </div>
    </section>

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/masonry.pkgd.min.js"></script>
    <script src="js/jquery.barfiller.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>
