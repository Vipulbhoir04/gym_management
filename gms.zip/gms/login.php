<?php
session_start();
include 'connection/connection.php';

$error = "";

// Check if user is already logged in via cookies
if (!isset($_SESSION["user_id"]) && isset($_COOKIE["login_token"])) {
    $token = $_COOKIE["login_token"];
    $query = "SELECT * FROM users WHERE login_token = ? AND token_expiry > NOW() AND is_logged_in = TRUE";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION["user_id"] = $user["user_id"];
        $_SESSION["username"] = $user["username"];
        header("Location: dashboard.php");
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    $remember = isset($_POST["remember"]);

    if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        $error = "❌ Password must be at least 8 characters long and contain both letters and numbers.";
    } else {
        $query = "SELECT * FROM users WHERE email = ? AND is_logged_in = FALSE";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            if (isset($user['psswd']) && $user['psswd'] === $password) {
                $_SESSION["user_id"] = $user["user_id"];
                $_SESSION["username"] = $user["username"];
                $user_id = $user["user_id"];

                // Set user as logged in
                $conn->query("UPDATE users SET is_logged_in = TRUE WHERE user_id = '$user_id'");

                // Generate a unique token
                $token = bin2hex(random_bytes(32));
                $expiry = date("Y-m-d H:i:s", strtotime("+30 days"));

                if ($remember) {
                    setcookie("login_token", $token, time() + (30 * 24 * 60 * 60), "/");
                    $conn->query("UPDATE users SET login_token='$token', token_expiry='$expiry' WHERE user_id='$user_id'");
                } else {
                    setcookie("login_token", "", time() - 3600, "/"); // Remove cookie if not remembered
                }

                // Redirect based on role
                $role_query = [
                    "SELECT * FROM member WHERE user_id = ?" => "member_dashboard.php",
                    "SELECT * FROM instructor WHERE user_id = ?" => "instructor_dashboard.php",
                    "SELECT * FROM admin_staff WHERE user_id = ? AND role = 'Admin'" => "admin/admin_dashboard.php",
                    "SELECT * FROM admin_staff WHERE user_id = ? AND role = 'Staff'" => "home.php"
                ];

                foreach ($role_query as $sql => $redirect) {
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("s", $user_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    if ($result->num_rows > 0) {
                        header("Location: $redirect");
                        exit();
                    }
                }

                header("Location: home.php");
                exit();
            } else {
                $error = "Invalid email or password";
            }
        } else {
            $error = "User already logged in";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        /* Background Image */
        body {
            background: url('img/hero/hero-1.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            position: relative;
            text-align: center;
        }

        /* Overlay Effect */
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: -1;
        }

        /* Background Animated Text */
        .animated-text {
            font-size: 3rem;
            font-weight: bold;
            color: rgba(255, 255, 255, 0.2);
            position: absolute;
            top: 8%;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
            animation: fadeInText 3s ease-in-out infinite alternate;
        }

        @keyframes fadeInText {
            0% {
                opacity: 0.3;
                transform: translateX(-50%) scale(1);
            }

            100% {
                opacity: 0.7;
                transform: translateX(-50%) scale(1.05);
            }
        }

        @media (max-width: 768px) {
            .animated-text {
                font-size: 2rem;
                top: 5%;
            }
        }

        /* Input Fields with Icons */
        .input-container {
            position: relative;
            width: 300px;
        }

        .input-icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
        }

        .input-field {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid rgba(255, 255, 255, 0.5);
            background: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
            color: white;
            outline: none;
            transition: all 0.3s ease-in-out;
        }

        .input-field::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .input-field:focus {
            border-color: #ffffff;
            background: rgba(255, 255, 255, 0.3);
        }

        /* Password Eye Icon */
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: rgba(255, 255, 255, 0.7);
        }

        /* Button */
        .btn {
            width: 300px;
            padding: 10px;
            background: #3b82f6;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn:hover {
            background: #2563eb;
        }

        /* Links */
        .link {
            color: #3b82f6;
        }

        .link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="animated-text">Welcome Back</div>

    <h2 class="text-white text-3xl font-bold mb-6">Login</h2>

    <?php if (!empty($error)): ?>
        <div id="error-box" class="bg-red-100 border border-red-400 text-red-700 px-7 py-3 rounded relative mb-4">
            <strong class="font-bold"><?php echo $error; ?></strong>
            <button id="close-error" class="absolute top-1 right-0 mt-2 mr-2 text-red-700 font-bold">✖</button>
        </div>
    <?php endif; ?>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const closeBtn = document.getElementById("close-error");
            const errorBox = document.getElementById("error-box");

            if (closeBtn && errorBox) {
                closeBtn.addEventListener("click", function () {
                    errorBox.style.display = "none";
                });
            }
        });
    </script>


    <form action="" method="POST" class="space-y-4">
        <div class="input-container">
            <i class="fa-solid fa-envelope input-icon"></i>
            <input type="email" id="email" name="email" required class="input-field" placeholder="Email">
        </div>

        <div class="input-container">
            <i class="fa-solid fa-lock input-icon"></i>
            <input type="password" id="password" name="password" required class="input-field" placeholder="Password">
            <span id="togglePassword" class="password-toggle">
                <i id="eye-icon" class="fa-solid fa-eye"></i>
            </span>
        </div>
        <div>
            <input type="checkbox" id="remember" name="remember">
            <label for="remember" class="text-white">Remember Me</label>
        </div>

        <button type="submit" class="btn">Login</button>
    </form>

    <p class="mt-4">
        <a href="forgot_password.php" class="link">Forgot Password?</a>
    </p>
    <p class="text-white">
        Don't have an account? <a href="register.php" class="link">Sign up here.</a>
    </p>

    <script>
        document.getElementById("togglePassword").addEventListener("click", function () {
            let passwordField = document.getElementById("password");
            let eyeIcon = document.getElementById("eye-icon");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            }
        });
    </script>

</body>

</html>