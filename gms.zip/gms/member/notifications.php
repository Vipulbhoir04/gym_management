<?php
session_start();
include '../connection/connection.php';
include '../main/layout/sidebar2.php';

// Fetch notifications
$query = "SELECT * FROM notification ORDER BY date DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex">

<div class="ml-64 p-6 w-full">
    <h2 class="text-3xl font-bold text-gray-800 mb-6">📢 Notifications</h2>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <div class="space-y-4">
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="bg-white p-4 rounded-lg shadow-md border border-gray-300">
                    <p class="text-gray-700"><strong>Date:</strong> <?php echo date("F j, Y", strtotime($row['date'])); ?></p>
                    <p class="text-gray-900 mt-2"><?php echo nl2br(htmlspecialchars($row['notification'])); ?></p>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p class="text-gray-600">No notifications available.</p>
    <?php endif; ?>
</div>

</body>
</html>
