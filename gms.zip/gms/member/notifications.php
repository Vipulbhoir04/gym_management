<?php
session_start();
include '../connection/connection.php';
include '../main/layout/sidebar2.php';

// Fetch notifications
$query = "SELECT * FROM notification ORDER BY date DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex">

    <div class="w-full p-4 sm:p-6 md:ml-64">
        <h2 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-4 sm:mb-6 mt-10">📢 Notifications</h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="space-y-4">
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <div class="bg-white p-3 sm:p-4 rounded-lg shadow-md border border-gray-300">
                        <p class="text-gray-700 text-sm sm:text-base">
                            <strong>Date:</strong> <?php echo date("F j, Y", strtotime($row['date'])); ?>
                        </p>
                        <p class="text-gray-900 mt-1 sm:mt-2 text-sm sm:text-base">
                            <?php echo nl2br(htmlspecialchars($row['notification'])); ?>
                        </p>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-600 text-sm sm:text-base">No notifications available.</p>
        <?php endif; ?>
    </div>

</body>

</html>