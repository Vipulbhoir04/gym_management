<?php
session_start();
include '../connection/connection.php';
include '../main/layout/sidebar2.php';
date_default_timezone_set('Asia/Kolkata'); // ✅ Set Timezone

function generateAttendanceID($conn)
{
    $query = "SELECT a_id FROM attendance ORDER BY a_id DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $lastId = $row['a_id'];
        $num = (int) substr($lastId, 1) + 1;
        return 'A' . str_pad($num, 5, '0', STR_PAD_LEFT);
    } else {
        return 'A00001';
    }
}

if (!isset($_SESSION["m_id"])) {
    die("<script>Swal.fire('Error', 'Session expired. Please log in again.', 'error');</script>");
}

$m_id = $_SESSION["m_id"];
$date = date('Y-m-d');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    header('Content-Type: application/json'); // ✅ Ensure JSON response
    ob_clean(); // ✅ Clear any unwanted output

    if (isset($_POST['check_in'])) {
        $checkQuery = "SELECT * FROM attendance WHERE m_id = '$m_id' AND date = '$date'";
        $result = mysqli_query($conn, $checkQuery);

        if (mysqli_num_rows($result) > 0) {
            echo json_encode(["status" => "warning", "message" => "You have already checked in today."]);
            exit();
        } else {
            $a_id = generateAttendanceID($conn);
            $time = date('H:i:s');
            $insertQuery = "INSERT INTO attendance (a_id, date, check_in, m_id) VALUES ('$a_id', '$date', '$time', '$m_id')";

            if (mysqli_query($conn, $insertQuery)) {
                echo json_encode(["status" => "success", "message" => "Checked in successfully!"]);
                exit();
            } else {
                echo json_encode(["status" => "error", "message" => "Check-in failed: " . mysqli_error($conn)]);
                exit();
            }
        }
    }

    if (isset($_POST['check_out'])) {
        $checkQuery = "SELECT * FROM attendance WHERE m_id = '$m_id' AND date = '$date' AND check_in IS NOT NULL AND check_out IS NULL";
        $result = mysqli_query($conn, $checkQuery);

        if (mysqli_num_rows($result) > 0) {
            $time = date('H:i:s');
            $updateQuery = "UPDATE attendance SET check_out = '$time' WHERE m_id = '$m_id' AND date = '$date'";

            if (mysqli_query($conn, $updateQuery)) {
                echo json_encode(["status" => "success", "message" => "Checked out successfully!"]);
                exit();
            } else {
                echo json_encode(["status" => "error", "message" => "Check-out failed: " . mysqli_error($conn)]);
                exit();
            }
        } else {
            echo json_encode(["status" => "warning", "message" => "You must check in before checking out."]);
            exit();
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex justify-center items-center min-h-screen">

    <div class="ml-64 flex justify-center w-full mt-20"> <!-- Adjust for Sidebar Space -->
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-md text-center">
            <h2 class="text-2xl font-bold mb-5">Attendance</h2>
            <form method="POST" class="flex flex-col space-y-4">
                <button type="submit" name="check_in"
                    class="bg-green-500 text-white px-6 py-3 rounded-lg shadow-md hover:bg-green-700">Check In</button>
                <button type="submit" name="check_out"
                    class="bg-red-500 text-white px-6 py-3 rounded-lg shadow-md hover:bg-red-700">Check Out</button>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function () {
            $("button[name='check_in'], button[name='check_out']").click(function (e) {
                e.preventDefault();
                let action = $(this).attr("name");

                $.ajax({
                    type: "POST",
                    url: "", // Same PHP file
                    data: { [action]: true },
                    dataType: "json",
                    success: function (response) {
                        Swal.fire(response.status.toUpperCase(), response.message, response.status).then(() => {
                            if (response.status === "success") {
                                location.reload();
                            }
                        });
                    },
                    error: function (xhr, status, error) {
                        console.log("AJAX Error:", xhr.responseText); // ✅ Debugging
                        Swal.fire("Error", "Something went wrong. Check console for details.", "error");
                    }
                });
            });
        });
    </script>


</body>

</html>