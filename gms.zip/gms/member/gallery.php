<?php
session_start();
include '../connection/connection.php';
include '../main/layout/sidebar2.php';

// Fetch images from the gallery table
$query = "SELECT * FROM gallery ORDER BY img_id DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex">

    <div class="ml-64 p-6 w-full">
        <h2 class="text-3xl font-bold text-gray-800 mb-6">📸 Gallery</h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <div class="bg-white p-4 rounded-lg shadow-md border">
                        <div class="w-full h-64 overflow-hidden rounded-lg">
                            <img src="../<?php echo $row['image_path']; ?>" alt="<?php echo $row['image_name']; ?>" alt="Gallery Image"
                                class="w-full h-full object-cover">
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-600">No images available.</p>
        <?php endif; ?>
    </div>

</body>

</html>