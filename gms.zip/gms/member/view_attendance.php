<?php
session_start();
include '../connection/connection.php';
include '../main/layout/sidebar2.php';

if (!isset($_SESSION["m_id"])) {
    die("<script>Swal.fire('Error', 'Session expired. Please log in again.', 'error');</script>");
}

$m_id = $_SESSION["m_id"];
$query = "SELECT * FROM attendance WHERE m_id = '$m_id' ORDER BY date DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Attendance</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex justify-center items-center min-h-screen">

    <div class="ml-[260px] flex justify-center w-[calc(100%-260px)] mt-20">
        <div class="bg-white shadow-lg rounded-lg p-6 w-full max-w-3xl">
            <h2 class="text-2xl font-bold text-center mb-5">My Attendance</h2>

            <?php if (mysqli_num_rows($result) > 0) { ?>
                <table class="w-full border-collapse border border-gray-300">
                    <thead>
                        <tr class="bg-gray-200">
                            <th class="border border-gray-300 px-4 py-2">Date</th>
                            <th class="border border-gray-300 px-4 py-2">Check-In</th>
                            <th class="border border-gray-300 px-4 py-2">Check-Out</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr class="text-center">
                                <td class="border border-gray-300 px-4 py-2"><?= $row['date']; ?></td>
                                <td class="border border-gray-300 px-4 py-2"><?= $row['check_in'] ?? 'N/A'; ?></td>
                                <td class="border border-gray-300 px-4 py-2"><?= $row['check_out'] ?? 'N/A'; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } else { ?>
                <p class="text-center text-gray-500">No attendance records found.</p>
            <?php } ?>
        </div>
    </div>

</body>

</html>