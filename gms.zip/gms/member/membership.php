<?php
session_start();
include '../connection/connection.php';
include '../main/layout/sidebar2.php';

// Fetch memberships
$query = "SELECT * FROM membership ORDER BY price ASC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membership Plans</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex">

    <div class="w-full p-4 sm:p-6 mt-10 md:ml-64">
        <h2 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-4 sm:mb-6">🏋️ Membership Plans</h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <div class="bg-white p-4 sm:p-5 rounded-lg shadow-md border border-gray-300">
                        <h3 class="text-lg sm:text-xl font-bold text-blue-900"><?php echo htmlspecialchars($row['title']); ?>
                        </h3>
                        <p class="text-gray-700 text-sm sm:text-base"><strong>Type:</strong>
                            <?php echo htmlspecialchars($row['type']); ?></p>
                        <p class="text-gray-700 text-sm sm:text-base"><strong>Duration:</strong>
                            <?php echo $row['duration'] . ' ' . htmlspecialchars($row['duration_type']); ?>
                        </p>
                        <p class="text-gray-700 text-sm sm:text-base"><strong>Price:</strong>
                            $<?php echo number_format($row['price'], 2); ?></p>
                        <p class="text-gray-700 text-sm sm:text-base"><strong>Discount:</strong>
                            <?php echo $row['discount'] ? $row['discount'] . '%' : 'No Discount'; ?>
                        </p>
                        <p class="text-gray-600 text-xs sm:text-sm"><strong>Offer Validity:</strong>
                            <?php echo "Offer valid from " . htmlspecialchars($row['start_date']) . " to " . htmlspecialchars($row['end_date']); ?>
                        </p>
                        <p class="text-gray-600 mt-2 sm:mt-3 text-sm sm:text-base"><strong>Description:</strong>
                            <?php echo nl2br(htmlspecialchars($row['description'])); ?>
                        </p>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-600 text-sm sm:text-base">No memberships available.</p>
        <?php endif; ?>
    </div>

</body>

</html>