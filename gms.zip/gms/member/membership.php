<?php
session_start();
include '../connection/connection.php';
include '../main/layout/sidebar2.php';

// Fetch memberships
$query = "SELECT * FROM membership ORDER BY price ASC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membership Plans</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex">

    <div class="ml-64 p-6 w-full">
        <h2 class="text-3xl font-bold text-gray-800 mb-6">🏋️ Membership Plans</h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <div class="bg-white p-5 rounded-lg shadow-md border border-gray-300">
                        <h3 class="text-xl font-bold text-blue-900"><?php echo htmlspecialchars($row['title']); ?></h3>
                        <p class="text-gray-700"><strong>Type:</strong> <?php echo htmlspecialchars($row['type']); ?></p>
                        <p class="text-gray-700"><strong>Duration:</strong>
                            <?php echo $row['duration'] . ' ' . htmlspecialchars($row['duration_type']); ?>
                        </p>
                        <p class="text-gray-700"><strong>Price:</strong> $<?php echo number_format($row['price'], 2); ?></p>
                        <p class="text-gray-700"><strong>Discount:</strong>
                            <?php echo $row['discount'] ? $row['discount'] . '%' : 'No Discount'; ?></p>
                        <p class="text-gray-600"><strong>Offer Validity:</strong>
                            <?php echo "Offer valid from " . htmlspecialchars($row['start_date']) . " to " . htmlspecialchars($row['end_date']); ?>
                        </p>
                        <p class="text-gray-600 mt-3"><strong>Description:</strong>
                            <?php echo nl2br(htmlspecialchars($row['description'])); ?>
                        </p>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-600">No memberships available.</p>
        <?php endif; ?>
    </div>

</body>

</html>