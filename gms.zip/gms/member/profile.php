<?php
session_start();
include('../connection/connection.php'); // Database connection

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch member details
$query = "SELECT m.m_id, m.name, m.contact, u.email, m.age, m.start_date, m.end_date, m.weight, m.height, m.fitness_level, m.goal 
          FROM member m
          JOIN users u ON m.user_id = u.user_id
          WHERE m.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$member = $result->fetch_assoc();

if (!$member) {
    echo "<p class='text-red-500 text-center mt-10'>No profile data found.</p>";
    exit();
}

$_SESSION["m_id"] = $member['m_id'];

// Calculate BMI
$weight = $member['weight'];
$height = $member['height'];
$bmi = ($height > 0) ? number_format($weight / ($height * $height), 2) : "N/A";

// Handle AJAX Update Request
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update_profile'])) {
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $age = $_POST['age'];
    $weight = $_POST['weight'];
    $height = $_POST['height'];
    $fitness_level = $_POST['fitness_level'];
    $bmi = ($height > 0) ? number_format($weight / ($height * $height), 2) : "N/A";
    $last_checkup_date = date("Y-m-d");

    // Update member table
    $update_query = "UPDATE member SET contact=?, age=?, weight=?, height=?, bmi=?, fitness_level=?, last_checkup_date=? WHERE user_id=?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("siddssss", $contact, $age, $weight, $height, $bmi, $fitness_level, $last_checkup_date, $user_id);

    // Update users table (email)
    $update_email_query = "UPDATE users SET email=? WHERE user_id=?";
    $stmt_email = $conn->prepare($update_email_query);
    $stmt_email->bind_param("ss", $email, $user_id);

    if ($stmt->execute() && $stmt_email->execute()) {
        echo json_encode(["status" => "success", "message" => "Profile updated successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error updating profile!"]);
    }
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="bg-gray-100 flex">

    <?php include('../main/layout/sidebar2.php'); ?> <!-- Sidebar -->

    <div class="flex-grow p-6 ml-64 flex justify-center items-center min-h-screen">
        <div class="bg-white p-10 rounded-2xl shadow-xl w-full max-w-2xl">
            <h3 class="text-3xl font-bold text-center text-blue-900 mb-6">
                <?php echo htmlspecialchars($member['name']); ?>
            </h3>

            <div class="grid grid-cols-2 gap-x-6 gap-y-4 text-lg text-gray-700">
                <p><strong>📞 Contact:</strong> <span
                        id="contact"><?php echo htmlspecialchars($member['contact']); ?></span></p>
                <p><strong>📧 Email:</strong> <span id="email"><?php echo htmlspecialchars($member['email']); ?></span>
                </p>
                <p><strong>🎂 Age:</strong> <span id="age"><?php echo htmlspecialchars($member['age']); ?></span></p>
                <p><strong>📅 Start Date:</strong> <?php echo htmlspecialchars($member['start_date']); ?></p>
                <p><strong>⏳ End Date:</strong> <?php echo htmlspecialchars($member['end_date']); ?></p>
                <p><strong>⚖️ Weight:</strong> <span
                        id="weight"><?php echo htmlspecialchars($member['weight']); ?></span> kg</p>
                <p><strong>📏 Height:</strong> <span
                        id="height"><?php echo htmlspecialchars($member['height']); ?></span> m</p>
                <p><strong>🏋️ Fitness Level:</strong> <span
                        id="fitness_level"><?php echo htmlspecialchars($member['fitness_level']); ?></span></p>
                <p class="col-span-2"><strong>🔄 Last Checkup Date:</strong> <span
                        id="last_checkup_date"><?php echo date("Y-m-d"); ?></span></p>
            </div>

            <!-- Update Profile Button -->
            <div class="mt-8 text-center">
                <button onclick="openUpdateModal()"
                    class="bg-blue-900 text-white py-3 px-6 rounded-lg shadow-md text-lg font-semibold hover:bg-blue-700 transition">
                    <i class="fas fa-edit mr-2"></i> Update Profile
                </button>
            </div>
        </div>
    </div>

    <script>
        function openUpdateModal() {
            Swal.fire({
                title: 'Update Profile',
                html: `
            <div style="display: flex; flex-direction: column; align-items: flex-start; gap: 5px; width: 100%;">
                <label for="new_email" style="font-size: 14px; font-weight: 600;">Email</label>
                <input id="new_email" type="email" class="swal2-input" style="width: 90%; height: 30px; font-size: 14px;" value="${document.getElementById('email').innerText}">
                
                <label for="new_contact" style="font-size: 14px; font-weight: 600;">Contact</label>
                <input id="new_contact" type="text" class="swal2-input" style="width: 90%; height: 30px; font-size: 14px;" value="${document.getElementById('contact').innerText}">
                
                <label for="new_age" style="font-size: 14px; font-weight: 600;">Age</label>
                <input id="new_age" type="number" class="swal2-input" style="width: 90%; height: 30px; font-size: 14px;" value="${document.getElementById('age').innerText}">
                
                <label for="new_weight" style="font-size: 14px; font-weight: 600;">Weight (kg)</label>
                <input id="new_weight" type="number" class="swal2-input" style="width: 90%; height: 30px; font-size: 14px;" value="${document.getElementById('weight').innerText}">
                
                <label for="new_height" style="font-size: 14px; font-weight: 600;">Height (m)</label>
                <input id="new_height" type="number" step="0.01" class="swal2-input" style="width: 90%; height: 30px; font-size: 14px;" value="${document.getElementById('height').innerText}">
                
                <label for="new_fitness_level" style="font-size: 14px; font-weight: 600;">Fitness Level</label>
                <select id="new_fitness_level" class="swal2-input" style="width: 90%; height: 35px; font-size: 14px;">
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                    <option value="Athlete">Athlete</option>
                </select>
            </div>
        `,
                showCancelButton: true,
                confirmButtonText: 'Update',
                preConfirm: () => {
                    return {
                        email: document.getElementById('new_email').value,
                        contact: document.getElementById('new_contact').value,
                        age: document.getElementById('new_age').value,
                        weight: document.getElementById('new_weight').value,
                        height: document.getElementById('new_height').value,
                        fitness_level: document.getElementById('new_fitness_level').value
                    };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch("profile.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: `update_profile=1&email=${result.value.email}&contact=${result.value.contact}&age=${result.value.age}&weight=${result.value.weight}&height=${result.value.height}&fitness_level=${result.value.fitness_level}`
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === "success") {
                                Swal.fire("Updated!", "Profile updated successfully.", "success").then(() => {
                                    location.reload(); // ✅ Auto-refresh the page after success
                                });
                            } else {
                                Swal.fire("Error!", "Could not update profile.", "error");
                            }
                        });
                }
            });
        }
    </script>

</body>

</html>