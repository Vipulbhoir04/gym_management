<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Fitness Factory</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        .fade-in-left {
            opacity: 0;
            transform: translateX(-50px);
            transition: opacity 1s ease-out, transform 1s ease-out;
        }

        .fade-in-right {
            opacity: 0;
            transform: translateX(50px);
            transition: opacity 1s ease-out, transform 1s ease-out;
        }

        .fade-in-left.active,
        .fade-in-right.active {
            opacity: 1;
            transform: translateX(0);
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("active");
                    }
                });
            }, { threshold: 0.5 });

            document.querySelectorAll(".fade-in-left").forEach(element => {
                observer.observe(element);
            });
        });
    </script>
</head>

<body class="bg-white text-black">
    <header class="bg-white shadow-lg p-5 flex justify-between items-center fixed w-full top-0 z-10">
        <h1 class="text-2xl font-bold text-black">THE FITNESS FACTORY</h1>
        <nav class="flex space-x-10">
            <a href="index.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-home mr-2"></i>Home</a>
            <a href="aboutus.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-info-circle mr-2"></i>About Us</a>
            <a href="contact1.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-envelope mr-2"></i>Contact</a>
        </nav>
        <div class="flex space-x-2">
            <a href="login.php" class="bg-blue-500 text-white px-8 py-1 rounded-lg text-center">Log In</a>
            <a href="register.php" class="bg-green-500 text-white px-8 py-1 rounded-lg text-center">Sign Up</a>
        </div>
    </header>

    <!-- Page Heading -->
    <div class="text-center py-10 fade-in">
        <section class="h-screen flex flex-col justify-center items-center text-center px-4 bg-cover bg-center mt-0"
            style="background-image: url('img/hero/hero-2.jpg');">
            <h1 class="text-4xl font-bold text-white">Contact Us</h1>
            <p class="text-white mt-2">We'd love to hear from you! Get in touch with us.</p>
        </section>
    </div>

    <!-- Introductory Content -->
    <div class="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8 mb-8 fade-in">
        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Why Contact Us?</h2>
        <p class="text-gray-600 leading-relaxed">
            Whether you're looking to sign up for a membership, have questions about our personal training programs, or
            want to know more about our state-of-the-art gym facilities, we are here to assist you.
            Our team is dedicated to ensuring you have the best fitness experience possible. Drop us a message, and
            we'll get back to you as soon as possible!
        </p>
        <ul class="list-disc list-inside mt-4 text-gray-700">
            <li>Membership inquiries</li>
            <li>Personal training sessions</li>
            <li>Gym facilities & services</li>
            <li>Business partnerships & collaborations</li>
        </ul>
    </div>

    <!-- Google Map Section -->
    <div class="max-w-4xl mx-auto mb-12 fade-in">
        <h2 class="text-2xl font-semibold text-gray-800 text-center mb-4">Find Us Here</h2>
        <iframe class="w-full h-72 rounded-lg shadow-lg"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.83543450933!2d72.950651755542!3d19.208350793857154!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2z19.208351N%2072.950652E!5e0!3m2!1sen!2s!4v1615322862754"
            allowfullscreen="" loading="lazy">
        </iframe>
    </div>


    <!-- Contact Details Section -->
    <section id="contact-info" class="bg-gray-100 py-10">
        <div class="container mx-auto text-center">
            <h2 class="text-3xl font-bold mb-6">Get in Touch</h2>
            <div class="flex flex-col md:flex-row justify-center items-center gap-10">
                <!-- Location -->
                <div class="flex items-center gap-4">
                    <i class="fas fa-map-marker-alt text-3xl text-red-500"></i>
                    <div>
                        <h3 class="text-xl font-semibold">Our Location</h3>
                        <p>123 Fitness Street, Lokmanya Nagar, Thane(W)</p>
                    </div>
                </div>

                <!-- Contact Number -->
                <div class="flex items-center gap-4">
                    <i class="fas fa-phone-alt text-3xl text-green-500"></i>
                    <div>
                        <h3 class="text-xl font-semibold">Call Us</h3>
                        <p>+91 90000 00001</p>
                    </div>
                </div>

                <!-- Email -->
                <div class="flex items-center gap-4">
                    <i class="fas fa-envelope text-3xl text-blue-500"></i>
                    <div>
                        <h3 class="text-xl font-semibold">Email Us</h3>
                        <p>info@thefitnessfactory.com</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FontAwesome for Icons -->
    <script src="https://kit.fontawesome.com/YOUR_KIT_CODE.js" crossorigin="anonymous"></script>


    <footer class="p-8 bg-black text-gray-400">
        <div class="container mx-auto flex flex-col md:flex-row justify-between items-start gap-6">
            <!-- About Section -->
            <div class="w-full md:w-1/3">
                <h3 class="text-lg font-bold text-white mb-2">About Us</h3>
                <p class="text-sm">THE FITNESS FACTORY is dedicated to providing top-tier fitness training and equipment
                    to help you achieve your fitness goals.</p>
            </div>

            <!-- Social Media Links -->
            <div class="w-full md:w-1/3">
                <h3 class="text-lg font-bold text-white mb-2">Follow Us</h3>
                <div class="flex space-x-4">
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-instagram"></i> Instagram</a>
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-facebook"></i> Facebook</a>
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-twitter"></i> Twitter</a>
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fas fa-envelope"></i> Email</a>
                </div>
            </div>

            <!-- Gym Timings -->
            <div class="w-full md:w-1/3">
                <h3 class="text-lg font-bold text-white mb-2">Opening Hours</h3>
                <p class="text-sm">Mon - Sat: 6 AM - 10 PM</p>
            </div>
        </div>

        <!-- Bottom: Copyright -->
        <div class="text-center mt-6 border-t border-gray-700 pt-4">
            <p>&copy; 2025 THE FITNESS FACTORY. All rights reserved.</p>
        </div>
    </footer>
</body>

</html>