<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        .submenu {
            display: none;
        }

        .submenu.hidden {
            display: none;
        }

        .submenu:not(.hidden) {
            display: block;
        }

        /* Hide sidebar on small screens */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }
        }
    </style>
</head>

<body class="bg-gray-100 flex">

    <!-- Mobile Sidebar Toggle Button -->
    <button id="menu-toggle" class="md:hidden fixed top-4 left-4 z-50 bg-blue-900 text-white p-2 rounded-full">
        <i class="fas fa-bars text-xl"></i>
    </button>

    <!-- Sidebar -->
    <aside class="bg-blue-900 text-white w-64 h-screen p-5 fixed sidebar">
    <h2 class="text-2xl font-bold text-center mb-6">Member Panel</h2>
    <nav class="space-y-2">
        <a href="member_dashboard.php" class="block py-2 px-4 bg-blue-700 rounded-lg">
            <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
        </a>
        
        <a href="profile.php" class="block py-2 px-4 hover:bg-blue-700 rounded-lg">
            <i class="fas fa-user mr-2"></i> Profile
        </a>

        <!-- Attendance Section -->
        <div>
            <button class="w-full text-left py-2 px-4 flex justify-between items-center hover:bg-blue-700 rounded-lg dropdown-btn">
                <span><i class="fas fa-calendar-check mr-2"></i> Attendance</span> <i class="fas fa-chevron-down"></i>
            </button>
            <div class="submenu hidden">
                <a href="enter_attendance.php" class="block py-2 pl-8 hover:bg-blue-700">➤ Enter Attendance</a>
                <a href="view_attendance.php" class="block py-2 pl-8 hover:bg-blue-700">➤ View Attendance</a>
            </div>
        </div>
        
        <a href="notifications.php" class="block py-2 px-4 hover:bg-blue-700 rounded-lg">
            <i class="fas fa-bell mr-2"></i> Notifications
        </a>

        <a href="membership.php" class="block py-2 px-4 hover:bg-blue-700 rounded-lg">
            <i class="fas fa-id-card-alt mr-2"></i> Membership
        </a>
        
        <a href="gallery.php" class="block py-2 px-4 hover:bg-blue-700 rounded-lg">
            <i class="fas fa-images mr-2"></i> Gallery
        </a>
        
        <a href="feedback.php" class="block py-2 px-4 hover:bg-blue-700 rounded-lg">
            <i class="fas fa-comment-alt mr-2"></i> Give Feedback
        </a>

        <a href="report.php" class="block py-2 px-4 hover:bg-blue-700 rounded-lg">
            <i class="fas fa-file-alt mr-2"></i> Report
        </a>

        <a href="../logout.php" class="block py-2 px-4 bg-red-600 hover:bg-red-700 rounded-lg mt-4">
            <i class="fas fa-sign-out-alt mr-2"></i> Logout
        </a>
    </nav>
</aside>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const dropdownButtons = document.querySelectorAll(".dropdown-btn");
        dropdownButtons.forEach(button => {
            button.addEventListener("click", function () {
                let submenu = this.nextElementSibling;
                document.querySelectorAll(".submenu").forEach(menu => {
                    if (menu !== submenu) {
                        menu.classList.add("hidden");
                    }
                });
                submenu.classList.toggle("hidden");
            });
        });
    });
</script>


</body>

</html>