<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        .submenu {
            display: none;
        }

        .submenu.hidden {
            display: none;
        }

        .submenu:not(.hidden) {
            display: block;
        }

        /* Hide sidebar on small screens */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }
        }
    </style>
</head>

<body class="bg-gray-100 flex">

    <!-- Mobile Sidebar Toggle Button -->
    <button id="menu-toggle" class="md:hidden fixed top-4 left-4 z-50 bg-blue-900 text-white p-2 rounded-full">
        <i class="fas fa-bars text-xl"></i>
    </button>

    <!-- Sidebar -->
    <aside class="bg-blue-900 text-white w-64 h-screen p-5 fixed">
        <h2 class="text-2xl font-bold text-center mb-6">Admin Panel</h2>
        <nav class="space-y-2">
            <a href="admin_dashboard.php" class="block py-2 px-4 bg-blue-700 rounded-lg">
                <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
            </a>

            <!-- Admin Section -->
            <div>
                <button
                    class="w-full text-left py-2 px-4 flex justify-between items-center hover:bg-blue-700 rounded-lg dropdown-btn">
                    <span><i class="fas fa-user-shield mr-2"></i> Admin/Staff</span> <i class="fas fa-chevron-down"></i>
                </button>
                <div class="submenu hidden">
                    <a href="add_admin.php" class="block py-2 pl-8 hover:bg-blue-700">➤ Add Admin/Staff</a>
                    <a href="view_admins.php" class="block py-2 pl-8 hover:bg-blue-700">➤ View List</a>
                </div>
            </div>

            <!-- Users Section -->
            <div>
                <button
                    class="w-full text-left py-2 px-4 flex justify-between items-center hover:bg-blue-700 rounded-lg dropdown-btn">
                    <span><i class="fas fa-users mr-2"></i> Users</span> <i class="fas fa-chevron-down"></i>
                </button>
                <div class="submenu hidden">
                    <a href="add_user.php" class="block py-2 pl-8 hover:bg-blue-700">➤ Add User</a>
                    <a href="view_users.php" class="block py-2 pl-8 hover:bg-blue-700">➤ View List</a>
                </div>
            </div>

            <!-- Members Section -->
            <div>
                <button
                    class="w-full text-left py-2 px-4 flex justify-between items-center hover:bg-blue-700 rounded-lg dropdown-btn">
                    <span><i class="fas fa-user-friends mr-2"></i> Members</span> <i class="fas fa-chevron-down"></i>
                </button>
                <div class="submenu hidden">
                    <a href="add_member.php" class="block py-2 pl-8 hover:bg-blue-700">➤ Add Member</a>
                    <a href="view_members.php" class="block py-2 pl-8 hover:bg-blue-700">➤ View List</a>
                </div>
            </div>

            <!-- Instructor Section -->
            <div>
                <button
                    class="w-full text-left py-2 px-4 flex justify-between items-center hover:bg-blue-700 rounded-lg dropdown-btn">
                    <span><i class="fas fa-chalkboard-teacher mr-2"></i> Instructor</span> <i
                        class="fas fa-chevron-down"></i>
                </button>
                <div class="submenu hidden">
                    <a href="add_instructor.php" class="block py-2 pl-8 hover:bg-blue-700">➤ Add Instructor</a>
                    <a href="view_instructors.php" class="block py-2 pl-8 hover:bg-blue-700">➤ View List</a>
                </div>
            </div>

            <!-- Equipment Section -->
            <div>
                <button
                    class="w-full text-left py-2 px-4 flex justify-between items-center hover:bg-blue-700 rounded-lg dropdown-btn">
                    <span><i class="fas fa-dumbbell mr-2"></i> Equipment</span> <i class="fas fa-chevron-down"></i>
                </button>
                <div class="submenu hidden">
                    <a href="add_equipment.php" class="block py-2 pl-8 hover:bg-blue-700">➤ Add Equipment</a>
                    <a href="view_equipment.php" class="block py-2 pl-8 hover:bg-blue-700">➤ View List</a>
                </div>
            </div>

            <!-- Membership Section -->
            <div>
                <button
                    class="w-full text-left py-2 px-4 flex justify-between items-center hover:bg-blue-700 rounded-lg dropdown-btn">
                    <span><i class="fas fa-id-card-alt mr-2"></i> Membership</span> <i class="fas fa-chevron-down"></i>
                </button>
                <div class="submenu hidden">
                    <a href="add_membership.php" class="block py-2 pl-8 hover:bg-blue-700">➤ Add Membership</a>
                    <a href="view_membership.php" class="block py-2 pl-8 hover:bg-blue-700">➤ View Membership</a>
                </div>
            </div>

            <!-- Images Section -->
            <div>
                <button
                    class="w-full text-left py-2 px-4 flex justify-between items-center hover:bg-blue-700 rounded-lg dropdown-btn">
                    <span><i class="fas fa-images mr-2"></i> Images</span> <i class="fas fa-chevron-down"></i>
                </button>
                <div class="submenu hidden">
                    <a href="add_image.php" class="block py-2 pl-8 hover:bg-blue-700">➤ Add Image</a>
                    <a href="view_images.php" class="block py-2 pl-8 hover:bg-blue-700">➤ View Images</a>
                </div>
            </div>

            <!-- Notification Section -->
            <div>
                <button
                    class="w-full text-left py-2 px-4 flex justify-between items-center hover:bg-blue-700 rounded-lg dropdown-btn">
                    <span><i class="fas fa-bell mr-2"></i> Notification</span> <i class="fas fa-chevron-down"></i>
                </button>
                <div class="submenu hidden">
                    <a href="send_notification.php" class="block py-2 pl-8 hover:bg-blue-700">➤ Send Notification</a>
                    <a href="view_notifications.php" class="block py-2 pl-8 hover:bg-blue-700">➤ View Notifications</a>
                </div>
            </div>

            <!-- View Applications -->
            <a href="view_applications.php" class="block py-2 px-4 hover:bg-blue-700 rounded-lg">
                <i class="fas fa-folder-open mr-2"></i> View Applications
            </a>

            <!-- Logout -->
            <a href="../logout.php" class="block py-2 px-4 bg-red-600 hover:bg-red-700 rounded-lg mt-4">
                <i class="fas fa-sign-out-alt mr-2"></i> Logout
            </a>
        </nav>
    </aside>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Select all dropdown buttons
            const dropdownButtons = document.querySelectorAll(".dropdown-btn");

            dropdownButtons.forEach(button => {
                button.addEventListener("click", function () {
                    let submenu = this.nextElementSibling;

                    // Close all submenus except the one being toggled
                    document.querySelectorAll(".submenu").forEach(menu => {
                        if (menu !== submenu) {
                            menu.classList.add("hidden");
                        }
                    });

                    // Toggle the clicked submenu
                    submenu.classList.toggle("hidden");
                });
            });

            // Sidebar Toggle for Mobile
            const sidebar = document.querySelector(".sidebar");
            const menuToggle = document.getElementById("menu-toggle");

            menuToggle.addEventListener("click", function (event) {
                sidebar.classList.toggle("open");
                event.stopPropagation(); // Prevents closing when clicking button again
            });

            // Close sidebar if clicked outside (for mobile)
            document.addEventListener("click", function (event) {
                if (!sidebar.contains(event.target) && !menuToggle.contains(event.target) && window.innerWidth <= 768) {
                    sidebar.classList.remove("open");
                }
            });
        });

    </script>

</body>

</html>