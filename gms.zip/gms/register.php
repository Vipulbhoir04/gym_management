<?php
include 'connection/connection.php';

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    // Validation: Username (Min 3 characters)
    if (empty($username) || strlen($username) < 3) {
        $errors[] = "Username must be at least 3 characters long.";
    }

    // Validation: Email (Must be valid format)
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Enter a valid email address.";
    }

    // Validation: Password (Min 8 chars, must contain letters & digits)
    if (strlen($password) < 8) {
        $errors[] = "Password must be greater than or equal to 8 characters.";
    } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        $errors[] = "Password must include both letters and numbers.";
    }

    // Check if email already exists
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $errors[] = "Email already exists.";
    }
    $stmt->close();

    if (empty($errors)) {
        // Generate user_id with prefix 'U0000'
        $query = "SELECT IFNULL(MAX(CAST(SUBSTRING(user_id, 2) AS UNSIGNED)), 0) + 1 AS new_id FROM users";
        $result = $conn->query($query);
        $row = $result->fetch_assoc();
        $new_id = $row['new_id'];
        $user_id = "U" . str_pad($new_id, 5, "0", STR_PAD_LEFT);


        // Store password securely (use password_hash)
        //$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Insert user
        $stmt = $conn->prepare("INSERT INTO users (user_id, username, email, psswd) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $user_id, $username, $email, $password);
        if ($stmt->execute()) {
            echo "<script>alert('Registration Successful! You can now log in.'); window.location.href='login.php';</script>";
        } else {
            $errors[] = "Something went wrong. Please try again.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        body {
            background: url('img/hero/hero-1.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            position: relative;
            text-align: center;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: -1;
        }

        .animated-text {
            font-size: 3rem;
            font-weight: bold;
            color: rgba(255, 255, 255, 0.2);
            position: absolute;
            top: 8%;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
            animation: fadeInText 3s ease-in-out infinite alternate;
        }

        @keyframes fadeInText {
            0% {
                opacity: 0.3;
                transform: translateX(-50%) scale(1);
            }

            100% {
                opacity: 0.7;
                transform: translateX(-50%) scale(1.05);
            }
        }

        @media (max-width: 768px) {
            .animated-text {
                font-size: 2rem;
                top: 5%;
            }
        }

        .input-container {
            position: relative;
            width: 300px;
            display: flex;
            align-items: center;
            flex-direction: column;
            /* Keeps the input and error message aligned */
        }

        .input-wrapper {
            position: relative;
            width: 100%;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
        }


        .input-icon,
        .password-toggle {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
        }

        .password-toggle {
            right: 10px;
            cursor: pointer;
        }

        .input-field {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid rgba(255, 255, 255, 0.5);
            background: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
            color: white;
            outline: none;
            transition: all 0.3s ease-in-out;
        }

        .input-field::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .input-field:focus {
            border-color: #ffffff;
            background: rgba(255, 255, 255, 0.3);
        }

        .btn {
            width: 300px;
            padding: 10px;
            background: #16a34a;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn:hover {
            background: #15803d;
        }

        .link {
            color: #3b82f6;
        }

        .link:hover {
            text-decoration: underline;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="animated-text">Sign Up</div>

    <h2 class="text-white text-3xl font-bold mb-6">Create an Account</h2>

    <form action="" method="POST" class="space-y-4">
        <div class="input-container">
            <?php if (!empty($errors)): ?>
                <div class="text-red-500 text-sm font-semibold mb-2">
                    <?= implode('<br>', $errors) ?>
                </div>
            <?php endif; ?>

            <div class="input-wrapper">
                <i class="fa-solid fa-user input-icon"></i>
                <input type="text" name="username"
                    value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>" required
                    class="input-field" placeholder="Username">
            </div>
        </div>


        <div class="input-container">
            <i class="fa-solid fa-envelope input-icon"></i>
            <input type="email" name="email"
                value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>" required
                class="input-field" placeholder="Email">
        </div>

        <div class="input-container relative">
            <i class="fa-solid fa-lock input-icon"></i>
            <input type="password" id="password" name="password" required class="input-field" placeholder="Password">
            <span id="togglePassword" class="password-toggle">
                <i id="eye-icon" class="fa-solid fa-eye"></i>
            </span>
        </div>

        <button type="submit" class="btn">Sign Up</button>
    </form>


    <p class="mt-4 text-white">Already have an account? <a href="login.php" class="link">Log in here.</a></p>

    <script>
        document.getElementById("togglePassword").addEventListener("click", function () {
            let passwordField = document.getElementById("password");
            let eyeIcon = document.getElementById("eye-icon");

            passwordField.type = passwordField.type === "password" ? "text" : "password";
            eyeIcon.classList.toggle("fa-eye");
            eyeIcon.classList.toggle("fa-eye-slash");
        });
    </script>

</body>

</html>