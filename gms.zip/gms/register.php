<?php
session_start();
include('../gms/connection/connection.php');

// Function to generate a unique user_id with the prefix U0000
function generateUserId($conn) {
    $prefix = "U0000";
    $sql = "SELECT MAX(CAST(SUBSTRING(user_id, 6) AS UNSIGNED)) AS max_id FROM users";
    $result = $conn->query($sql);

    if ($result) {
        $row = $result->fetch_assoc();
        $max_id = $row['max_id'] + 1;
        return $prefix . str_pad($max_id, 0, '0', STR_PAD_LEFT);
    } else {
        return $prefix . '1'; // default value if no users exist
    }
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Generate user_id
    $user_id = generateUserId($conn);

    // Insert user into database
    $sql = "INSERT INTO users (user_id, username, email, psswd) VALUES ('$user_id', '$username', '$email', '$password')";
    if ($conn->query($sql) === TRUE) {
        $success_message = "Registration successful! Redirecting to login page...";
        echo '<script type="text/javascript">
            setTimeout(function() {
                window.location.href = "login.php";
            }, 2000);
        </script>';
    } else {
        $error_message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Gym Template">
    <meta name="keywords" content="Gym, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>The Fitness Factory</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,600,700&display=swap" rel="stylesheet">

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/barfiller.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <!--Custom Styles-->
    <style>
        body {
            background: url('img/hero/hero-1.jpg') no-repeat center center/cover;
        }

        .register-container {
            background: rgba(0, 0, 0, 0.8);
            padding: 40px;
            border-radius: 10px;
            max-width: 450px;
            margin: auto;
        }

        .btn-custom {
            background: #ff6b00;
            border: none;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
            width: 100%;
            color: white;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background: #e65c00;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .social-icons a {
            color: white;
            font-size: 20px;
            margin-right: 10px;
            transition: 0.3s;
        }

        .social-icons a:hover {
            color: #ff6b00;
        }
    </style>

</head>

<body>
    <!-- Register Form Section -->
    <section class="d-flex align-items-center vh-100">
        <div class="container">
            <div class="register-container text-center">
                <h2 class="mb-4 text-warning">SIGN UP</h2>

                <?php
                if (isset($success_message)) {
                    echo '<div class="alert alert-success">' . $success_message . '</div>';
                }

                if (isset($error_message)) {
                    echo '<div class="alert alert-danger">' . $error_message . '</div>';
                }
                ?>

                <form action="" method="POST">
                    <div class="mb-3">
                        <input type="text" name="username" class="form-control py-3" placeholder="Username" required>
                    </div>
                    <div class="mb-3">
                        <input type="email" name="email" class="form-control py-3" placeholder="Email Address" required>
                    </div>
                    <div class="mb-3">
                        <input type="password" name="password" class="form-control py-3" placeholder="Password" required>
                    </div>

                    <button type="submit" class="btn-custom">Sign Up</button>

                    <p class="mt-3">Already have an account? <a href="login.php" class="text-warning">Login</a></p>
                </form>
            </div>
        </div>
    </section>

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/masonry.pkgd.min.js"></script>
    <script src="js/jquery.barfiller.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>
