<?php
include '../connection/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $m_id = $_POST['m_id'];
    $status = $_POST['status'];
    $last_checkup_date = date('Y-m-d'); // Update last_checkup_date to today

    $update_query = "UPDATE member SET status='$status', last_checkup_date='$last_checkup_date' WHERE m_id='$m_id'";
    mysqli_query($conn, $update_query);
    header("Location: view_members.php");
    exit();
}

$query = "SELECT m.m_id, m.name, ms.title AS membership_title, m.start_date, m.end_date, m.status, m.user_id 
          FROM member m 
          INNER JOIN membership ms ON m.mem_id = ms.mem_id";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Members</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
</head>

<body class="bg-gray-100 flex">
    <?php 
    include '../main/layout/sidebar.php';
    ?>
    <div class="ml-64 p-6 w-full">
        <h2 class="text-2xl font-bold mb-4">View Members</h2>
        <div class="bg-white p-4 rounded-lg shadow">
            <table class="w-full border-collapse border border-gray-300">
                <thead>
                    <tr class="bg-blue-900 text-white">
                        <th class="p-2 border border-gray-300">Name</th>
                        <th class="p-2 border border-gray-300">Membership Title</th>
                        <th class="p-2 border border-gray-300">Start Date</th>
                        <th class="p-2 border border-gray-300">End Date</th>
                        <th class="p-2 border border-gray-300">Status</th>
                        <th class="p-2 border border-gray-300">User</th>
                        <th class="p-2 border border-gray-300">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr class="text-center border border-gray-300">
                            <td class="p-2 border border-gray-300"><?php echo $row['name']; ?></td>
                            <td class="p-2 border border-gray-300"><?php echo $row['membership_title']; ?></td>
                            <td class="p-2 border border-gray-300"><?php echo $row['start_date']; ?></td>
                            <td class="p-2 border border-gray-300"><?php echo $row['end_date']; ?></td>
                            <td class="p-2 border border-gray-300"><?php echo $row['status']; ?></td>
                            <td class="p-2 border border-gray-300"><?php echo $row['user_id']; ?></td>
                            <td class="p-2 border border-gray-300">
                                <button class="text-blue-500 mx-2"
                                    onclick="openEditModal('<?php echo $row['m_id']; ?>', '<?php echo $row['name']; ?>', '<?php echo $row['status']; ?>')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="fixed inset-0 hidden bg-gray-600 bg-opacity-50 flex items-center justify-center">
        <div class="bg-white p-6 rounded shadow-lg w-1/3">
            <h2 class="text-xl font-bold mb-4">Edit Member</h2>
            <form id="editForm" method="POST">
                <input type="hidden" id="edit_m_id" name="m_id">
                <label class="block mb-2">Name:</label>
                <input type="text" id="edit_name" name="name" class="w-full p-2 border rounded mb-2" readonly>
                <label class="block mb-2">Status:</label>
                <select id="edit_status" name="status" class="w-full p-2 border rounded mb-2">
                    <option value="Active">Active</option>
                    <option value="Expired">Expired</option>
                </select>
                <div class="flex justify-end">
                    <button type="button" onclick="closeEditModal()"
                        class="mr-2 px-4 py-2 bg-gray-500 text-white rounded">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded">Update</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openEditModal(id, name, status) {
            document.getElementById('edit_m_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_status').value = status;
            document.getElementById('editModal').classList.remove('hidden');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.add('hidden');
        }
    </script>
</body>

</html>