<?php
session_start();
include "../connection/connection.php";

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Fetch last mem_id from the database
$query = "SELECT mem_id FROM membership ORDER BY mem_id DESC LIMIT 1";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $lastId = (int) substr($row['mem_id'], 5);
    $newId = "MEM00" . ($lastId + 1);
} else {
    $newId = "MEM001";
}

$successMessage = "";

// Insert membership data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $type = $_POST["type"];
    $price = $_POST["price"];
    $duration = $_POST["duration"];
    $duration_type = $_POST["duration_type"];
    $description = $_POST["description"];
    $discount = $_POST["discount"];
    $start_date = $_POST["start_date"];
    $end_date = $_POST["end_date"];
    $status = $_POST["status"];

    $stmt = $conn->prepare("INSERT INTO membership (mem_id, title, type, price, duration, duration_type, description, discount, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssss", $newId, $title, $type, $price, $duration, $duration_type, $description, $discount, $start_date, $end_date, $status);
    $stmt->execute();

    $successMessage = "Membership added successfully!";
    echo "<script>
        setTimeout(function() {
            window.location.href = 'view_membership.php';
        }, 5000);
    </script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Membership</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <?php include "../main/layout/sidebar.php"; ?>

    <!-- Main Content -->
    <div class="flex justify-center items-center w-full p-10">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-3xl">
            <h2 class="text-2xl font-bold text-center mb-6">Add Membership</h2>
            <?php if ($successMessage): ?>
                <div class="bg-green-500 text-white text-center py-2 rounded mb-4">
                    <?php echo $successMessage; ?>
                </div>
            <?php endif; ?>
            <form method="POST">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-gray-700">Title</label>
                        <input type="text" name="title" class="w-full px-4 py-2 border rounded-lg" required>
                    </div>
                    <div>
                        <label class="block text-gray-700">Type</label>
                        <select name="type" class="w-full px-4 py-2 border rounded-lg" required>
                            <option value="REGULAR">REGULAR</option>
                            <option value="SEASONAL">SEASONAL</option>
                            <option value="OTHER">OTHER</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-gray-700">Price</label>
                        <input type="number" name="price" class="w-full px-4 py-2 border rounded-lg" required>
                    </div>
                    <div>
                        <label class="block text-gray-700">Duration</label>
                        <input type="text" name="duration" class="w-full px-4 py-2 border rounded-lg" required>
                    </div>
                    <div>
                        <label class="block text-gray-700">Duration Type</label>
                        <select name="duration_type" class="w-full px-4 py-2 border rounded-lg" required>
                            <option value="Days">Days</option>
                            <option value="Months">Months</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-gray-700">Discount</label>
                        <input type="number" name="discount" class="w-full px-4 py-2 border rounded-lg">
                    </div>
                    <div>
                        <label class="block text-gray-700">Start Date</label>
                        <input type="date" name="start_date" id="start_date" class="w-full px-4 py-2 border rounded-lg"
                            required>
                    </div>
                    <div>
                        <label class="block text-gray-700">End Date</label>
                        <input type="date" name="end_date" id="end_date" class="w-full px-4 py-2 border rounded-lg"
                            required>
                    </div>
                    <div class="col-span-2">
                        <label class="block text-gray-700">Description</label>
                        <textarea name="description" class="w-full px-4 py-2 border rounded-lg" required></textarea>
                    </div>
                    <div class="col-span-2">
                        <label class="block text-gray-700">Status</label>
                        <select name="status" class="w-full px-4 py-2 border rounded-lg" required>
                            <option value="Active">Active</option>
                            <option value="Expired">Expired</option>
                        </select>
                    </div>
                </div>
                <div class="flex justify-center mt-4">
                    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg">Add Membership</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            let today = new Date().toISOString().split('T')[0];
            document.getElementById("start_date").setAttribute("min", today);
            document.getElementById("end_date").setAttribute("min", today);
        });
    </script>

</body>

</html>