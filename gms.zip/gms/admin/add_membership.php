<?php
// Include the database connection file
include('../connection/connection.php');

// Handling form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $type = $_POST['type'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];
    $description = $_POST['description'];

    // Generate a new mem_id
    $result = $conn->query("SELECT mem_id FROM membership ORDER BY mem_id DESC LIMIT 1");
    $lastMemId = $result->fetch_assoc()['mem_id'];
    $memNumber = intval(substr($lastMemId, 3)) + 1;
    $newMemId = "MEM" . str_pad($memNumber, 3, '0', STR_PAD_LEFT);

    $sql = "INSERT INTO membership (mem_id, title, type, price, duration, description)
            VALUES ('$newMemId', '$title', '$type', '$price', '$duration', '$description')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New membership added successfully!');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha384-k6RqeWeci5ZR/Lv4MR0sA0FfDOM6CTIYk3Q7SufV1jM0K4HX1qrB0dtu3hLFW4z" crossorigin="anonymous">
    <style>
        .sidebar {
            height: 100vh;
            width: 240px;
            /* Slightly increased width */
            background-color: #343a40;
            color: white;
            padding: 0;
        }

        .sidebar a {
            color: white;
            font-size: 12px;
            /* Reduced font size */
            padding: 8px 15px;
            position: relative;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .sidebar .collapse a:before {
            content: '';
            position: absolute;
            left: -25px;
        }

        .fa-arrow-right {
            margin-right: 10px;
            color: black;
            /* Ensure the arrow is visible */
        }

        .navbar-custom {
            background-color: #343a40;
            color: white;
            height: auto;
            display: flex;
            align-items: center;
        }

        .navbar-custom a {
            color: white;
        }

        .navbar-custom a:hover {
            color: #adb5bd;
        }

        .content-wrapper {
            display: flex;
            width: 100%;
        }

        .main-content {
            flex: 1;
            padding: 20px;
            /* Top and bottom padding */
            padding-left: 250px;
            /* Left padding */
            padding-right: 250px;
            /* Right padding */
            background-color: #f8f9fa;
        }
    </style>
</head>

<body class="d-flex">

    <!-- Sidebar -->
    <aside class="sidebar">
        <!-- Gym Logo -->
        <div class="text-center py-3">
            <img src="../img/logo.png" alt="Gym Logo" class="img-fluid mx-auto d-block" style="max-width: 80%;">
        </div>
        <!-- Sidebar Menu -->
        <nav class="nav flex-column">
            <a class="nav-link" href="../admin/admin_dashboard.php">Dashboard</a>

            <a class="nav-link" data-toggle="collapse" href="#manageMembersSubmenu" role="button" aria-expanded="false"
                aria-controls="manageMembersSubmenu">
                Manage Members
            </a>
            <div class="collapse" id="manageMembersSubmenu">
                <a class="nav-link ml-3" href="#list-all-members"><i class="fas fa-arrow-right"></i>List All Members</a>
                <a class="nav-link ml-3" href="#remove-member"><i class="fas fa-arrow-right"></i>Remove Member</a>
                <a class="nav-link ml-3" href="#update-member-details"><i class="fas fa-arrow-right"></i>Update Member
                    Details</a>
            </div>

            <a class="nav-link" data-toggle="collapse" href="#gymEquipmentSubmenu" role="button" aria-expanded="false"
                aria-controls="gymEquipmentSubmenu">
                Gym Equipment
            </a>
            <div class="collapse" id="gymEquipmentSubmenu">
                <a class="nav-link ml-3" href="#list-gym-equipment"><i class="fas fa-arrow-right"></i>List Gym
                    Equipment</a>
                <a class="nav-link ml-3" href="#add-equipment"><i class="fas fa-arrow-right"></i>Add Equipment</a>
                <a class="nav-link ml-3" href="#remove-equipment"><i class="fas fa-arrow-right"></i>Remove Equipment</a>
                <a class="nav-link ml-3" href="#update-equipment-details"><i class="fas fa-arrow-right"></i>Update
                    Equipment Details</a>
            </div>

            <a class="nav-link" href="#attendance">Attendance</a>
            <a class="nav-link" href="#members-status">Member's Status</a>

            <a class="nav-link" data-toggle="collapse" href="#announcementSubmenu" role="button" aria-expanded="false"
                aria-controls="announcementSubmenu">
                Announcement
            </a>
            <div class="collapse" id="announcementSubmenu">
                <a class="nav-link ml-3" href="../admin/make_announcement.php"><i class="fas fa-arrow-right"></i>Make
                    Announcement</a>
                <a class="nav-link ml-3" href="#manage-announcements"><i class="fas fa-arrow-right"></i>Manage
                    Announcements</a>
            </div>

            <a class="nav-link" data-toggle="collapse" href="#staffManagementSubmenu" role="button"
                aria-expanded="false" aria-controls="staffManagementSubmenu">
                Staff Management
            </a>
            <div class="collapse" id="staffManagementSubmenu">
                <a class="nav-link ml-3" href="../admin/add_staff.php"><i class="fas fa-arrow-right"></i>Add Staff</a>
                <a class="nav-link ml-3" href="#manage-staff"><i class="fas fa-arrow-right"></i>Manage Staff</a>
            </div>

            <a class="nav-link" data-toggle="collapse" href="#adminManagementSubmenu" role="button"
                aria-expanded="false" aria-controls="adminManagementSubmenu">
                Admin Management
            </a>
            <div class="collapse" id="adminManagementSubmenu">
                <a class="nav-link ml-3" href="../admin/add_admin.php"><i class="fas fa-arrow-right"></i>Add Admin</a>
                <a class="nav-link ml-3" href="#manage-admin"><i class="fas fa-arrow-right"></i>Manage Admin</a>
            </div>

            <a class="nav-link" data-toggle="collapse" href="#membershipSubmenu" role="button" aria-expanded="false"
                aria-controls="membershipSubmenu">
                Membership
            </a>
            <div class="collapse" id="membershipSubmenu">
                <a class="nav-link ml-3" href="../admin/add_membership.php"><i class="fas fa-arrow-right"></i>Add
                    Membership</a>
                <a class="nav-link ml-3" href="#manage-membership"><i class="fas fa-arrow-right"></i>Manage
                    Membership</a>
            </div>
        </nav>
    </aside>

    <!-- Main Content Wrapper -->
    <div class="content-wrapper flex-grow-1 d-flex flex-column">
        <!-- Top Navigation Bar -->
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#profile">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- Main Content -->
        <main class="flex-grow-1 p-4 bg-light">
            <div class="main-content">
                <div class="form-container">
                    <h2 class="text-center">Add Membership</h2>
                    <form action="" method="POST">
                        <div class="form-group">
                            <label for="title">Membership Title</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>
                        <div class="form-group">
                            <label for="type">Membership Type</label>
                            <select class="form-control" id="type" name="type" required>
                                <option value="REGULAR">Regular</option>
                                <option value="SEASONAL">Seasonal</option>
                                <option value="OTHER">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="price">Price</label>
                            <input type="number" class="form-control" id="price" name="price" required>
                        </div>
                        <div class="form-group">
                            <label for="duration">Duration (in days/months)</label>
                            <input type="text" class="form-control" id="duration" name="duration" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"
                                required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Add Membership</button>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>