<?php
include '../connection/connection.php'; // Include your DB connection

$delete_message = ""; // Initialize delete message variable

// Handle Delete Request (POST Method for Security)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $query = "DELETE FROM equipment WHERE e_id = '$delete_id'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $delete_message = "<div class='bg-green-500 text-white p-3 rounded mb-4'>Equipment deleted successfully.</div>";
    } else {
        $delete_message = "<div class='bg-red-500 text-white p-3 rounded mb-4'>Error deleting equipment. Try again.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Equipment</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
    </style>
</head>

<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <?php include("../main/layout/sidebar.php"); ?>

    <!-- Main Content -->
    <div class="flex-1 ml-64 p-6">
        <h1 class="text-3xl font-bold mb-6">Equipment List</h1>

        <!-- Success/Error Message -->
        <?php
        if (!empty($delete_message)) {
            echo $delete_message;
        }
        ?>

        <div class="bg-white p-4 rounded-lg shadow">
            <table class="min-w-full bg-white border border-gray-300">
                <thead>
                    <tr class="bg-blue-900 text-white">
                        <th class="py-2 px-4 border">Name</th>
                        <th class="py-2 px-4 border">Description</th>
                        <th class="py-2 px-4 border">Date of Purchase</th>
                        <th class="py-2 px-4 border">Quantity</th>
                        <th class="py-2 px-4 border">Total Amount</th>
                        <th class="py-2 px-4 border">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT e_id, name, description, date_of_purchase, quantity, total_amount FROM equipment";
                    $result = mysqli_query($conn, $query);

                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr class='text-center border'>";
                            echo "<td class='py-2 px-4 border'>{$row['name']}</td>";
                            echo "<td class='py-2 px-4 border'>{$row['description']}</td>";
                            echo "<td class='py-2 px-4 border'>{$row['date_of_purchase']}</td>";
                            echo "<td class='py-2 px-4 border'>{$row['quantity']}</td>";
                            echo "<td class='py-2 px-4 border'>₹{$row['total_amount']}</td>";
                            echo "<td class='py-2 px-4 border flex justify-center gap-2'>";

                            // Delete Form (Post Method)
                            echo "<form method='POST' onsubmit='return confirm(\"Are you sure you want to delete this equipment?\")'>";
                            echo "<input type='hidden' name='delete_id' value='{$row['e_id']}'>";
                            echo "<button type='submit' class='bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600'>
                                    <i class='fas fa-trash'></i> Delete
                                  </button>";
                            echo "</form>";

                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center py-4'>No equipment found</td></tr>";
                    }

                    mysqli_close($conn);
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Toggle Dropdown Menus
        document.querySelectorAll(".dropdown-btn").forEach(button => {
            button.addEventListener("click", () => {
                let submenu = button.nextElementSibling;
                submenu.style.display = submenu.style.display === "block" ? "none" : "block";
            });
        });

        // Sidebar Toggle
        const sidebar = document.getElementById("sidebar");
        const menuToggle = document.getElementById("menu-toggle");

        menuToggle.addEventListener("click", () => {
            sidebar.classList.toggle("open");
        });

        // Close sidebar if clicked outside (for mobile)
        document.addEventListener("click", (event) => {
            if (!sidebar.contains(event.target) && !menuToggle.contains(event.target) && window.innerWidth <= 768) {
                sidebar.classList.remove("open");
            }
        });
    </script>

</body>

</html>