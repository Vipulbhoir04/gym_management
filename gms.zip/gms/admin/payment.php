<?php
include '../connection/connection.php'; // Database connection
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Details</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex">

    <?php include '../main/layout/sidebar.php'; ?>

    <div class="ml-64 mt-10 flex justify-center items-start w-full">
        <div class="bg-white shadow-lg rounded-lg p-6 w-full max-w-4xl">
            <h2 class="text-2xl font-bold mb-4 text-center">Payment Details</h2>

            <!-- Update Payment Status -->
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $payment_id = $_POST['payment_id'];
                $payment_status = $_POST['payment_status'];
                $current_time = date("Y-m-d H:i:s");

                // Update payment status and date
                $query = "UPDATE payments SET payment_status = ?, payment_date = ? WHERE payment_id = ?";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, "sss", $payment_status, $current_time, $payment_id);

                if (mysqli_stmt_execute($stmt)) {
                    if ($payment_status === 'Completed') {
                        $update_member = "UPDATE member 
                                      SET status = 'Active' 
                                      WHERE m_id = (SELECT m_id FROM payments WHERE payment_id = ?)";
                        $stmt2 = mysqli_prepare($conn, $update_member);
                        mysqli_stmt_bind_param($stmt2, "s", $payment_id);
                        mysqli_stmt_execute($stmt2);
                        mysqli_stmt_close($stmt2);
                    }

                    echo "<script>
                    Swal.fire({
                        title: 'Success!',
                        text: 'Payment status updated successfully!',
                        icon: 'success'
                    }).then(() => {
                        window.location.href = 'payment.php';
                    });
                </script>";
                } else {
                    echo "<script>
                    Swal.fire({
                        title: 'Error!',
                        text: 'Failed to update payment status.',
                        icon: 'error'
                    });
                </script>";
                }
                mysqli_stmt_close($stmt);
            }

            // Fetch payment details
            $query = "SELECT * FROM payments ORDER BY payment_date DESC";
            $result = mysqli_query($conn, $query);
            ?>

            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-200">
                    <thead>
                        <tr class="bg-gray-100 border-b">
                            <th class="p-3 text-left">M_ID</th>
                            <th class="p-3 text-left">MEM_ID</th>
                            <th class="p-3 text-left">Amount</th>
                            <th class="p-3 text-left">Payment Mode</th>
                            <th class="p-3 text-left">Payment Status</th>
                            <th class="p-3 text-left">Payment Date</th>
                            <th class="p-3 text-center">Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr class="border-b">
                                <td class="p-3"><?= htmlspecialchars($row['m_id']) ?></td>
                                <td class="p-3"><?= htmlspecialchars($row['mem_id']) ?></td>
                                <td class="p-3">₱<?= number_format($row['amount'], 2) ?></td>
                                <td class="p-3"><?= htmlspecialchars($row['payment_mode']) ?></td>
                                <td class="p-3">
                                    <span
                                        class="px-2 py-1 text-white rounded 
                                    <?= $row['payment_status'] === 'Completed' ? 'bg-green-500' : ($row['payment_status'] === 'Pending' ? 'bg-yellow-500' : 'bg-red-500') ?>">
                                        <?= htmlspecialchars($row['payment_status']) ?>
                                    </span>
                                </td>
                                <td class="p-3"><?= htmlspecialchars($row['payment_date']) ?></td>
                                <td class="p-3 text-center">
                                    <button
                                        onclick="openEditModal('<?= $row['payment_id'] ?>', '<?= $row['payment_status'] ?>')"
                                        class="text-blue-600 hover:text-blue-800">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Edit Payment Modal -->
    <div id="editModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center">
        <div class="bg-white p-6 rounded shadow-lg w-96">
            <h2 class="text-xl font-bold mb-4">Update Payment Status</h2>
            <form method="POST">
                <input type="hidden" name="payment_id" id="edit_payment_id">

                <label class="block mb-2">Payment Status:</label>
                <select name="payment_status" id="edit_payment_status" class="border p-2 w-full">
                    <option value="Pending">Pending</option>
                    <option value="Completed">Completed</option>
                    <option value="Failed">Failed</option>
                </select>

                <div class="flex justify-end mt-4">
                    <button type="button" onclick="closeEditModal()"
                        class="bg-gray-500 text-white px-4 py-2 rounded mr-2">Cancel</button>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Update</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openEditModal(payment_id, payment_status) {
            document.getElementById('edit_payment_id').value = payment_id;
            document.getElementById('edit_payment_status').value = payment_status;
            document.getElementById('editModal').classList.remove('hidden');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.add('hidden');
        }
    </script>

</body>

</html>