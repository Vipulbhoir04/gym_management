<?php
include '../connection/connection.php'; // Database connection
include("../main/layout/sidebar.php"); // Include sidebar

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Generate a new img_id (IMG00001, IMG00002, ...)
    $query = "SELECT img_id FROM gallery ORDER BY img_id DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $last_id = intval(substr($row['img_id'], 3)); // Extract number part
        $new_id = 'IMG' . str_pad($last_id + 1, 5, '0', STR_PAD_LEFT);
    } else {
        $new_id = 'IMG00001';
    }

    $image_name = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $upload_dir = "../img/uploads/"; // Updated path

    // Ensure the directory exists
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Generate a unique filename to avoid conflicts
    $image_path = $upload_dir . time() . "_" . basename($image_name);
    $db_image_path = "img/uploads/" . time() . "_" . basename($image_name); // Relative path for DB

    if (move_uploaded_file($image_tmp, $image_path)) {
        $uploaded_by = "AS00001"; // Replace with session value of logged-in admin's `as_id`

        $insert_query = "INSERT INTO gallery (img_id, image_name, image_path, uploaded_by) 
                         VALUES ('$new_id', '$image_name', '$db_image_path', '$uploaded_by')";

        if (mysqli_query($conn, $insert_query)) {
            echo "<script>alert('Image uploaded successfully!');</script>";
        } else {
            echo "<script>alert('Error uploading image!');</script>";
        }
    } else {
        echo "<script>alert('Failed to move the uploaded file.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Image</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex">
    <!-- Wrapper for the content to push it right of the sidebar -->
    <div class="flex-grow flex justify-center items-center min-h-screen ml-64 p-4">
        <div class="max-w-lg w-full bg-white p-8 rounded-lg shadow-lg text-center">
            <h2 class="text-2xl font-semibold text-gray-700 mb-4">Upload Image</h2>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="mb-4 text-left">
                    <label for="image" class="block text-sm font-medium text-gray-700">Select Image:</label>
                    <input type="file" name="image" id="image"
                        class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-300"
                        required>
                </div>
                <button type="submit"
                    class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition">Upload</button>
            </form>
        </div>
    </div>
</body>


</html>