<?php
include '../connection/connection.php';

// Fetch the highest user_id numerically
$query_max_id = "SELECT MAX(CAST(SUBSTRING(user_id, 2) AS UNSIGNED)) AS max_id FROM users";
$result_max_id = $conn->query($query_max_id);
$row_max_id = $result_max_id->fetch_assoc();

$next_id = $row_max_id['max_id'] ? $row_max_id['max_id'] + 1 : 1;
$new_user_id = "U" . str_pad($next_id, 5, "0", STR_PAD_LEFT);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    // Server-side password validation
    if (strlen($password) < 8) {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: 'Error!',
                        text: 'Password must be at least 8 characters long.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                });
              </script>";
    } else {
        // Insert into users table
        $stmt = $conn->prepare("INSERT INTO users (user_id, username, email, psswd) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $new_user_id, $username, $email, $password);

        if ($stmt->execute()) {
            echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Success!',
                            text: 'User added successfully with User ID: $new_user_id',
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(() => {
                            window.location.href = 'view_users.php';
                        });
                    });
                  </script>";
        } else {
            echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            title: 'Error!',
                            text: 'Something went wrong. Please try again.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    });
                  </script>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert2 -->
</head>

<body class="flex">
    <!-- Sidebar -->
    <?php include("../main/layout/sidebar.php"); ?>

    <!-- Main Content -->
    <main class="flex-1 p-10" style="padding-left:250px; padding-top: 100px;">
        <div class="max-w-lg mx-auto bg-white p-8 rounded shadow">
            <h2 class="text-2xl font-bold text-center mb-6">Add User</h2>
            <form action="" method="POST" onsubmit="return validateForm()">
                <div class="mb-4">
                    <label class="block text-gray-700">Username</label>
                    <input type="text" name="username" required class="w-full p-2 border rounded">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">Email</label>
                    <input type="email" name="email" required class="w-full p-2 border rounded">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">Password</label>
                    <div class="relative">
                        <input type="password" name="password" id="password" required
                            class="w-full p-2 border rounded pr-10">
                        <button type="button" id="togglePassword"
                            class="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500">
                            <i id="eyeIcon" class="fas fa-eye-slash text-black"></i>
                        </button>
                    </div>
                    <small id="passwordError" class="text-red-500 hidden">Password must be at least 8 characters long.</small>
                </div>

                <div class="text-center">
                    <button type="submit" class="bg-green-500 text-white px-6 py-2 rounded">Add User</button>
                </div>
            </form>
        </div>
    </main>

    <script>
        // Toggle Password Visibility
        document.getElementById("togglePassword").addEventListener("click", function () {
            let passwordInput = document.getElementById("password");
            let eyeIcon = document.getElementById("eyeIcon");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                eyeIcon.classList.replace("fa-eye-slash", "fa-eye");
            } else {
                passwordInput.type = "password";
                eyeIcon.classList.replace("fa-eye", "fa-eye-slash");
            }
        });

        // Client-side Password Validation
        function validateForm() {
            let password = document.getElementById("password").value;
            let errorText = document.getElementById("passwordError");

            if (password.length < 8) {
                errorText.classList.remove("hidden");
                return false; // Prevent form submission
            } else {
                errorText.classList.add("hidden");
                return true;
            }
        }
    </script>
</body>

</html>
