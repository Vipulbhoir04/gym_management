<?php
// Database connection
include '../connection/connection.php';

// Function to generate the next `n_id`
function generateNotificationID($conn)
{
    $query = "SELECT n_id FROM notification ORDER BY n_id DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_assoc($result)) {
        $lastId = intval(substr($row['n_id'], 1)); // Remove 'N' and get number
        $newId = 'N' . str_pad($lastId + 1, 5, '0', STR_PAD_LEFT);
    } else {
        $newId = 'N00001'; // First entry
    }
    return $newId;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $notification = mysqli_real_escape_string($conn, $_POST['notification']);
    $date = date("Y-m-d"); // Auto-set to today's date
    $n_id = generateNotificationID($conn); // Get new ID

    // Insert into database
    $query = "INSERT INTO notification (n_id, notification, date) VALUES ('$n_id', '$notification', '$date')";
    if (mysqli_query($conn, $query)) {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: 'Notification sent successfully.',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        window.location.href = 'view_notifications.php';
                    });
                });
              </script>";
    } else {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: '" . mysqli_error($conn) . "'
                    });
                });
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Notification</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <?php include("../main/layout/sidebar.php"); ?>

    <main class="flex-1 p-10" style="padding-left: 250px; padding-top: 100px;">
        <div class="max-w-lg mx-auto bg-white p-8 rounded shadow">
            <h2 class="text-2xl font-bold text-center mb-6">Send Notification</h2>

            <form method="POST" action="">
                <div class="mb-4">
                    <label class="block text-gray-700">Notification Message</label>
                    <textarea name="notification" required class="w-full p-2 border border-gray-300 rounded-lg"
                        rows="4"></textarea>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700">Date</label>
                    <input type="text" value="<?php echo date('Y-m-d'); ?>" disabled
                        class="w-full p-2 border border-gray-300 rounded-lg bg-gray-100">
                </div>
                <div class="text-center">
                    <button type="submit"
                        class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Send</button>
                </div>
            </form>
        </div>
    </main>

    <script>
        // Toggle Dropdown Menus
        document.querySelectorAll(".dropdown-btn").forEach(button => {
            button.addEventListener("click", () => {
                let submenu = button.nextElementSibling;
                submenu.style.display = submenu.style.display === "block" ? "none" : "block";
            });
        });

        // Sidebar Toggle
        const sidebar = document.getElementById("sidebar");
        const menuToggle = document.getElementById("menu-toggle");

        menuToggle.addEventListener("click", () => {
            sidebar.classList.toggle("open");
        });

        // Close sidebar if clicked outside (for mobile)
        document.addEventListener("click", (event) => {
            if (!sidebar.contains(event.target) && !menuToggle.contains(event.target) && window.innerWidth <= 768) {
                sidebar.classList.remove("open");
            }
        });
    </script>

</body>

</html>