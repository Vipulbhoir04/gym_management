<?php
// Include the database connection file
include('../connection/connection.php');

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    $result = $conn->query("SELECT email FROM users WHERE user_id = '$user_id'");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(['email' => $row['email']]);
    } else {
        echo json_encode(['email' => '']);
    }
}

$conn->close();
?>
