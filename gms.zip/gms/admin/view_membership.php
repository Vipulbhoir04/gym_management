<?php
session_start();
include "../connection/connection.php";

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Handle delete membership
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_query = "DELETE FROM membership WHERE mem_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("s", $delete_id);
    if ($stmt->execute()) {
        header("Location: view_membership.php");
        exit();
    }
}

// Handle toggle status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mem_id']) && isset($_POST['status'])) {
    $mem_id = $_POST['mem_id'];
    $status = $_POST['status'];

    $update_query = "UPDATE membership SET status = ? WHERE mem_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ss", $status, $mem_id);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }
    exit();
}

// Update memberships where the end_date is today
$sql_update = "UPDATE membership SET status = 'Inactive' WHERE end_date = CURDATE() AND status != 'Inactive'";
$conn->query($sql_update);

// Fetch membership data
$filter = isset($_GET['type']) ? $_GET['type'] : 'All';
$query = "SELECT * FROM membership";
if ($filter !== 'All') {
    $query .= " WHERE type = ?";
}
$stmt = $conn->prepare($query);
if ($filter !== 'All') {
    $stmt->bind_param("s", $filter);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Memberships</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <?php include "../main/layout/sidebar.php"; ?>

    <!-- Main Content -->
    <div class="flex justify-center items-start w-full pt-10 ml-64">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-5xl">
            <h2 class="text-2xl font-bold mb-4 text-center">View Memberships</h2>

            <!-- Filter Dropdown -->
            <div class="mb-4">
                <label class="block text-gray-700">Filter by Type:</label>
                <select id="filter" class="w-full px-4 py-2 border rounded-lg" onchange="filterMemberships()">
                    <option value="All" <?= $filter === 'All' ? 'selected' : '' ?>>All</option>
                    <option value="REGULAR" <?= $filter === 'REGULAR' ? 'selected' : '' ?>>Regular</option>
                    <option value="SEASONAL" <?= $filter === 'SEASONAL' ? 'selected' : '' ?>>Seasonal</option>
                    <option value="OTHER" <?= $filter === 'OTHER' ? 'selected' : '' ?>>Other</option>
                </select>
            </div>

            <!-- Membership Table -->
            <div class="overflow-x-auto">
                <table class="w-full bg-white shadow-md rounded-lg overflow-hidden">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="px-4 py-2">Title</th>
                            <th class="px-4 py-2">Type</th>
                            <th class="px-4 py-2">Price</th>
                            <th class="px-4 py-2">Duration</th>
                            <th class="px-4 py-2">Discount</th>
                            <th class="px-4 py-2 text-center">Status</th>
                            <th class="px-4 py-2 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr class="border-b">
                                <td class="px-4 py-2 text-center"> <?= $row['title'] ?> </td>
                                <td class="px-4 py-2 text-center"> <?= $row['type'] ?> </td>
                                <td class="px-4 py-2 text-center"> <?= $row['price'] ?> </td>
                                <td class="px-4 py-2 text-center"> <?= $row['duration'] ?> </td>
                                <td class="px-4 py-2 text-center"> <?= $row['discount'] ?> </td>
                                <td class="px-4 py-2 text-center">
                                    <label class="flex items-center justify-center cursor-pointer">
                                        <input type="checkbox" class="hidden"
                                            onchange="toggleStatus('<?= $row['mem_id'] ?>', this.checked)"
                                            <?= $row['status'] === 'Active' ? 'checked' : '' ?>>
                                        <span
                                            class="relative w-10 h-5 flex items-center bg-gray-300 rounded-full p-1 transition duration-300 ease-in-out <?= $row['status'] === 'Active' ? 'bg-green-500' : '' ?>">
                                            <span
                                                class="absolute left-1 w-4 h-4 bg-white rounded-full shadow-md transform transition duration-300 ease-in-out <?= $row['status'] === 'Active' ? 'translate-x-5' : '' ?>"></span>
                                        </span>
                                    </label>
                                </td>
                                <td class="px-4 py-2 flex justify-center space-x-2">
                                    <button
                                        onclick="openUpdateModal('<?= $row['mem_id'] ?>', '<?= $row['price'] ?>', '<?= $row['duration'] ?>', '<?= $row['duration_type'] ?>', '<?= $row['description'] ?>', '<?= $row['discount'] ?>', '<?= $row['start_date'] ?>', '<?= $row['end_date'] ?>', '<?= $row['status'] ?>')"
                                        class="bg-green-500 text-white px-3 py-1 rounded-lg">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="deleteMembership('<?= $row['mem_id'] ?>')"
                                        class="bg-red-500 text-white px-3 py-1 rounded-lg">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        function openUpdateModal(memId, price, duration, durationType, description, discount, startDate, endDate, status) {
            Swal.fire({
                title: 'Update Membership',
                html: `
            <input type="hidden" id="mem_id" value="${memId}">
            <div class="grid grid-cols-2 gap-4">
    <!-- Price & Duration -->
    <div class="flex flex-col">
        <label class="block text-sm text-gray-600">Price:</label>
        <input type="number" id="price" class="swal2-input text-sm" value="${price}" min="0">
    </div>
    <div class="flex flex-col">
        <label class="block text-sm text-gray-600">Duration:</label>
        <input type="number" id="duration" class="swal2-input text-sm" value="${duration}" min="1">
    </div>

    <!-- Duration Type & Discount -->
    <div class="flex flex-col">
        <label class="block text-sm text-gray-600">Duration Type:</label>
        <select id="duration_type" class="swal2-input text-sm">
            <option value="Months" ${durationType === 'Months' ? 'selected' : ''}>Months</option>
            <option value="Days" ${durationType === 'Days' ? 'selected' : ''}>Days</option>
        </select>
    </div>
    <div class="flex flex-col">
        <label class="block text-sm text-gray-600">Discount (%):</label>
        <input type="number" id="discount" class="swal2-input text-sm" value="${discount}" min="0" max="100">
    </div>

    <!-- Start Date & End Date -->
    <div class="flex flex-col">
        <label class="block text-sm text-gray-600">Start Date:</label>
        <input type="date" id="start_date" class="swal2-input text-sm" min="${new Date().toISOString().split('T')[0]}" value="${startDate}">
    </div>
    <div class="flex flex-col">
        <label class="block text-sm text-gray-600">End Date:</label>
        <input type="date" id="end_date" class="swal2-input text-sm" min="${getTomorrowDate()}" value="${endDate}">
    </div>

    <!-- Description & Status -->
    <div class="flex flex-col col-span-2">
        <label class="block text-sm text-gray-600">Description:</label>
        <textarea id="description" class="swal2-textarea text-sm">${description}</textarea>
    </div>
    <div class="flex flex-col col-span-2 ">
        <label class="block text-sm text-gray-600">Status:</label>
        <select id="status" class="swal2-input text-sm">
            <option value="Active" ${status === 'Active' ? 'selected' : ''}>Active</option>
            <option value="Inactive" ${status === 'Inactive' ? 'selected' : ''}>Inactive</option>
        </select>
    </div>
</div>

        `,
                focusConfirm: false,
                showCancelButton: true,
                confirmButtonText: 'Update',
                preConfirm: () => {
                    return {
                        mem_id: document.getElementById('mem_id').value,
                        price: document.getElementById('price').value,
                        duration: document.getElementById('duration').value,
                        duration_type: document.getElementById('duration_type').value,
                        description: document.getElementById('description').value,
                        discount: document.getElementById('discount').value,
                        start_date: document.getElementById('start_date').value,
                        end_date: document.getElementById('end_date').value,
                        status: document.getElementById('status').value
                    };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    updateMembership(result.value);
                }
            });
        }

        // Prevents selecting past or current date for end_date
        function getTomorrowDate() {
            let tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            return tomorrow.toISOString().split('T')[0];
        }

        // Send updated data to server
        function updateMembership(data) {
            fetch('update_membership.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams(data).toString()
            })
                .then(response => response.json())
                .then(response => {
                    if (response.success) {
                        Swal.fire('Updated!', response.message, 'success').then(() => location.reload());
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire('Error!', 'Something went wrong', 'error');
                });
        }
    </script>

    <script>
        function filterMemberships() {
            var type = document.getElementById('filter').value;
            window.location.href = 'view_membership.php?type=' + type;
        }

        function toggleStatus(memId, isChecked) {
            const newStatus = isChecked ? 'Active' : 'Inactive';

            fetch('view_membership.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ mem_id: memId, status: newStatus }).toString()
            })
                .then(response => {
                    if (response.ok) {
                        return response.text();
                    }
                    throw new Error('Status update failed');
                })
                .then(() => {
                    // If status update is successful, update the UI
                    const toggle = document.querySelector(`input[onchange="toggleStatus('${memId}', this.checked)"]`);
                    if (toggle) {
                        toggle.checked = isChecked;
                        toggle.nextElementSibling.classList.toggle("bg-green-500", isChecked);
                        toggle.nextElementSibling.firstElementChild.classList.toggle("translate-x-5", isChecked);
                    }
                })
                .catch(error => {
                    console.error(error);
                    // Revert toggle state if request fails
                    const toggle = document.querySelector(`input[onchange="toggleStatus('${memId}', this.checked)"]`);
                    if (toggle) {
                        toggle.checked = !isChecked;
                    }
                });
        }

        function deleteMembership(memId) {
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'view_membership.php?delete_id=' + memId;
                }
            });
        }

    </script>
</body>

</html>