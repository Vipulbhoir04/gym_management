<?php
session_start();
include "../connection/connection.php";

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Handle delete membership
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_query = "DELETE FROM membership WHERE mem_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("s", $delete_id);
    if ($stmt->execute()) {
        header("Location: view_membership.php");
        exit();
    }
}

// Handle toggle status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mem_id']) && isset($_POST['status'])) {
    $mem_id = $_POST['mem_id'];
    $status = $_POST['status'];
    $update_query = "UPDATE membership SET status = ? WHERE mem_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ss", $status, $mem_id);
    $stmt->execute();
    exit();
}

// Fetch membership data
$filter = isset($_GET['type']) ? $_GET['type'] : 'All';
$query = "SELECT * FROM membership";
if ($filter !== 'All') {
    $query .= " WHERE type = ?";
}
$stmt = $conn->prepare($query);
if ($filter !== 'All') {
    $stmt->bind_param("s", $filter);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Memberships</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
</head>

<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <?php include "../main/layout/sidebar.php"; ?>

    <!-- Main Content -->
    <div class="flex justify-end items-start w-full p-20">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-5xl">
            <h2 class="text-2xl font-bold mb-4">View Memberships</h2>

            <!-- Filter Dropdown -->
            <div class="mb-4">
                <label class="block text-gray-700">Filter by Type:</label>
                <select id="filter" class="w-full px-4 py-2 border rounded-lg" onchange="filterMemberships()">
                    <option value="All" <?= $filter === 'All' ? 'selected' : '' ?>>All</option>
                    <option value="REGULAR" <?= $filter === 'REGULAR' ? 'selected' : '' ?>>Regular</option>
                    <option value="SEASONAL" <?= $filter === 'SEASONAL' ? 'selected' : '' ?>>Seasonal</option>
                    <option value="OTHER" <?= $filter === 'OTHER' ? 'selected' : '' ?>>Other</option>
                </select>
            </div>

            <!-- Membership Table -->
            <div class="overflow-x-auto">
                <table class="w-full bg-white shadow-md rounded-lg overflow-hidden">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="px-4 py-2">Title</th>
                            <th class="px-4 py-2">Type</th>
                            <th class="px-4 py-2">Price</th>
                            <th class="px-4 py-2">Duration</th>
                            <th class="px-4 py-2">Discount</th>
                            <th class="px-4 py-2 text-center">Status</th>
                            <th class="px-4 py-2 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr class="border-b">
                                <td class="px-4 py-2 text-center"> <?= $row['title'] ?> </td>
                                <td class="px-4 py-2 text-center"> <?= $row['type'] ?> </td>
                                <td class="px-4 py-2 text-center"> <?= $row['price'] ?> </td>
                                <td class="px-4 py-2 text-center"> <?= $row['duration'] ?> </td>
                                <td class="px-4 py-2 text-center"> <?= $row['discount'] ?> </td>
                                <td class="px-4 py-2 text-center">
                                    <label class="flex items-center justify-center cursor-pointer">
                                        <input type="checkbox" class="hidden"
                                            onchange="toggleStatus('<?= $row['mem_id'] ?>', this.checked)"
                                            <?= $row['status'] === 'Active' ? 'checked' : '' ?>>
                                        <span
                                            class="relative w-10 h-5 flex items-center bg-gray-300 rounded-full p-1 transition duration-300 ease-in-out <?= $row['status'] === 'Active' ? 'bg-green-500' : '' ?>">
                                            <span
                                                class="absolute left-1 w-4 h-4 bg-white rounded-full shadow-md transform transition duration-300 ease-in-out <?= $row['status'] === 'Active' ? 'translate-x-5' : '' ?>"></span>
                                        </span>
                                    </label>
                                </td>
                                <td class="px-4 py-2 flex justify-center space-x-2">
                                    <a href="update_membership.php?id=<?= $row['mem_id'] ?>"
                                        class="bg-green-500 text-white px-3 py-1 rounded-lg">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button onclick="deleteMembership('<?= $row['mem_id'] ?>')"
                                        class="bg-red-500 text-white px-3 py-1 rounded-lg">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function filterMemberships() {
            var type = document.getElementById('filter').value;
            window.location.href = 'view_membership.php?type=' + type;
        }

        function toggleStatus(memId, isChecked) {
            let status = isChecked ? 'Active' : 'Inactive';
            fetch('view_membership.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'mem_id=' + memId + '&status=' + status
            }).then(() => location.reload());
        }

        function deleteMembership(memId) {
            if (confirm("Are you sure you want to delete this membership?")) {
                window.location.href = 'view_membership.php?delete_id=' + memId;
            }
        }
    </script>
</body>

</html>