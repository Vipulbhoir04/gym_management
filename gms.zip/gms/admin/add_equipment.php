<?php
include '../connection/connection.php';

// Fetch the next e_id
$query_max_id = "SELECT MAX(CAST(SUBSTRING(e_id, 6) AS UNSIGNED)) AS max_id FROM equipment";
$result_max_id = $conn->query($query_max_id);
$row_max_id = $result_max_id->fetch_assoc();
$new_e_id = "E" . str_pad($row_max_id['max_id'] + 1, 5, "0", STR_PAD_LEFT);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $description = trim($_POST["description"]);
    $date_of_purchase = trim($_POST["date_of_purchase"]);
    $quantity = (int) trim($_POST["quantity"]);
    $cost_per_item = (float) trim($_POST["cost_per_item"]);
    $total_amount = $quantity * $cost_per_item;

    // Insert into equipment table
    $stmt = $conn->prepare("INSERT INTO equipment (e_id, name, description, date_of_purchase, quantity, total_amount) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssii", $new_e_id, $name, $description, $date_of_purchase, $quantity, $total_amount);

    if ($stmt->execute()) {
        $success_message = "Equipment added successfully with ID: " . $new_e_id;
        header("Location: admin_dashboard.php?success=" . urlencode($success_message));
        exit();
    } else {
        $error_message = "Something went wrong. Please try again.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Equipment</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            text-align: center;
        }
    </style>
</head>

<body class="flex">
    <!-- Sidebar -->
    <?php include '../main/layout/sidebar.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 p-10" style="padding-left: 250px;">
        <div class="max-w-lg mx-auto bg-white p-8 rounded shadow">
            <h2 class="text-2xl font-bold text-center mb-6">Add Equipment</h2>

            <?php if (isset($error_message)): ?>
                <div class="bg-red-500 text-white p-3 rounded mb-4 text-center">
                    <?= $error_message; ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <div class="mb-4">
                    <label class="block text-gray-700">Name</label>
                    <input type="text" name="name" required class="w-full p-2 border rounded">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">Description</label>
                    <textarea name="description" required class="w-full p-2 border rounded"></textarea>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">Date of Purchase</label>
                    <input type="date" name="date_of_purchase" required class="w-full p-2 border rounded">
                </div>

                <!-- Quantity & Cost per Item in One Row -->
                <div class="flex gap-4">
                    <div class="w-1/2">
                        <label class="block text-gray-700">Quantity</label>
                        <input type="number" name="quantity" id="quantity" required class="w-full p-2 border rounded"
                            min="1">
                    </div>

                    <div class="w-1/2">
                        <label class="block text-gray-700">Cost per Item</label>
                        <input type="number" name="cost_per_item" id="cost_per_item" required
                            class="w-full p-2 border rounded" min="0" step="0.01">
                    </div>
                </div>

                <div class="mb-4 mt-4">
                    <label class="block text-gray-700">Total Amount</label>
                    <input type="text" id="total_amount" class="w-full p-2 border rounded bg-gray-100" readonly>
                </div>

                <div class="text-center">
                    <button type="submit" class="bg-green-500 text-white px-6 py-2 rounded">Add Equipment</button>
                </div>
            </form>
        </div>
    </main>

    <script>
        document.getElementById("quantity").addEventListener("input", calculateTotal);
        document.getElementById("cost_per_item").addEventListener("input", calculateTotal);

        function calculateTotal() {
            let quantity = parseInt(document.getElementById("quantity").value) || 0;
            let cost = parseFloat(document.getElementById("cost_per_item").value) || 0;
            document.getElementById("total_amount").value = (quantity * cost).toFixed(2);
        }

        document.querySelectorAll(".dropdown-btn").forEach(button => {
            button.addEventListener("click", () => {
                let submenu = button.nextElementSibling;
                submenu.style.display = submenu.style.display === "block" ? "none" : "block";
            });
        });

        setTimeout(() => {
            let successMessage = document.querySelector(".success-message");
            if (successMessage) successMessage.style.display = "none";
        }, 3000);

        document.addEventListener("DOMContentLoaded", function () {
            let dateInput = document.querySelector('input[name="date_of_purchase"]');

            // Get today's date
            let today = new Date();
            let todayFormatted = today.toISOString().split('T')[0];

            // Calculate the date 3 months ago
            let pastDate = new Date();
            pastDate.setMonth(today.getMonth() - 3);
            let pastFormatted = pastDate.toISOString().split('T')[0];

            // Set the min and max attributes
            dateInput.setAttribute("max", todayFormatted);
            dateInput.setAttribute("min", pastFormatted);
        });

    </script>
</body>

</html>