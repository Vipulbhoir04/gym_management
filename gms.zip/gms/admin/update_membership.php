<?php
session_start();
include "../connection/connection.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mem_id = $_POST['mem_id'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];
    $duration_type = $_POST['duration_type'];
    $description = $_POST['description'];
    $discount = $_POST['discount'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $status = $_POST['status'];

    // Validate dates
    $current_date = date('Y-m-d');
    if ($start_date < $current_date) {
        echo json_encode(['success' => false, 'message' => 'Start date cannot be in the past.']);
        exit();
    }
    if ($end_date <= $current_date) {
        echo json_encode(['success' => false, 'message' => 'End date cannot be today or in the past.']);
        exit();
    }

    // Update query
    $query = "UPDATE membership SET price=?, duration=?, duration_type=?, description=?, discount=?, start_date=?, end_date=?, status=? WHERE mem_id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iississss", $price, $duration, $duration_type, $description, $discount, $start_date, $end_date, $status, $mem_id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Membership updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update membership.']);
    }
    exit();
}
?>
