<?php
include '../connection/connection.php';

// Delete admin functionality
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_query = "DELETE FROM admin_staff WHERE as_id = '$delete_id'";

    if ($conn->query($delete_query) === TRUE) {
        echo "<script>alert('Admin deleted successfully!'); window.location.href='view_admins.php';</script>";
    } else {
        echo "<script>alert('Error deleting admin: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
    </style>
</head>

<body class="bg-gray-100 flex">
    <!-- Sidebar -->
    <?php include("../main/layout/sidebar.php"); ?>

    <!-- Main Content -->
    <main class="flex-1 p-10 ml-64">
        <div class="max-w-4xl mx-auto bg-white p-8 rounded shadow">
            <h2 class="text-2xl font-bold text-center mb-6">Admin/Staff List</h2>

            <div class="overflow-x-auto">
                <table class="w-full border-collapse border border-gray-300">
                    <thead>
                        <tr class="bg-blue-600 text-white">
                            <th class="border border-gray-300 p-3">Name</th>
                            <th class="border border-gray-300 p-3">Contact</th>
                            <th class="border border-gray-300 p-3">Email</th>
                            <th class="border border-gray-300 p-3">Role</th>
                            <th class="border border-gray-300 p-3">User ID</th>
                            <th class="border border-gray-300 p-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT as_id, name, contact, email, role, user_id FROM admin_staff";
                        $result = $conn->query($query);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr class='text-center border border-gray-300'>";
                                echo "<td class='border border-gray-300 p-3'>{$row['name']}</td>";
                                echo "<td class='border border-gray-300 p-3'>{$row['contact']}</td>";
                                echo "<td class='border border-gray-300 p-3'>{$row['email']}</td>";
                                echo "<td class='border border-gray-300 p-3'>{$row['role']}</td>";
                                echo "<td class='border border-gray-300 p-3'>{$row['user_id']}</td>";
                                echo "<td class='border border-gray-300 p-3 flex justify-center gap-2'>";
                                echo "<a href='update_admin.php?id={$row['as_id']}' class='bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600'>
                                    <i class='fas fa-edit'></i> Update
                                  </a>";
                                echo "<a href='view_admins.php?delete_id={$row['as_id']}' class='bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600' onclick='return confirm(\"Are you sure you want to delete this admin?\")'>
                                    <i class='fas fa-trash'></i> Delete
                                  </a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6' class='text-center p-4'>No admins found</td></tr>";
                        }

                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

</body>

</html>