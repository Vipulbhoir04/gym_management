<?php
include '../connection/connection.php';

// Fetch total users count
$user_query = "SELECT COUNT(*) AS total_users FROM users";
$user_result = mysqli_query($conn, $user_query);
$user_data = mysqli_fetch_assoc($user_result);
$total_users = $user_data['total_users'];

// Fetch total members count
$member_query = "SELECT COUNT(*) AS total_members FROM member";
$member_result = mysqli_query($conn, $member_query);
$member_data = mysqli_fetch_assoc($member_result);
$total_members = $member_data['total_members'];

// Fetch total admins count
$admin_query = "SELECT COUNT(*) AS total_admins FROM admin_staff WHERE role = 'Admin'";
$admin_result = mysqli_query($conn, $admin_query);
$admin_data = mysqli_fetch_assoc($admin_result);
$total_admins = $admin_data['total_admins'];

// Fetch total payments sum
$payment_query = "SELECT SUM(amount) AS total_payments FROM payments WHERE payment_status = 'Completed'";
$payment_result = mysqli_query($conn, $payment_query);
$payment_data = mysqli_fetch_assoc($payment_result);
$total_payments = $payment_data['total_payments'] ?? 0; // Default to 0 if no payments found

// Fetch membership data (count per month)
$membership_query = "
    SELECT DATE_FORMAT(start_date, '%Y-%m') AS month, COUNT(*) AS total 
    FROM member 
    GROUP BY month 
    ORDER BY month ASC";
$membership_result = mysqli_query($conn, $membership_query);

$months = [];
$membership_counts = [];

while ($row = mysqli_fetch_assoc($membership_result)) {
    $months[] = $row['month'];
    $membership_counts[] = $row['total'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body class="bg-gray-100 flex">

    <?php include '../main/layout/sidebar.php'; ?>

    <div class="ml-64 md:ml-64 flex flex-col w-full p-6">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Welcome to Admin Dashboard</h1>

        <!-- Dashboard Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <!-- Total Users -->
            <div class="bg-white shadow-md rounded-lg p-6 flex items-center">
                <i class="fas fa-user text-indigo-500 text-3xl mr-4"></i>
                <div>
                    <h2 class="text-xl font-semibold">Total Users</h2>
                    <p class="text-gray-600"><?php echo $total_users; ?></p>
                </div>
            </div>

            <!-- Total Members -->
            <div class="bg-white shadow-md rounded-lg p-6 flex items-center">
                <i class="fas fa-users text-blue-500 text-3xl mr-4"></i>
                <div>
                    <h2 class="text-xl font-semibold">Total Members</h2>
                    <p class="text-gray-600"><?php echo $total_members; ?></p>
                </div>
            </div>

            <!-- Total Admins -->
            <div class="bg-white shadow-md rounded-lg p-6 flex items-center">
                <i class="fas fa-user-shield text-green-500 text-3xl mr-4"></i>
                <div>
                    <h2 class="text-xl font-semibold">Total Admins</h2>
                    <p class="text-gray-600"><?php echo $total_admins; ?></p>
                </div>
            </div>

            <!-- Total Payments -->
            <div class="bg-white shadow-md rounded-lg p-6 flex items-center">
                <i class="fas fa-credit-card text-purple-500 text-3xl mr-4"></i>
                <div>
                    <h2 class="text-xl font-semibold">Total Payments</h2>
                    <p class="text-gray-600">₹<?php echo number_format($total_payments, 2); ?></p>
                </div>
            </div>
        </div>

        <!-- Fetch Attendance Data for Graph -->
        <?php
        $attendance_chart_query = "
    SELECT DATE(check_in) AS date, COUNT(*) AS total 
    FROM attendance 
    GROUP BY date 
    ORDER BY date DESC 
    LIMIT 7";
        $attendance_chart_result = mysqli_query($conn, $attendance_chart_query);

        $attendance_dates = [];
        $attendance_counts = [];

        while ($row = mysqli_fetch_assoc($attendance_chart_result)) {
            $attendance_dates[] = $row['date'];
            $attendance_counts[] = $row['total'];
        }
        ?>

        <!-- Graph Row -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Membership Graph -->
            <div class="bg-white shadow-md rounded-lg p-6">
                <h2 class="text-xl font-semibold mb-4">Monthly Membership Purchases</h2>
                <div class="w-full mx-auto" style="height: 300px;">
                    <canvas id="membershipChart"></canvas>
                </div>
            </div>

            <!-- Attendance Graph -->
            <div class="bg-white shadow-md rounded-lg p-6">
                <h2 class="text-xl font-semibold mb-4">Daily Attendance</h2>
                <div class="w-full mx-auto" style="height: 300px;">
                    <canvas id="attendanceChart"></canvas>
                </div>
            </div>
        </div>

        <script>
            document.addEventListener("DOMContentLoaded", function () {
                // Membership Graph
                const ctx1 = document.getElementById('membershipChart').getContext('2d');
                new Chart(ctx1, {
                    type: 'line',
                    data: {
                        labels: <?php echo json_encode($months); ?>,
                        datasets: [{
                            label: 'Total Memberships',
                            data: <?php echo json_encode($membership_counts); ?>,
                            backgroundColor: 'rgba(54, 162, 235, 0.2)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 2,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: { beginAtZero: true, title: { display: true, text: 'Memberships' } },
                            x: { title: { display: true, text: 'Month' } }
                        }
                    }
                });

                // Attendance Graph
                const ctx2 = document.getElementById('attendanceChart').getContext('2d');
                new Chart(ctx2, {
                    type: 'line',
                    data: {
                        labels: <?php echo json_encode(array_reverse($attendance_dates)); ?>,
                        datasets: [{
                            label: 'Attendance Entries',
                            data: <?php echo json_encode(array_reverse($attendance_counts)); ?>,
                            backgroundColor: 'rgba(255, 99, 132, 0.2)',
                            borderColor: 'rgba(255, 99, 132, 1)',
                            borderWidth: 2,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: { beginAtZero: true, title: { display: true, text: 'Entries' } },
                            x: { title: { display: true, text: 'Date' } }
                        }
                    }
                });
            });
        </script>


        <!-- Quick Navigation Section (Aligned in Same Row) -->
        <div class="flex items-center gap-4 mt-6">
            <h2 class="text-lg font-semibold">Quick Navigation:</h2>
            <div class="flex flex-wrap gap-4">
                <a href="add_admin.php"
                    class="bg-blue-500 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:bg-blue-600">
                    <i class="fas fa-user-shield"></i> Add Admin
                </a>
                <a href="add_instructor.php"
                    class="bg-green-500 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:bg-green-600">
                    <i class="fas fa-chalkboard-teacher"></i> Add Instructor
                </a>
                <a href="add_equipment.php"
                    class="bg-yellow-500 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:bg-yellow-600">
                    <i class="fas fa-dumbbell"></i> Add Equipment
                </a>
                <a href="add_membership.php"
                    class="bg-purple-500 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:bg-purple-600">
                    <i class="fas fa-id-card"></i> Add Membership
                </a>
                <a href="add_image.php"
                    class="bg-red-500 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:bg-red-600">
                    <i class="fas fa-image"></i> Add Image
                </a>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const ctx = document.getElementById('membershipChart').getContext('2d');
            const membershipChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($months); ?>,
                    datasets: [{
                        label: 'Total Memberships',
                        data: <?php echo json_encode($membership_counts); ?>,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 2,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Memberships'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Month'
                            }
                        }
                    }
                }
            });
        });

    </script>

</body>

</html>