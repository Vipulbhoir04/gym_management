<?php
session_start();
include "../connection/connection.php";

// Check if the admin is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Fetch admin details
$user_id = $_SESSION["user_id"];
$query = "SELECT * FROM admin_staff WHERE user_id = ? AND role = 'Admin'";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: home.php"); // Redirect non-admins
    exit();
}

$admin = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
    </style>
</head>

<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <?php include "../main/layout/sidebar.php"; ?>

    <!-- Main Content -->

</body>

</html>