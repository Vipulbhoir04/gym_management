<?php
session_start();
include "../connection/connection.php";

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$deleteSuccess = false;

// Handle delete request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $delete_query = "DELETE FROM instructor WHERE ins_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("s", $delete_id);
    if ($stmt->execute()) {
        $deleteSuccess = true;
    }
}

// Fetch instructor data
$query = "SELECT * FROM instructor";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Instructors</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="bg-gray-100 flex">

    <?php include "../main/layout/sidebar.php"; ?>
    <div class="ml-60 p-8 w-full">
        <div class="flex justify-start items-start w-full min-h-screen p-8 ml-12">
            <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-5xl">
                <h2 class="text-2xl font-bold mb-4 text-center">View Instructors</h2>
                <div class="overflow-x-auto w-full">
                    <table class="w-full bg-white shadow-md rounded-lg overflow-hidden">
                        <thead class="bg-gray-200">
                            <tr>
                                <th class="px-4 py-2">Name</th>
                                <th class="px-4 py-2">Contact</th>
                                <th class="px-4 py-2">Email</th>
                                <th class="px-4 py-2">Specialist</th>
                                <th class="px-4 py-2">Fees</th>
                                <th class="px-4 py-2">Availability</th>
                                <th class="px-4 py-2">Profile Picture</th>
                                <th class="px-4 py-2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr class="border-b text-center">
                                    <td class="px-4 py-2"> <?= $row['name'] ?> </td>
                                    <td class="px-4 py-2"> <?= $row['contact'] ?> </td>
                                    <td class="px-4 py-2"> <?= $row['email'] ?> </td>
                                    <td class="px-4 py-2"> <?= $row['specialist'] ?> </td>
                                    <td class="px-4 py-2"> <?= $row['fees'] ?> </td>
                                    <td class="px-4 py-2"> <?= $row['availability'] ?> </td>
                                    <td class="px-4 py-2">
                                        <img src="../<?= $row['profile_picture'] ?>" alt="Profile"
                                            class="w-12 h-12 rounded-full mx-auto">
                                    </td>
                                    <td class="px-4 py-2">
                                        <button onclick="confirmDelete('<?= $row['ins_id'] ?>')"
                                            class="bg-red-500 text-white px-4 py-2 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-trash-alt mr-2"></i> Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete(insId) {
            Swal.fire({
                title: "Are you sure?",
                text: "You won’t be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    let form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'view_instructors.php';

                    let input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'delete_id';
                    input.value = insId;

                    form.appendChild(input);
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        }

        <?php if ($deleteSuccess): ?>
            document.addEventListener('DOMContentLoaded', function () {
                Swal.fire({
                    icon: "success",
                    title: "Deleted!",
                    text: "Instructor has been deleted successfully.",
                    confirmButtonColor: "#3085d6"
                }).then(() => {
                    window.location.href = "view_instructors.php";
                });
            });
        <?php endif; ?>
    </script>

</body>

</html>