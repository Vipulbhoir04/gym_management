<?php
include '../connection/connection.php';

$type = $_GET['type'] ?? 'Appointment';

if ($type === "Appointment") {
    $sql = "SELECT user_id, name, email, message AS description, NULL AS role FROM appointment ORDER BY app_id DESC";
} elseif ($type === "Job Application") {
    $sql = "SELECT user_id, name, email, description, role FROM application_form ORDER BY form_id DESC";
}

$result = mysqli_query($conn, $sql);

$output = "";

// Table headers
if ($type === "Job Application") {
    $output .= "<tr class='bg-gray-200'>
                    <th class='border border-gray-300 px-4 py-2'>User ID</th>
                    <th class='border border-gray-300 px-4 py-2'>Name</th>
                    <th class='border border-gray-300 px-4 py-2'>Email</th>
                    <th class='border border-gray-300 px-4 py-2'>Description</th>
                    <th class='border border-gray-300 px-4 py-2'>Role</th>
                </tr>";
} else {
    $output .= "<tr class='bg-gray-200'>
                    <th class='border border-gray-300 px-4 py-2'>User ID</th>
                    <th class='border border-gray-300 px-4 py-2'>Name</th>
                    <th class='border border-gray-300 px-4 py-2'>Email</th>
                    <th class='border border-gray-300 px-4 py-2'>Description</th>
                </tr>";
}

// Table rows
while ($row = mysqli_fetch_assoc($result)) {
    $output .= "<tr class='text-center bg-white hover:bg-gray-100'>";
    $output .= "<td class='border border-gray-300 px-4 py-2'>" . htmlspecialchars($row['user_id']) . "</td>";
    $output .= "<td class='border border-gray-300 px-4 py-2'>" . htmlspecialchars($row['name']) . "</td>";
    $output .= "<td class='border border-gray-300 px-4 py-2'>" . htmlspecialchars($row['email']) . "</td>";
    $output .= "<td class='border border-gray-300 px-4 py-2'>" . htmlspecialchars($row['description']) . "</td>";

    if ($type === "Job Application") {
        $output .= "<td class='border border-gray-300 px-4 py-2'>" . htmlspecialchars($row['role']) . "</td>";
    }

    $output .= "</tr>";
}

echo $output;
?>