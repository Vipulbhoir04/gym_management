<?php
include '../connection/connection.php'; // Include database connection

$delete_message = ""; // Initialize delete message variable

// Handle Delete Request (POST Method for Security)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $query = "DELETE FROM users WHERE user_id = '$delete_id'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $delete_message = "<div class='bg-green-500 text-white p-3 rounded mb-4 text-center'>User deleted successfully.</div>";
    } else {
        $delete_message = "<div class='bg-red-500 text-white p-3 rounded mb-4 text-center'>Error deleting user. Try again.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
    </style>
</head>

<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <?php include("../main/layout/sidebar.php"); ?>        

    <!-- Main Content -->
    <main class="flex-1 p-10 ml-64">
        <div class="max-w-4xl mx-auto bg-white p-8 rounded shadow">
            <h2 class="text-2xl font-bold text-center mb-6">Users List</h2>

            <!-- Success/Error Message -->
            <?php
            if (!empty($delete_message)) {
                echo $delete_message;
            }
            ?>

            <div class="overflow-x-auto">
                <table class="w-full border-collapse border border-gray-300">
                    <thead>
                        <tr class="bg-blue-600 text-white">
                            <th class="border border-gray-300 p-3">User ID</th>
                            <th class="border border-gray-300 p-3">Username</th>
                            <th class="border border-gray-300 p-3">Email</th>
                            <th class="border border-gray-300 p-3">Password</th>
                            <th class="border border-gray-300 p-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT user_id, username, email, psswd FROM users";
                        $result = $conn->query($query);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr class='text-center border border-gray-300'>";
                                echo "<td class='border border-gray-300 p-3'>{$row['user_id']}</td>";
                                echo "<td class='border border-gray-300 p-3'>{$row['username']}</td>";
                                echo "<td class='border border-gray-300 p-3'>{$row['email']}</td>";
                                echo "<td class='border border-gray-300 p-3'>{$row['psswd']}</td>";
                                echo "<td class='border border-gray-300 p-3 flex justify-center gap-2'>";
                                // Delete Form (Post Method)
                                echo "<form method='POST' onsubmit='return confirm(\"Are you sure you want to delete this user?\")'>";
                                echo "<input type='hidden' name='delete_id' value='{$row['user_id']}'>";
                                echo "<button type='submit' class='bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600'>
                                        <i class='fas fa-trash'></i> Delete
                                      </button>";
                                echo "</form>";

                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center p-4'>No users found</td></tr>";
                        }

                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>


    <script>
        // Toggle Dropdown Menus
        document.querySelectorAll(".dropdown-btn").forEach(button => {
            button.addEventListener("click", () => {
                let submenu = button.nextElementSibling;
                submenu.style.display = submenu.style.display === "block" ? "none" : "block";
            });
        });
    </script>

</body>

</html>