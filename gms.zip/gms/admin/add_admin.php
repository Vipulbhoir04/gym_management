<?php
include '../connection/connection.php';

$success_message = "";

// Fetch available users (not in admin_staff, member, or instructor)
$query = "SELECT user_id, email FROM users WHERE user_id NOT IN (
            SELECT user_id FROM admin_staff 
            UNION 
            SELECT user_id FROM member 
            UNION 
            SELECT user_id FROM instructor
          )";
$result = $conn->query($query);

// Fetch the next admin ID
$query_max_id = "SELECT MAX(CAST(SUBSTRING(as_id, 6) AS UNSIGNED)) AS max_id FROM admin_staff";
$result_max_id = $conn->query($query_max_id);
$row_max_id = $result_max_id->fetch_assoc();
$new_as_id = "AS" . str_pad($row_max_id['max_id'] + 1, 5, "0", STR_PAD_LEFT);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST["user_id"];
    $name = trim($_POST["name"]);
    $contact = trim($_POST["contact"]);
    $role = $_POST["role"];

    // Fetch email based on user_id
    $stmt = $conn->prepare("SELECT email FROM users WHERE user_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $stmt->bind_result($email);
    $stmt->fetch();
    $stmt->close();

    // Insert into admin_staff
    $stmt = $conn->prepare("INSERT INTO admin_staff (as_id, name, contact, email, role, user_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $new_as_id, $name, $contact, $email, $role, $user_id);

    if ($stmt->execute()) {
        $success_message = $role === "Admin" ? "Admin added successfully!" : "Staff added successfully!";
        echo "<script>
                setTimeout(function() {
                    window.location.href = 'admin_dashboard.php';
                }, 3000);
              </script>";
    } else {
        $success_message = "Something went wrong. Please try again.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            text-align: center;
        }
    </style>
</head>

<body class="flex">

    <!-- Sidebar -->
    <?php include("../main/layout/sidebar.php"); ?>

    <!-- Main Content -->
    <main class="flex-1 p-10" style="padding-left:250px;">
        <div class="max-w-lg mx-auto bg-white p-8 rounded shadow" >
            <h2 class="text-2xl font-bold text-center mb-6">Add Admin</h2>

            <?php if ($success_message): ?>
                <div class="success-message"><?= $success_message; ?></div>
            <?php endif; ?>

            <form action="" method="POST">
                <div class="mb-4">
                    <label class="block text-gray-700">User ID</label>
                    <select name="user_id" id="user_id" required class="w-full p-2 border rounded">
                        <option value="">Select User</option>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <option value="<?= $row['user_id']; ?>" data-email="<?= $row['email']; ?>">
                                <?= $row['user_id']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">Email</label>
                    <input type="email" id="email" name="email" readonly required
                        class="w-full p-2 border rounded bg-gray-100">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">Full Name</label>
                    <input type="text" name="name" required class="w-full p-2 border rounded">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">Contact</label>
                    <input type="text" name="contact" required class="w-full p-2 border rounded">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">Role</label>
                    <select name="role" required class="w-full p-2 border rounded">
                        <option value="Admin">Admin</option>
                        <option value="Staff">Staff</option>
                    </select>
                </div>

                <div class="text-center">
                    <button type="submit" class="bg-green-500 text-white px-6 py-2 rounded">Add Admin</button>
                </div>
            </form>
        </div>
    </main>

</body>

</html>