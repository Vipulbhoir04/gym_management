<?php
session_start();
include "../connection/connection.php";

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $specialist = $_POST['specialist'];
    $fees = $_POST['fees'];
    $availability = $_POST['availability'];
    $qualifications = $_POST['qualifications'];
    $experience = $_POST['experience'];
    $user_id = $_POST['user_id'];

    // Auto-generate instructor ID
    $query = "SELECT MAX(CAST(SUBSTRING(ins_id, 2) AS UNSIGNED)) AS max_id FROM instructor";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    $next_id = $row['max_id'] ? $row['max_id'] + 1 : 1;
    $ins_id = "I" . str_pad($next_id, 5, "0", STR_PAD_LEFT);


    // Handle file upload
    $profile_picture = "";
    if (!empty($_FILES['profile_picture']['name'])) {
        $target_dir = "../img/instructorsprofile/";
        $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
        move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file);
        $profile_picture = "img/instructorsprofile/" . basename($_FILES["profile_picture"]["name"]);
    }

    // Insert instructor into database
    $stmt = $conn->prepare("INSERT INTO instructor (ins_id, name, contact, email, specialist, fees, availability, qualifications, experience, profile_picture, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssss", $ins_id, $name, $contact, $email, $specialist, $fees, $availability, $qualifications, $experience, $profile_picture, $user_id);

    if ($stmt->execute()) {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: 'Instructor added successfully!',
                    confirmButtonColor: '#3085d6'
                }).then(() => {
                    window.location.href = 'view_instructors.php';
                });
            });
        </script>";
    } else {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Error adding instructor.',
                    confirmButtonColor: '#d33'
                });
            });
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Instructor</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function fetchEmail(userId) {
            let emailField = document.getElementById('email');
            let selectedOption = document.querySelector(`option[value='${userId}']`);
            emailField.value = selectedOption.getAttribute('data-email');
        }
    </script>
</head>

<body class="bg-gray-100 flex">

    <?php include "../main/layout/sidebar.php"; ?>
    </div>
    <div class="ml-64 p-8 w-full">
        <div class="flex justify-center items-center w-full p-8">
            <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-lg">
                <h2 class="text-2xl font-bold mb-4">Add Instructor</h2>
                <form action="add_instructor.php" method="POST" enctype="multipart/form-data">
                    <label class="block">Select User:</label>
                    <select name="user_id" class="w-full mb-2 p-2 border rounded" required
                        onchange="fetchEmail(this.value)">
                        <option value="" disabled selected>Select User</option>
                        <?php
                        $user_query = "SELECT user_id, email FROM users WHERE user_id NOT IN (
                        SELECT user_id FROM member 
                        UNION 
                        SELECT user_id FROM instructor 
                        UNION 
                        SELECT user_id FROM admin_staff
                    )";
                        $user_result = $conn->query($user_query);
                        while ($user = $user_result->fetch_assoc()) {
                            echo "<option value='{$user['user_id']}' data-email='{$user['email']}'>{$user['user_id']}</option>";
                        }
                        ?>
                    </select>
                    <input type="email" id="email" name="email" class="w-full mb-2 p-2 border rounded"
                        placeholder="Email" readonly required>
                    <input type="text" name="name" class="w-full mb-2 p-2 border rounded" placeholder="Name" required>
                    <input type="text" name="contact" class="w-full mb-2 p-2 border rounded" placeholder="Contact"
                        required>
                    <input type="text" name="specialist" class="w-full mb-2 p-2 border rounded" placeholder="Specialist"
                        required>
                    <input type="text" name="fees" class="w-full mb-2 p-2 border rounded" placeholder="Fees" required>
                    <input type="text" name="availability" class="w-full mb-2 p-2 border rounded"
                        placeholder="Availability" required>
                    <input type="text" name="qualifications" class="w-full mb-2 p-2 border rounded"
                        placeholder="Qualifications in years" required>
                    <input type="text" name="experience" class="w-full mb-2 p-2 border rounded" placeholder="Experience"
                        required>
                    <label class="block">Profile Picture:</label>
                    <input type="file" name="profile_picture" class="w-full mb-2 p-2 border rounded" required>
                    <button type="submit" class="w-full bg-blue-500 text-white px-4 py-2 rounded">Add
                        Instructor</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>