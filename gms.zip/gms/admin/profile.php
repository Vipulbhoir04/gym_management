<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Update</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.tailwindcss.com">
</head>
<body>

<?php
session_start();
include '../main/layout/sidebar.php';
include '../connection/connection.php'; // Database connection

// Ensure admin is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch admin details
$query = "SELECT as_id, name, contact, email, role FROM admin_staff WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$stmt->close();

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $as_id = $_POST['as_id'];
    
    $update_query = "UPDATE admin_staff SET name = ?, contact = ?, email = ? WHERE as_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ssss", $name, $contact, $email, $as_id);
    if ($stmt->execute()) {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Profile Updated Successfully!',
                    showConfirmButton: false,
                    timer: 1500
                }).then(() => {
                    window.location.href='profile.php';
                });
            });
        </script>";
    } else {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Failed to Update Profile!',
                    text: 'Please try again later.'
                });
            });
        </script>";
    }
    $stmt->close();
}
$conn->close();
?>

<div class="ml-64 p-8 w-full flex flex-col items-center bg-gray-100 min-h-screen">
    <h2 class="text-3xl font-bold mb-6 text-blue-900">Admin Profile</h2>
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg">
        <p class="text-lg"><strong>ID:</strong> <?php echo htmlspecialchars($admin['as_id']); ?></p>
        <p class="text-lg"><strong>Name:</strong> <?php echo htmlspecialchars($admin['name']); ?></p>
        <p class="text-lg"><strong>Contact:</strong> <?php echo htmlspecialchars($admin['contact']); ?></p>
        <p class="text-lg"><strong>Email:</strong> <?php echo htmlspecialchars($admin['email']); ?></p>
        <p class="text-lg"><strong>Role:</strong> <?php echo htmlspecialchars($admin['role']); ?></p>
        
        <!-- Update Button -->
        <button id="updateBtn" class="mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Update</button>
    </div>
</div>

<!-- Update Modal -->
<div id="updateModal" class="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50 hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-xl font-bold mb-4">Update Profile</h2>
        <form action="" method="POST">
            <input type="hidden" name="as_id" value="<?php echo htmlspecialchars($admin['as_id']); ?>">
            <div class="mb-4">
                <label class="block text-sm font-medium">Name</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($admin['name']); ?>" class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Contact</label>
                <input type="text" name="contact" value="<?php echo htmlspecialchars($admin['contact']); ?>" class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Email</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div class="flex justify-end">
                <button type="button" id="closeModal" class="mr-2 px-4 py-2 bg-gray-500 text-white rounded-lg">Cancel</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
    document.getElementById("updateBtn").addEventListener("click", function() {
        document.getElementById("updateModal").classList.remove("hidden");
    });
    
    document.getElementById("closeModal").addEventListener("click", function() {
        document.getElementById("updateModal").classList.add("hidden");
    });
</script>

</body>
</html>
