<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Applications</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        function fetchData(type) {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_applications.php?type=" + type, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.getElementById("table-data").innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        }

        // Fetch appointments by default when page loads
        window.onload = function () {
            fetchData('Appointment');
        };
    </script>
</head>

<body class="bg-gray-100">
    <!-- Sidebar -->
    <?php include '../main/layout/sidebar.php'; ?>

    <div class="p-6 sm:ml-64">
        <div class="bg-white shadow-lg rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-4">View Applications</h2>

            <!-- Dropdown for selecting table -->
            <div class="mb-4">
                <label class="block text-lg font-medium">Select Type:</label>
                <select onchange="fetchData(this.value)" class="w-64 px-4 py-2 border rounded-lg">
                    <option value="Appointment" selected>Appointment</option>
                    <option value="Job Application">Job Application</option>
                </select>
            </div>

            <table class="w-full border-collapse border border-gray-300">
                <thead id="table-header"></thead>
                <tbody id="table-data"></tbody>
            </table>
        </div>
    </div>

</body>

</html>