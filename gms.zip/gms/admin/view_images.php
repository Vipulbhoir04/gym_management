<?php
include '../connection/connection.php'; // Database connection

// Handle image deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_image'])) {
    $img_id = $_POST['img_id'];

    // Fetch the image path
    $query = "SELECT image_path FROM gallery WHERE img_id = '$img_id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $image_path = "../" . $row['image_path']; // Full path

        // Delete image file from server
        if (file_exists($image_path)) {
            unlink($image_path);
        }

        // Delete record from database
        $delete_query = "DELETE FROM gallery WHERE img_id = '$img_id'";
        if (mysqli_query($conn, $delete_query)) {
            echo "<script>alert('Image deleted successfully!'); window.location.href='view_images.php';</script>";
        } else {
            echo "<script>alert('Error deleting image!');</script>";
        }
    } else {
        echo "<script>alert('Image not found!');</script>";
    }
}

// Fetch images from the gallery table
$query = "SELECT img_id, image_path, image_name FROM gallery ORDER BY img_id DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Images</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex">
    <?php 
    include("../main/layout/sidebar.php"); 
    ?>
    <!-- Main content wrapper to adjust for sidebar -->
    <div class="flex-grow ml-64 p-6">
        <h2 class="text-2xl font-semibold text-gray-700 mb-6 text-center">Uploaded Images</h2>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <div class="bg-white shadow-lg rounded-lg overflow-hidden relative">
                        <img src="../<?php echo $row['image_path']; ?>" alt="<?php echo $row['image_name']; ?>"
                            class="w-full h-48 object-cover">
                        <div class="p-4">
                            <p class="text-center text-gray-700 font-medium truncate"><?php echo $row['image_name']; ?></p>
                        </div>

                        <!-- Delete Button -->
                        <form method="post" class="absolute top-2 right-2">
                            <input type="hidden" name="img_id" value="<?php echo $row['img_id']; ?>">
                            <button type="submit" name="delete_image"
                                class="bg-red-600 hover:bg-red-700 text-white p-2 rounded-full transition">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                                    class="w-5 h-5">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </form>

                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-center text-gray-600">No images uploaded yet.</p>
        <?php endif; ?>

    </div>
</body>

</html>