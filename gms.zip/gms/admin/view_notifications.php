<?php
session_start();
include '../connection/connection.php';

// Check if the admin is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Fetch admin details
$user_id = $_SESSION["user_id"];
$query = "SELECT * FROM admin_staff WHERE user_id = ? AND role = 'Admin'";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: home.php"); // Redirect non-admins
    exit();
}

// Fetch notifications
$notif_query = "SELECT * FROM notification ORDER BY date DESC";
$notif_result = $conn->query($notif_query);

// Delete notification
$success_message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $delete_query = "DELETE FROM notification WHERE n_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("s", $delete_id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Notification deleted successfully!";
        header("Location: view_notifications.php"); // Redirect to refresh the page
        exit();
    } else {
        $_SESSION['success_message'] = "Error deleting notification!";
        header("Location: view_notifications.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
    </style>
</head>

<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <?php include("../main/layout/sidebar.php"); ?>

    <!--Main Content-->
    <main class="flex-1 p-10 ml-64">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-4">View Notifications</h2>

            <!-- Display success message -->
            <?php if (isset($_SESSION['success_message'])) { ?>
                <div class="bg-green-500 text-white p-3 rounded-lg mb-4">
                    <?php
                    echo $_SESSION['success_message'];
                    unset($_SESSION['success_message']); // Clear message after displaying
                    ?>
                </div>
            <?php } ?>

            <table class="w-full border-collapse border border-gray-200">
                <thead>
                    <tr class="bg-blue-600 text-white">
                        <th class="p-3 border border-gray-300">Notification</th>
                        <th class="p-3 border border-gray-300">Date</th>
                        <th class="p-3 border border-gray-300">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $notif_result->fetch_assoc()) { ?>
                        <tr class="odd:bg-gray-100 even:bg-white hover:bg-gray-200 text-center">
                            <td class="p-3 border border-gray-300"> <?php echo $row['notification']; ?> </td>
                            <td class="p-3 border border-gray-300"> <?php echo $row['date']; ?> </td>
                            <td class="p-3 border border-gray-300 flex justify-center gap-2">
                                <a href="update_notification.php?n_id=<?php echo $row['n_id']; ?>"
                                    class="bg-green-500 text-white px-3 py-1 rounded-lg flex items-center gap-1 hover:bg-green-600">
                                    <i class="fas fa-edit"></i> Update
                                </a>
                                <form method="POST">
                                    <input type="hidden" name="delete_id" value="<?php echo $row['n_id']; ?>">
                                    <button type="submit"
                                        class="bg-red-500 text-white px-3 py-1 rounded-lg flex items-center gap-1 hover:bg-red-600">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </main>

</body>

</html>