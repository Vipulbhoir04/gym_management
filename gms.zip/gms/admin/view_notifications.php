<?php
session_start();
include '../connection/connection.php';

// Check if the admin is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Fetch notifications
$notif_query = "SELECT * FROM notification ORDER BY date DESC";
$notif_result = $conn->query($notif_query);

// Delete notification
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $delete_query = "DELETE FROM notification WHERE n_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("s", $delete_id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Notification deleted successfully!";
    } else {
        $_SESSION['success_message'] = "Error deleting notification!";
    }
    header("Location: view_notifications.php"); // Redirect to refresh the page
    exit();
}

// Update notification
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_id'])) {
    $update_id = $_POST['update_id'];
    $new_message = $_POST['new_message'];
    $update_query = "UPDATE notification SET notification = ? WHERE n_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ss", $new_message, $update_id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Notification updated successfully!";
    } else {
        $_SESSION['success_message'] = "Error updating notification!";
    }
    header("Location: view_notifications.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <?php include("../main/layout/sidebar.php"); ?>

    <!-- Main Content -->
    <main class="flex-1 p-10 ml-64">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-4">View Notifications</h2>

            <!-- Display success message using SweetAlert2 -->
            <?php if (isset($_SESSION['success_message'])) { ?>
                <script>
                    Swal.fire({
                        icon: '<?php echo (strpos($_SESSION["success_message"], "Error") !== false) ? "error" : "success"; ?>',
                        title: '<?php echo $_SESSION["success_message"]; ?>',
                        showConfirmButton: false,
                        timer: 2000
                    });
                </script>
                <?php unset($_SESSION['success_message']); ?>
            <?php } ?>

            <table class="w-full border-collapse border border-gray-200">
                <thead>
                    <tr class="bg-blue-600 text-white">
                        <th class="p-3 border border-gray-300">Notification</th>
                        <th class="p-3 border border-gray-300">Date</th>
                        <th class="p-3 border border-gray-300">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $notif_result->fetch_assoc()) { ?>
                        <tr class="odd:bg-gray-100 even:bg-white hover:bg-gray-200 text-center">
                            <td class="p-3 border border-gray-300"> <?php echo $row['notification']; ?> </td>
                            <td class="p-3 border border-gray-300"> <?php echo $row['date']; ?> </td>
                            <td class="p-3 border border-gray-300 flex justify-center gap-2">
                                <!-- Update Button -->
                                <button
                                    onclick="showUpdateModal('<?php echo $row['n_id']; ?>', '<?php echo htmlspecialchars($row['notification'], ENT_QUOTES); ?>')"
                                    class="bg-green-500 text-white px-3 py-1 rounded-lg flex items-center gap-1 hover:bg-green-600">
                                    <i class="fas fa-edit"></i> Update
                                </button>

                                <!-- Delete Button -->
                                <button onclick="confirmDelete('<?php echo $row['n_id']; ?>')"
                                    class="bg-red-500 text-white px-3 py-1 rounded-lg flex items-center gap-1 hover:bg-red-600">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Hidden form for deletion -->
    <form id="deleteForm" method="POST">
        <input type="hidden" name="delete_id" id="delete_id">
    </form>

    <!-- Hidden form for update -->
    <form id="updateForm" method="POST">
        <input type="hidden" name="update_id" id="update_id">
        <input type="hidden" name="new_message" id="new_message">
    </form>

    <script>
        // Confirm Delete with SweetAlert2
        function confirmDelete(deleteId) {
            Swal.fire({
                title: "Are you sure?",
                text: "This action cannot be undone!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete_id').value = deleteId;
                    document.getElementById('deleteForm').submit();
                }
            });
        }

        // Show Update Modal
        function showUpdateModal(updateId, currentMessage) {
            Swal.fire({
                title: "Update Notification",
                input: "text",
                inputValue: currentMessage,
                showCancelButton: true,
                confirmButtonText: "Update",
                cancelButtonText: "Cancel",
                preConfirm: (newMessage) => {
                    if (!newMessage) {
                        Swal.showValidationMessage("Notification message cannot be empty");
                    }
                    return newMessage;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('update_id').value = updateId;
                    document.getElementById('new_message').value = result.value;
                    document.getElementById('updateForm').submit();
                }
            });
        }
    </script>

</body>

</html>