<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - THE FITNESS FACTORY</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .fade-in-left {
            opacity: 0;
            transform: translateX(-50px);
            transition: opacity 1s ease-out, transform 1s ease-out;
        }

        .fade-in-left.active {
            opacity: 1;
            transform: translateX(0);
        }

        /* Quotes Animation */
        .quotes {
            font-size: 1.5rem;
            font-weight: bold;
            color: white;
            transition: opacity 1s ease-in-out;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            background-color: white;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            min-width: 150px;
            z-index: 10;
        }

        .dropdown:hover .dropdown-menu {
            display: block;
        }

        /* Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: -250px;
            width: 250px;
            height: 100%;
            background: white;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.2);
            transition: left 0.3s ease-in-out;
            z-index: 50;
            padding-top: 60px;
        }

        .sidebar.open {
            left: 0;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            font-size: 18px;
            text-decoration: none;
            color: black;
        }

        .sidebar a:hover {
            background: #f3f3f3;
        }

        .sidebar .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
        }

        /* Hide sidebar toggle button on large screens */
        @media (min-width: 1024px) {
            .mobile-menu-btn {
                display: none;
            }
        }

        /* Hide navbar on mobile */
        @media (max-width: 1024px) {
            .desktop-nav {
                display: none;
            }
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Fade-in animation
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("active");
                    }
                });
            }, { threshold: 0.5 });

            document.querySelectorAll(".fade-in-left").forEach(element => {
                observer.observe(element);
            });

            // Motivational Quotes
            const quotes = [
                "Train like a beast, look like a beauty.",
                "Every workout is progress, no matter how small.",
                "Push yourself because no one else will do it for you.",
                "Stronger every day, inside and out."
            ];
            let quoteIndex = 0;
            function updateQuote() {
                document.getElementById("quote-text").style.opacity = 0;
                setTimeout(() => {
                    document.getElementById("quote-text").innerText = quotes[quoteIndex];
                    document.getElementById("quote-text").style.opacity = 1;
                    quoteIndex = (quoteIndex + 1) % quotes.length;
                }, 1000);
            }
            setInterval(updateQuote, 3000);
        });

        function toggleSidebar() {
            document.getElementById("sidebar").classList.toggle("open");
        }
    </script>
</head>

<body class="bg-white text-black">

    <header class="bg-white shadow-lg p-5 flex justify-between items-center fixed w-full top-0 z-10">
        <h1 class="text-2xl font-bold text-black">THE FITNESS FACTORY</h1>

        <!-- Hamburger Menu Button (visible on mobile) -->
        <button id="menu-btn" class="md:hidden text-black text-2xl focus:outline-none">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Sidebar (hidden by default) -->
        <div id="mobile-menu"
            class="fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform -translate-x-full transition-transform duration-300 md:hidden">
            <button id="close-btn" class="absolute top-4 right-4 text-2xl text-black">
                <i class="fas fa-times"></i>
            </button>
            <nav class="flex flex-col p-5 space-y-4 mt-10">
                <a href="home.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-home mr-2"></i>Home</a>
                <a href="#about" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-info-circle mr-2"></i>About Us</a>
                <a href="#contact" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-envelope mr-2"></i>Contact</a>
                <a href="#membership" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-user-plus mr-2"></i>Membership</a>
                <a href="#appointment" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-calendar-check mr-2"></i>Appointment</a>
                <a href="#notification.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fa fa-bell mr-2"></i>Notification</a>
                <a href="#feedback" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-comments mr-2"></i>Feedback</a>
                <a href="#team" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-users mr-2"></i>Our Team</a>
                <a href="#gallery" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-images mr-2"></i>Gallery</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="profile.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-user mr-2"></i>Profile</a>
                    <a href="logout.php" class="bg-red-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
                <?php else: ?>
                    <a href="login.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-sign-in-alt mr-2"></i>Log In</a>
                    <a href="register.php" class="bg-green-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-user-plus mr-2"></i>Sign Up</a>
                <?php endif; ?>
            </nav>
        </div>

        <!-- Normal Navbar (Hidden on Mobile) -->
        <nav class="hidden md:flex space-x-10">
            <a href="home.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-home mr-2"></i>Home</a>
            <a href="#about" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-info-circle mr-2"></i>About Us</a>
            <a href="#contact" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-envelope mr-2"></i>Contact</a>
            <a href="#membership" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-user-plus mr-2"></i>Membership</a>
            <div class="relative dropdown">
                <button class="text-black hover:text-gray-600 flex items-center">
                    <i class="fas fa-bars mr-2"></i>More <i class="fas fa-caret-down ml-1"></i>
                </button>
                <div class="dropdown-menu absolute mt-2 w-40 p-2">
                    <a href="#appointment" class="block px-4 py-2 hover:bg-gray-100 flex items-center"><i
                            class="fas fa-calendar-check mr-2"></i>Appointment</a>
                    <a href="#notification" class="block px-4 py-2 hover:bg-gray-100 flex items-center"><i
                            class="fa fa-bell mr-2"></i>Notification</a>
                    <a href="#feedback" class="block px-4 py-2 hover:bg-gray-100 flex items-center"><i
                            class="fas fa-comments mr-2"></i>Feedback</a>
                    <a href="#team" class="block px-4 py-2 hover:bg-gray-100 flex items-center"><i
                            class="fas fa-users mr-2"></i>Our Team</a>
                    <a href="#gallery" class="block px-4 py-2 hover:bg-gray-100 flex items-center"><i
                            class="fas fa-images mr-2"></i>Gallery</a>
                </div>
            </div>
        </nav>

        <!-- Login/Profile Buttons -->
        <div class="hidden md:flex space-x-2">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="profile.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-user mr-2"></i>Profile</a>
                <a href="logout.php" class="bg-red-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
            <?php else: ?>
                <a href="login.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-sign-in-alt mr-2"></i>Log In</a>
                <a href="register.php" class="bg-green-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-user-plus mr-2"></i>Sign Up</a>
            <?php endif; ?>
        </div>
    </header>

    <!-- JavaScript to Toggle Sidebar -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const menuBtn = document.getElementById("menu-btn");
            const closeBtn = document.getElementById("close-btn");
            const mobileMenu = document.getElementById("mobile-menu");

            menuBtn.addEventListener("click", function () {
                mobileMenu.classList.remove("-translate-x-full");
            });

            closeBtn.addEventListener("click", function () {
                mobileMenu.classList.add("-translate-x-full");
            });

            // Close sidebar if user clicks outside it
            window.addEventListener("click", function (e) {
                if (!mobileMenu.contains(e.target) && !menuBtn.contains(e.target)) {
                    mobileMenu.classList.add("-translate-x-full");
                }
            });
        });
    </script>

    <!-- Hero Section with Quotes -->
    <section class="h-screen flex flex-col justify-center items-center text-center px-4 bg-cover bg-center mt-0"
        style="background-image: url('img/hero/hero-2.jpg');">
        <h2 class="text-4xl font-bold mb-4 text-white">Unleash Your Inner Beast</h2>
        <p class="text-lg mb-6 text-white">Join THE FITNESS FACTORY and start your transformation today.</p>
        <p id="quote-text" class="quotes">Train like a beast, look like a beauty.</p>
    </section>

    <!-- Why Choose Us Section -->
    <section id="why-choose-us" class="p-10">
        <h2 class="text-3xl font-bold mb-6 text-center">Why Choose Us?</h2>
        <div class="flex flex-col md:flex-row items-center justify-between">
            <!-- Image on the left -->
            <div class="md:w-1/2 flex justify-center fade-in-left">
                <img src="img/services/services-3.jpg" alt="Why Choose Us" class="rounded-lg shadow-lg w-full max-w-md">
            </div>

            <!-- Text on the right with fade-in effect -->
            <div
                class="md:w-1/2 md:pr-10 opacity-0 transform translate-x-10 transition-opacity transition-transform duration-1000 ease-out fade-in-right">
                <p class="max-w-lg text-lg">
                    At <strong>THE FITNESS FACTORY</strong>, we are more than just a gym—we are a community of fitness
                    enthusiasts committed to helping each other grow and improve. Whether you're a beginner looking
                    for guidance or an experienced athlete aiming to take your fitness to the next level, we have the
                    perfect resources for you.
                    <br><br>
                    Our state-of-the-art facilities, expert trainers, and personalized workout plans ensure that
                    you stay motivated and on track. We offer a variety of classes, including strength training,
                    HIIT, yoga, and personal coaching, to cater to different fitness goals.
                    <br><br>
                    At our gym, you’ll find a supportive environment where discipline, determination, and dedication
                    lead to transformation. Join us today and experience the difference!
                </p>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const fadeInElements = document.querySelectorAll('.fade-in-left, .fade-in-right');
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('opacity-100', 'translate-x-0');
                        entry.target.classList.remove('opacity-0', 'translate-x-10');
                    }
                });
            }, { threshold: 0.5 });

            fadeInElements.forEach(element => {
                observer.observe(element);
            });
        });
    </script>

    <!-- Our Classes Section -->
    <section class="p-10 bg-gray-100 text-center">
        <h2 class="text-3xl font-bold mb-6">What We Can Offer</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/weightlifting.jpg" alt="Strength Training"
                    class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">Strength Training</h3>
                <p class="text-lg">Build your strength with our weightlifting and resistance training programs.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/cycling.jpg" alt="Indoor Cycling" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">Indoor Cycling</h3>
                <p class="text-lg">Get your heart pumping with high-energy cycling classes.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/yoga.jpg" alt="Yoga" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">Yoga & Flexibility</h3>
                <p class="text-lg">Improve flexibility, balance, and mental well-being with our yoga classes.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/HIIT.jpg" alt="HIIT" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">HIIT</h3>
                <p class="text-lg">High-Intensity Interval Training designed to push your limits and burn fat.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/personaltraining.jpg" alt="CrossFit" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">CrossFit</h3>
                <p class="text-lg">A combination of cardiovascular exercise, strength training, and gymnastics.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/zumba.jpg" alt="Zumba" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">Zumba</h3>
                <p class="text-lg">Dance-based cardio workouts that are fun and effective.</p>
            </div>
        </div>
    </section>

    <!-- Trainer Profiles -->
    <section class="p-10 bg-gray-100 text-center">
        <h2 class="text-3xl font-bold mb-6">Meet Our Trainers</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-lg shadow-md">
                <img src="img/testimonial/testimonial-1.jpg" class="rounded-full mx-auto w-32 h-32">
                <h3 class="text-xl font-bold mt-4">John Doe</h3>
                <p class="text-gray-600">Strength Coach</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-md">
                <img src="img/testimonial/testimonial-2.jpg" class="rounded-full mx-auto w-32 h-32">
                <h3 class="text-xl font-bold mt-4">Sarah Lee</h3>
                <p class="text-gray-600">Yoga Instructor</p>
            </div>
        </div>
    </section>

    <!-- Animated Statistics -->
    <section class="p-10 bg-gray-200 text-center">
        <h2 class="text-3xl font-bold mb-6">Our Achievements</h2>
        <div class="flex justify-center gap-10">
            <div class="text-center">
                <h3 class="text-4xl font-bold text-red-500">500+</h3>
                <p class="text-gray-600">Active Members</p>
            </div>
            <div class="text-center">
                <h3 class="text-4xl font-bold text-blue-500">20+</h3>
                <p class="text-gray-600">Professional Trainers</p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="p-8 bg-black text-gray-400">
        <div class="container mx-auto flex flex-col md:flex-row justify-between">
            <div>
                <h3 class="text-lg font-bold text-white">About Us</h3>
                <p>The Fitness Factory is dedicated to providing top-tier training and equipment to help you achieve
                    your fitness goals.</p>
            </div>
            <div>
                <h3 class="text-lg font-bold text-white">Opening Hours</h3>
                <p>Mon - Sat: 6 AM - 10 PM</p>
            </div>
            <!-- Social Media Links -->
            <div class="flex space-x-4 mt-4 md:mt-0">
                <a href="https://www.instagram.com" target="_blank" class="text-gray-400 hover:text-white text-2xl">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="https://www.facebook.com" target="_blank" class="text-gray-400 hover:text-white text-2xl">
                    <i class="fab fa-facebook"></i>
                </a>
                <a href="https://www.twitter.com" target="_blank" class="text-gray-400 hover:text-white text-2xl">
                    <i class="fab fa-twitter"></i>
                </a>
            </div>
        </div>
        <div class="text-center mt-6 border-t border-gray-700 pt-4">
            <p>&copy; 2025 THE FITNESS FACTORY. All rights reserved.</p>
        </div>
    </footer>


</body>

</html>