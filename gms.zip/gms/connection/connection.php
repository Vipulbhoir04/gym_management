<?php
// Database Configuration
$host = "localhost";       
$user = "root"; 
$password = "";
$database = "gym_management_system";

// Create Connection
$conn = new mysqli($host, $user, $password, $database);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Optional: Display a success message (for testing)
// echo "Connected successfully";
?>
