<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Fitness Factory</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        .fade-in-left {
            opacity: 0;
            transform: translateX(-50px);
            transition: opacity 1s ease-out, transform 1s ease-out;
        }

        .fade-in-right {
            opacity: 0;
            transform: translateX(50px);
            transition: opacity 1s ease-out, transform 1s ease-out;
        }

        .fade-in-left.active,
        .fade-in-right.active {
            opacity: 1;
            transform: translateX(0);
        }

        /* Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: -250px;
            width: 250px;
            height: 100%;
            background: white;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.2);
            transition: left 0.3s ease-in-out;
            z-index: 50;
            padding-top: 60px;
        }

        .sidebar.open {
            left: 0;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            font-size: 18px;
            text-decoration: none;
            color: black;
        }

        .sidebar a:hover {
            background: #f3f3f3;
        }

        .sidebar .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
        }

        /* Hide sidebar toggle button on large screens */
        @media (min-width: 1024px) {
            .mobile-menu-btn {
                display: none;
            }
        }

        /* Hide navbar on mobile */
        @media (max-width: 1024px) {
            .desktop-nav {
                display: none;
            }
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("active");
                    }
                });
            }, { threshold: 0.5 });

            document.querySelectorAll(".fade-in-left").forEach(element => {
                observer.observe(element);
            });
        });
    </script>
</head>



<body class="bg-white text-black mt-20">
    <header class="bg-white shadow-lg p-5 flex justify-between items-center fixed w-full top-0 z-10">
        <h1 class="text-2xl font-bold text-black">THE FITNESS FACTORY</h1>

        <!-- Hamburger Menu Button (visible on mobile) -->
        <button id="menu-btn" class="md:hidden text-black text-2xl focus:outline-none">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Sidebar (hidden by default) -->
        <div id="mobile-menu"
            class="fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform -translate-x-full transition-transform duration-300 md:hidden">
            <button id="close-btn" class="absolute top-4 right-4 text-2xl text-black">
                <i class="fas fa-times"></i>
            </button>
            <nav class="flex flex-col p-5 space-y-4 mt-10">
                <a href="index.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-home mr-2"></i>Home</a>
                <a href="aboutus.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-info-circle mr-2"></i>About Us</a>
                <a href="contact1.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-envelope mr-2"></i>Contact</a>
                <a href="user_manual.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-book mr-2"></i>User Manual</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="profile.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-user mr-2"></i>Profile</a>
                    <a href="logout.php" class="bg-red-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
                <?php else: ?>
                    <a href="login.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-sign-in-alt mr-2"></i>Log In</a>
                    <a href="register.php" class="bg-green-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-user-plus mr-2"></i>Sign Up</a>
                <?php endif; ?>
            </nav>
        </div>

        <!-- Normal Navbar (Hidden on Mobile) -->
        <nav class="hidden md:flex space-x-10">
            <a href="index.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-home mr-2"></i>Home</a>
            <a href="aboutus.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-info-circle mr-2"></i>About Us</a>
            <a href="contact1.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-envelope mr-2"></i>Contact</a>
            <a href="user_manual.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-book mr-2"></i>User Manual</a>
        </nav>

        <!-- Login/Profile Buttons -->
        <div class="hidden md:flex space-x-2">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="profile.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-user mr-2"></i>Profile</a>
                <a href="logout.php" class="bg-red-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
            <?php else: ?>
                <a href="login.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-sign-in-alt mr-2"></i>Log In</a>
                <a href="register.php" class="bg-green-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-user-plus mr-2"></i>Sign Up</a>
            <?php endif; ?>
        </div>
    </header>

    <!-- JavaScript to Toggle Sidebar -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const menuBtn = document.getElementById("menu-btn");
            const closeBtn = document.getElementById("close-btn");
            const mobileMenu = document.getElementById("mobile-menu");

            menuBtn.addEventListener("click", function () {
                mobileMenu.classList.remove("-translate-x-full");
            });

            closeBtn.addEventListener("click", function () {
                mobileMenu.classList.add("-translate-x-full");
            });

            // Close sidebar if user clicks outside it
            window.addEventListener("click", function (e) {
                if (!mobileMenu.contains(e.target) && !menuBtn.contains(e.target)) {
                    mobileMenu.classList.add("-translate-x-full");
                }
            });
        });
    </script>

    <!-- Main Content -->
    <div class="container mx-auto p-6">
        <h1 class="text-4xl font-bold text-center mb-8">How Gym Management System Works</h1>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Step 1 -->
            <div class="bg-white shadow-lg p-6 rounded-lg text-center">
                <h2 class="text-xl font-semibold">Step 1: Register</h2>
                <p class="text-gray-600">Sign up as a member or admin to access the gym management system.</p>
            </div>

            <!-- Step 2 -->
            <div class="bg-white shadow-lg p-6 rounded-lg text-center">
                <h2 class="text-xl font-semibold">Step 2: Overview</h2>
                <p class="text-gray-600">After successfully registering and signing in, take the overview of the system
                    by navigating to different pages.</p>
            </div>

            <!-- Step 3 -->
            <div class="bg-white shadow-lg p-6 rounded-lg text-center">
                <h2 class="text-xl font-semibold">Step 3: Select Membership</h2>
                <p class="text-gray-600">Choose from various membership plans that suit your fitness needs.</p>
            </div>

            <!-- Step 4 -->
            <div class="bg-white shadow-lg p-6 rounded-lg text-center">
                <h2 class="text-xl font-semibold">Step 4: Entering Details</h2>
                <p class="text-gray-600">After selecting membership, enter your data to proceed to purchase membership
                    and creating your member account.</p>
            </div>

            <!-- Step 5 -->
            <div class="bg-white shadow-lg p-6 rounded-lg text-center">
                <h2 class="text-xl font-semibold">Step 5: Make Payment (offline)</h2>
                <p class="text-gray-600">Complete payment via offline methods by visiting gym.</p>
            </div>

            <!-- Step 6 -->
            <div class="bg-white shadow-lg p-6 rounded-lg text-center">
                <h2 class="text-xl font-semibold">Step 6: Account Activation</h2>
                <p class="text-gray-600">After successfully completing offline payment, the admin will update your
                    payment status which will activate your account.</p>
            </div>

            <!-- Step 7 -->
            <div class="bg-white shadow-lg p-6 rounded-lg text-center">
                <h2 class="text-xl font-semibold">Step 7: Daily Attendance</h2>
                <p class="text-gray-600">Members should enter their check-in and check-out time everytime they visit the
                    gym. (Only once in a day the attendance can be given).</p>
            </div>

            <!-- Step 8 -->
            <div class="bg-white shadow-lg p-6 rounded-lg text-center">
                <h2 class="text-xl font-semibold">Step 8: Checkout New Memberships</h2>
                <p class="text-gray-600">While still bing a member, you can checkout new membership of the gym.</p>
            </div>

            <!-- Step 9 -->
            <div class="bg-white shadow-lg p-6 rounded-lg text-center">
                <h2 class="text-xl font-semibold">Step 9: Get Support</h2>
                <p class="text-gray-600">Contact gym admins for guidance and assistance.</p>
            </div>
        </div>

        <!-- FAQ Section -->
        <div class="mt-12">
            <h2 class="text-3xl font-bold text-center mb-6">Frequently Asked Questions</h2>
            <div class="space-y-4">
                <div class="bg-white shadow p-4 rounded-lg">
                    <h3 class="font-semibold">1. How do I reset my password?</h3>
                    <p class="text-gray-600">Click on the 'Forgot Password' button and fill in the same email that you
                        entered while registering your account.</p>
                </div>
                <div class="bg-white shadow p-4 rounded-lg">
                    <h3 class="font-semibold">2. How do I apply for job in gym?</h3>
                    <p class="text-gray-600">Register yourself as a user first. Then navigate to Job Application page
                        (More -> Job Application), and fill the data and job role.</p>
                </div>
                <div class="bg-white shadow p-4 rounded-lg">
                    <h3 class="font-semibold">3. How do I book a appointment?</h3>
                    <p class="text-gray-600">After successful login, go to the Contact page and fill in the form. The
                        admin will contact you back with further details</p>
                </div>
                <div class="bg-white shadow p-4 rounded-lg">
                    <h3 class="font-semibold">4. What payment methods are available?</h3>
                    <p class="text-gray-600">Currently, only offline payment method is avaiable. After successfully
                        purchasing a membership visit the gym and make offline payment in order to activate your
                        account.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="p-8 bg-black text-gray-400">
        <div class="container mx-auto flex flex-col md:flex-row justify-between">
            <div>
                <h3 class="text-lg font-bold text-white">About Us</h3>
                <p>The Fitness Factory is dedicated to providing top-tier training and equipment to help you achieve
                    your fitness goals.</p>
            </div>
            <div>
                <h3 class="text-lg font-bold text-white">Opening Hours</h3>
                <p>Mon - Sat: 6 AM - 10 PM</p>
            </div>
            <!-- Social Media Links -->
            <div class="flex space-x-4 mt-4 md:mt-0">
                <a href="https://www.instagram.com" target="_blank" class="text-gray-400 hover:text-white text-2xl">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="https://www.facebook.com" target="_blank" class="text-gray-400 hover:text-white text-2xl">
                    <i class="fab fa-facebook"></i>
                </a>
                <a href="https://www.twitter.com" target="_blank" class="text-gray-400 hover:text-white text-2xl">
                    <i class="fab fa-twitter"></i>
                </a>
            </div>
        </div>
        <div class="text-center mt-6 border-t border-gray-700 pt-4">
            <p>&copy; 2025 THE FITNESS FACTORY. All rights reserved.</p>
        </div>
    </footer>
</body>

</html>