<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Fitness Factory</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <style>
        .fade-in-left {
            opacity: 0;
            transform: translateX(-50px);
            transition: opacity 1s ease-out, transform 1s ease-out;
        }

        .fade-in-right {
            opacity: 0;
            transform: translateX(50px);
            transition: opacity 1s ease-out, transform 1s ease-out;
        }

        .fade-in-left.active,
        .fade-in-right.active {
            opacity: 1;
            transform: translateX(0);
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("active");
                    }
                });
            }, { threshold: 0.5 });

            document.querySelectorAll(".fade-in-left").forEach(element => {
                observer.observe(element);
            });
        });
    </script>
</head>

<body class="bg-white text-black">
    <header class="bg-white shadow-lg p-5 flex justify-between items-center fixed w-full top-0 z-10">
        <h1 class="text-2xl font-bold text-black">THE FITNESS FACTORY</h1>
        <nav class="flex space-x-10">
            <a href="home.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-home mr-2"></i>Home</a>
            <a href="aboutus.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-info-circle mr-2"></i>About Us</a>
            <a href="contact1.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-envelope mr-2"></i>Contact</a>
        </nav>
        <div class="flex space-x-2">
            <a href="login.php" class="bg-blue-500 text-white px-8 py-1 rounded-lg text-center">Log In</a>
            <a href="register.php" class="bg-green-500 text-white px-8 py-1 rounded-lg text-center">Sign Up</a>
        </div>
    </header>

    <section class="h-screen flex flex-col justify-center items-center text-center px-4 bg-cover bg-center mt-0"
        style="background-image: url('img/hero/hero-1.jpg');">
        <h2 class="text-4xl font-bold mb-4 text-white">Unleash Your Inner Beast</h2>
        <p class="text-lg mb-6 text-white">Join THE FITNESS FACTORY and start your transformation today.</p>
        <button class="bg-red-500 text-white px-6 py-3 rounded-lg mt-4">Get Started</button>
    </section>

    <section class="p-10 flex flex-col md:flex-row items-center justify-between bg-gray-100">
        <div class="md:w-1/2 fade-in-left md:pl-10">
            <h2 class="text-3xl font-bold mb-4">Our Philosophy</h2>
            <p class="max-w-lg">At THE FITNESS FACTORY, we believe in more than just lifting weights. Our goal is to
                foster a community of fitness enthusiasts who support and challenge each other. Strength, endurance, and
                discipline are the core values that drive us forward.</p>
        </div>
        <div class="md:w-1/2 flex justify-center">
            <img src="img/sidebar-banner.jpg" alt="Our Philosophy" class="rounded-lg shadow-lg w-full max-w-md">
        </div>
    </section>

    <!-- Why Choose Us Section -->
    <section id="why-choose-us" class="p-10">
        <h2 class="text-3xl font-bold mb-6 text-center">Why Choose Us?</h2>
        <div class="flex flex-col md:flex-row items-center justify-between">
            <!-- Image on the left -->
            <div class="md:w-1/2 flex justify-center fade-in-left">
                <img src="img/services/services-3.jpg" alt="Why Choose Us" class="rounded-lg shadow-lg w-full max-w-md">
            </div>

            <!-- Text on the right with fade-in effect -->
            <div
                class="md:w-1/2 md:pr-10 opacity-0 transform translate-x-10 transition-opacity transition-transform duration-1000 ease-out fade-in-right">
                <p class="max-w-lg text-lg">
                    At <strong>THE FITNESS FACTORY</strong>, we are more than just a gym—we are a community of fitness
                    enthusiasts committed to helping each other grow and improve. Whether you're a beginner looking
                    for guidance or an experienced athlete aiming to take your fitness to the next level, we have the
                    perfect resources for you.
                    <br><br>
                    Our state-of-the-art facilities, expert trainers, and personalized workout plans ensure that
                    you stay motivated and on track. We offer a variety of classes, including strength training,
                    HIIT, yoga, and personal coaching, to cater to different fitness goals.
                    <br><br>
                    At our gym, you’ll find a supportive environment where discipline, determination, and dedication
                    lead to transformation. Join us today and experience the difference!
                </p>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const fadeInElements = document.querySelectorAll('.fade-in-left, .fade-in-right');
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('opacity-100', 'translate-x-0');
                        entry.target.classList.remove('opacity-0', 'translate-x-10');
                    }
                });
            }, { threshold: 0.5 });

            fadeInElements.forEach(element => {
                observer.observe(element);
            });
        });
    </script>

    <!-- Our Classes Section -->
    <section class="p-10 bg-gray-100 text-center">
        <h2 class="text-3xl font-bold mb-6">What We Can Offer</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/weightlifting.jpg" alt="Strength Training"
                    class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">Strength Training</h3>
                <p class="text-lg">Build your strength with our weightlifting and resistance training programs.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/cycling.jpg" alt="Indoor Cycling" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">Indoor Cycling</h3>
                <p class="text-lg">Get your heart pumping with high-energy cycling classes.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/yoga.jpg" alt="Yoga" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">Yoga & Flexibility</h3>
                <p class="text-lg">Improve flexibility, balance, and mental well-being with our yoga classes.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/HIIT.jpg" alt="HIIT" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">HIIT</h3>
                <p class="text-lg">High-Intensity Interval Training designed to push your limits and burn fat.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/personaltraining.jpg" alt="CrossFit" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">CrossFit</h3>
                <p class="text-lg">A combination of cardiovascular exercise, strength training, and gymnastics.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                <img src="img/zumba.jpg" alt="Zumba" class="w-full h-40 object-cover mb-4 rounded-lg">
                <h3 class="text-xl font-semibold mb-2">Zumba</h3>
                <p class="text-lg">Dance-based cardio workouts that are fun and effective.</p>
            </div>
        </div>
    </section>

    <!-- Contact Information Section -->
    <section id="contact-info" class="bg-gray-100 py-10">
        <div class="container mx-auto text-center">
            <h2 class="text-3xl font-bold mb-6">Get in Touch</h2>
            <div class="flex flex-col md:flex-row justify-center items-center gap-10">
                <!-- Location -->
                <div class="flex items-center gap-4">
                    <i class="fas fa-map-marker-alt text-3xl text-red-500"></i>
                    <div>
                        <h3 class="text-xl font-semibold">Our Location</h3>
                        <p>123 Fitness Street, Lokmanya Nagar, Thane(W)</p>
                    </div>
                </div>

                <!-- Contact Number -->
                <div class="flex items-center gap-4">
                    <i class="fas fa-phone-alt text-3xl text-green-500"></i>
                    <div>
                        <h3 class="text-xl font-semibold">Call Us</h3>
                        <p>+91 90000 00001</p>
                    </div>
                </div>

                <!-- Email -->
                <div class="flex items-center gap-4">
                    <i class="fas fa-envelope text-3xl text-blue-500"></i>
                    <div>
                        <h3 class="text-xl font-semibold">Email Us</h3>
                        <p>info@thefitnessfactory.com</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FontAwesome for Icons -->
    <script src="https://kit.fontawesome.com/YOUR_KIT_CODE.js" crossorigin="anonymous"></script>


    <footer class="p-8 bg-black text-gray-400">
        <div class="container mx-auto flex flex-col md:flex-row justify-between items-start gap-6">
            <!-- About Section -->
            <div class="w-full md:w-1/3">
                <h3 class="text-lg font-bold text-white mb-2">About Us</h3>
                <p class="text-sm">THE FITNESS FACTORY is dedicated to providing top-tier fitness training and equipment
                    to help you achieve your fitness goals.</p>
            </div>

            <!-- Social Media Links -->
            <div class="w-full md:w-1/3">
                <h3 class="text-lg font-bold text-white mb-2">Follow Us</h3>
                <div class="flex space-x-4">
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-instagram"></i> Instagram</a>
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-facebook"></i> Facebook</a>
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-twitter"></i> Twitter</a>
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fas fa-envelope"></i> Email</a>
                </div>
            </div>

            <!-- Gym Timings -->
            <div class="w-full md:w-1/3">
                <h3 class="text-lg font-bold text-white mb-2">Opening Hours</h3>
                <p class="text-sm">Mon - Sat: 6 AM - 10 PM</p>
            </div>
        </div>

        <!-- Bottom: Copyright -->
        <div class="text-center mt-6 border-t border-gray-700 pt-4">
            <p>&copy; 2025 THE FITNESS FACTORY. All rights reserved.</p>
        </div>
    </footer>
</body>

</html>