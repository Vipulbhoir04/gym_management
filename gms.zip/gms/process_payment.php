<?php
session_start();
include("connection/connection.php");

// Get user_id from session
if (!isset($_SESSION['user_id'])) {
    die(json_encode(["status" => "error", "message" => "Session expired. Please log in again."]));
}
$user_id = $_SESSION['user_id'];

// Get form data
$name = $_POST['name'];
$contact = $_POST['contact'];
$email = $_POST['email'];
$address = $_POST['address'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$mem_id = $_POST['mem_id'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$weight = $_POST['weight'];
$height = $_POST['height'];
$bmi = $_POST['bmi'];
$fitness_level = $_POST['fitness_level'];
$goal = $_POST['goal'];
$instructor = !empty($_POST['ins_id']) ? $_POST['ins_id'] : 'NULL';
$total_price = $_POST['total_price'];
$payment_method = $_POST['payment_method']; // Should be 'Offline'
$total_price = $_POST['total_price'];

$status = 'Inactive'; // default value for offline payment mode (will be updated after payment by admin)

// Generate m_id (Auto-incremented)
$query = "SELECT COUNT(*) AS count FROM member";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$m_id = 'M' . str_pad($row['count'] + 1, 5, '0', STR_PAD_LEFT);

// Insert into `member` table (Added last_checkup_date with CURDATE())
$insertMember = "INSERT INTO member (m_id, user_id, name, contact, email, address, age, gender, mem_id, start_date, end_date, status, weight, height, fitness_level, goal, ins_id, last_checkup_date, total_price)
                 VALUES ('$m_id', '$user_id', '$name', '$contact', '$email', '$address', '$age', '$gender', '$mem_id', '$start_date', '$end_date', '$status', '$weight', '$height', '$fitness_level', '$goal', " . ($instructor === 'NULL' ? "NULL" : "'$instructor'") . ", CURDATE(), '$total_price')";

if (!mysqli_query($conn, $insertMember)) {
    die(json_encode(["status" => "error", "message" => "Failed to insert member data."]));
}

// Generate payment_id (Auto-incremented)
$query = "SELECT COUNT(*) AS count FROM payments";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$payment_id = 'P' . str_pad($row['count'] + 1, 5, '0', STR_PAD_LEFT);

// Insert into `payment` table
$insertPayment = "INSERT INTO payments (payment_id, m_id, mem_id, amount, payment_mode, payment_status, transaction_id, payment_date)
                  VALUES ('$payment_id', '$m_id', '$mem_id', '$total_price', '$payment_method', 'Pending', NULL, NULL)";

if (!mysqli_query($conn, $insertPayment)) {
    die(json_encode(["status" => "error", "message" => "Failed to insert payment data."]));
}

// Redirect to invoice page
header("Location: invoice.php?payment_id=$payment_id");
exit;
?>