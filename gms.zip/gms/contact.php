<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .fade-in {
            opacity: 0;
            transform: translateY(30px);
            transition: opacity 0.6s ease-out, transform 0.6s ease-out;
        }

        .fade-in.show {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>

<body class="bg-gray-100">

    <!-- Page Heading -->
    <div class="text-center py-10 fade-in">
        <h1 class="text-4xl font-bold text-gray-800">Contact Us</h1>
        <p class="text-gray-600 mt-2">We'd love to hear from you! Get in touch with us.</p>
    </div>

    <!-- Introductory Content -->
    <div class="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8 mb-12 fade-in">
        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Why Contact Us?</h2>
        <p class="text-gray-600 leading-relaxed">
            Whether you're looking to sign up for a membership, have questions about our personal training programs, or
            want to know more about our state-of-the-art gym facilities, we are here to assist you.
            Our team is dedicated to ensuring you have the best fitness experience possible. Drop us a message, and
            we'll get back to you as soon as possible!
        </p>
        <ul class="list-disc list-inside mt-4 text-gray-700">
            <li>Membership inquiries</li>
            <li>Personal training sessions</li>
            <li>Gym facilities & services</li>
            <li>Business partnerships & collaborations</li>
        </ul>
    </div>

    <!-- Contact Form Section -->
    <div class="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8 mb-12 fade-in">
        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Send Us a Message</h2>
        <form action="process_contact.php" method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Your Name</label>
                <input type="text" name="name" required
                    class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Your Email</label>
                <input type="email" name="email" required
                    class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-medium">Message</label>
                <textarea name="message" required
                    class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300"></textarea>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
                Send Message
            </button>
        </form>
    </div>

    <!-- Google Map Section -->
    <div class="max-w-6xl mx-auto mb-12 fade-in">
        <h2 class="text-2xl font-semibold text-gray-800 text-center mb-4">Find Us Here</h2>
        <iframe class="w-full h-96 rounded-lg shadow-lg"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.83543450933!2d144.9556513153166!3d-37.81731497975171!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0x5045675218ce6e0!2sMelbourne%2C+Victoria%2C+Australia!5e0!3m2!1sen!2s!4v1615322862754"
            allowfullscreen="" loading="lazy">
        </iframe>
    </div>

    <!-- Contact Details Section -->
    <div class="max-w-6xl mx-auto mb-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center fade-in">
        <!-- Location -->
        <div class="bg-white p-6 rounded-lg shadow-md flex flex-col items-center">
            <i class="fas fa-map-marker-alt text-red-500 text-3xl"></i>
            <h3 class="text-xl font-semibold mt-2">Our Location</h3>
            <p class="text-gray-600">123 Fitness Street, New York, USA</p>
        </div>
        <!-- Phone Number -->
        <div class="bg-white p-6 rounded-lg shadow-md flex flex-col items-center">
            <i class="fas fa-phone text-green-500 text-3xl"></i>
            <h3 class="text-xl font-semibold mt-2">Call Us</h3>
            <p class="text-gray-600">+1 234 567 890</p>
        </div>
        <!-- Email -->
        <div class="bg-white p-6 rounded-lg shadow-md flex flex-col items-center">
            <i class="fas fa-envelope text-blue-500 text-3xl"></i>
            <h3 class="text-xl font-semibold mt-2">Email Us</h3>
            <p class="text-gray-600">contact@fitnessfactory.com</p>
        </div>
    </div>

    <!-- Scroll Animation Script -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const elements = document.querySelectorAll(".fade-in");

            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("show");
                    }
                });
            }, { threshold: 0.2 });

            elements.forEach(element => {
                observer.observe(element);
            });
        });
    </script>

    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

</body>

</html>