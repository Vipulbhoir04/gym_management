<?php
session_start();
include 'connection/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $mem_id = $_POST['mem_id'];
    $weight = $_POST['weight'];
    $height = $_POST['height'];
    $bmi = $_POST['bmi'];
    $fitness_level = $_POST['fitness_level'];
    $goal = $_POST['goal'];
    $ins_id = !empty($_POST['ins_id']) ? $_POST['ins_id'] : NULL;
    $total_price = $_POST['total_price'];

    // Store form data in session for later insertion
    $_SESSION['membership_data'] = [
        'name' => $name,
        'contact' => $contact,
        'email' => $email,
        'address' => $address,
        'age' => $age,
        'gender' => $gender,
        'start_date' => $start_date,
        'end_date' => $end_date,
        'mem_id' => $mem_id,
        'weight' => $weight,
        'height' => $height,
        'bmi' => $bmi,
        'fitness_level' => $fitness_level,
        'goal' => $goal,
        'ins_id' => $ins_id,
        'total_price' => $total_price
    ];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex justify-center items-center min-h-screen">
    <div class="bg-white shadow-lg rounded-xl p-6 w-full max-w-md text-center">
        <h2 class="text-2xl font-bold mb-4">Payment Details</h2>
        <p class="text-lg">Total Amount: <strong>Rs.<?php echo number_format($total_price, 2); ?></strong></p>

        <form action="process_payment.php" method="POST">
            <input type="hidden" name="total_price" value="<?php echo $total_price; ?>">
            <button type="submit"
                class="bg-green-500 text-white py-2 px-4 rounded-lg mt-4 hover:bg-green-600 transition">
                Pay Now
            </button>
        </form>
    </div>
</body>

</html>