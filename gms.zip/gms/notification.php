<?php
session_start();
include 'connection/connection.php'; // Include database connection file

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch unread notifications count
$unreadQuery = "SELECT COUNT(*) AS unread_count FROM notification";
$unreadResult = $conn->query($unreadQuery);
$unreadRow = $unreadResult->fetch_assoc();
$unreadCount = $unreadRow['unread_count'];

// Fetch notifications
$query = "SELECT * FROM notification ORDER BY date DESC";
$result = $conn->query($query);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .fade-in {
            opacity: 0;
            transform: translateY(30px);
            transition: opacity 0.6s ease-out, transform 0.6s ease-out;
        }

        .fade-in.show {
            opacity: 1;
            transform: translateY(0);
        }

        .fade-in-left {
            opacity: 0;
            transform: translateX(-50px);
            transition: opacity 1s ease-out, transform 1s ease-out;
        }

        .fade-in-left.active {
            opacity: 1;
            transform: translateX(0);
        }

        /* Quotes Animation */
        .quotes {
            font-size: 1.5rem;
            font-weight: bold;
            color: white;
            transition: opacity 1s ease-in-out;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            background-color: white;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            min-width: 150px;
            z-index: 10;
        }

        .dropdown:hover .dropdown-menu {
            display: block;
        }

        /* Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: -250px;
            width: 250px;
            height: 100%;
            background: white;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.2);
            transition: left 0.3s ease-in-out;
            z-index: 50;
            padding-top: 60px;
        }

        .sidebar.open {
            left: 0;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            font-size: 18px;
            text-decoration: none;
            color: black;
        }

        .sidebar a:hover {
            background: #f3f3f3;
        }

        .sidebar .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
        }

        /* Hide sidebar toggle button on large screens */
        @media (min-width: 1024px) {
            .mobile-menu-btn {
                display: none;
            }
        }

        /* Hide navbar on mobile */
        @media (max-width: 1024px) {
            .desktop-nav {
                display: none;
            }
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Fade-in animation
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("active");
                    }
                });
            }, { threshold: 0.5 });

            document.querySelectorAll(".fade-in-left").forEach(element => {
                observer.observe(element);
            });

            // Motivational Quotes
            const quotes = [
                "Train like a beast, look like a beauty.",
                "Every workout is progress, no matter how small.",
                "Push yourself because no one else will do it for you.",
                "Stronger every day, inside and out."
            ];
            let quoteIndex = 0;
            function updateQuote() {
                document.getElementById("quote-text").style.opacity = 0;
                setTimeout(() => {
                    document.getElementById("quote-text").innerText = quotes[quoteIndex];
                    document.getElementById("quote-text").style.opacity = 1;
                    quoteIndex = (quoteIndex + 1) % quotes.length;
                }, 1000);
            }
            setInterval(updateQuote, 3000);
        });

        function toggleSidebar() {
            document.getElementById("sidebar").classList.toggle("open");
        }
        setTimeout(function () {
            let messageDiv = document.getElementById("success-message");
            if (messageDiv) {
                messageDiv.style.display = "none";
            }
        }, 3000);

    </script>
</head>

<body class="bg-gray-100">

    <header class="bg-white shadow-lg p-5 flex justify-between items-center fixed w-full top-0 z-10">
        <h1 class="text-2xl font-bold text-black">THE FITNESS FACTORY</h1>

        <!-- Hamburger Menu Button (visible on mobile) -->
        <button id="menu-btn" class="md:hidden text-black text-2xl focus:outline-none">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Sidebar (hidden by default) -->
        <div id="mobile-menu"
            class="fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform -translate-x-full transition-transform duration-300 md:hidden">
            <button id="close-btn" class="absolute top-4 right-4 text-2xl text-black">
                <i class="fas fa-times"></i>
            </button>
            <nav class="flex flex-col p-5 space-y-4 mt-10">
                <a href="home.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-home mr-2"></i>Home</a>
                <a href="about_us.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-info-circle mr-2"></i>About Us</a>
                <a href="contact.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-envelope mr-2"></i>Contact</a>
                <a href="notification.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-bell mr-2"></i>Notification</a>
                <a href="job_application.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-calendar-check mr-2"></i>Job Apply</a>
                <a href="membership.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fa fa-user-plus mr-2"></i>Membership</a>
                <a href="our_team.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-users mr-2"></i>Our Team</a>
                <a href="gallery.php" class="text-black hover:text-gray-600 flex items-center"><i
                        class="fas fa-images mr-2"></i>Gallery</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="profile.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-user mr-2"></i>Profile</a>
                    <a href="logout.php" class="bg-red-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
                <?php else: ?>
                    <a href="login.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-sign-in-alt mr-2"></i>Log In</a>
                    <a href="register.php" class="bg-green-500 text-white px-6 py-1 rounded-lg flex items-center">
                        <i class="fas fa-user-plus mr-2"></i>Sign Up</a>
                <?php endif; ?>
            </nav>
        </div>

        <!-- Normal Navbar (Hidden on Mobile) -->
        <nav class="hidden md:flex space-x-10">
            <a href="home.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-home mr-2"></i>Home</a>
            <a href="about_us.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-info-circle mr-2"></i>About Us</a>
            <a href="contact.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-envelope mr-2"></i>Contact</a>
            <a href="notification.php" class="text-black hover:text-gray-600 flex items-center"><i
                    class="fas fa-bell mr-2"></i>Notification</a>
            <div class="relative dropdown">
                <button class="text-black hover:text-gray-600 flex items-center">
                    <i class="fas fa-bars mr-2"></i>More <i class="ml-1"></i>
                </button>
                <div class="dropdown-menu absolute mt-2 w-40 p-2">
                    <a href="job_application.php" class="block px-4 py-2 hover:bg-gray-100 flex items-center"><i
                            class="fas fa-calendar-check mr-2"></i>Job Apply</a>
                    <a href="membership.php" class="block px-4 py-2 hover:bg-gray-100 flex items-center"><i
                            class="fa fa-user-plus mr-2"></i>Membership</a>
                    <a href="our_team.php" class="block px-4 py-2 hover:bg-gray-100 flex items-center"><i
                            class="fas fa-users mr-2"></i>Our Team</a>
                    <a href="gallery.php" class="block px-4 py-2 hover:bg-gray-100 flex items-center"><i
                            class="fas fa-images mr-2"></i>Gallery</a>
                </div>
            </div>
        </nav>

        <!-- Login/Profile Buttons -->
        <div class="hidden md:flex space-x-2">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="profile.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-user mr-2"></i>Profile</a>
                <a href="logout.php" class="bg-red-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
            <?php else: ?>
                <a href="login.php" class="bg-blue-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-sign-in-alt mr-2"></i>Log In</a>
                <a href="register.php" class="bg-green-500 text-white px-6 py-1 rounded-lg flex items-center">
                    <i class="fas fa-user-plus mr-2"></i>Sign Up</a>
            <?php endif; ?>
        </div>
    </header>

    <!-- JavaScript to Toggle Sidebar -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const menuBtn = document.getElementById("menu-btn");
            const closeBtn = document.getElementById("close-btn");
            const mobileMenu = document.getElementById("mobile-menu");

            menuBtn.addEventListener("click", function () {
                mobileMenu.classList.remove("-translate-x-full");
            });

            closeBtn.addEventListener("click", function () {
                mobileMenu.classList.add("-translate-x-full");
            });

            // Close sidebar if user clicks outside it
            window.addEventListener("click", function (e) {
                if (!mobileMenu.contains(e.target) && !menuBtn.contains(e.target)) {
                    mobileMenu.classList.add("-translate-x-full");
                }
            });
        });
    </script>

    <!-- Notification List -->
    <div class="flex items-center justify-center min-h-screen bg-gray-100">
        <div class="bg-white p-6 rounded-lg shadow-lg w-[28rem] mx-auto">
            <h2 class="text-xl font-semibold text-center mb-4 text-gray-700">Notifications</h2>
            <div class="space-y-2">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="p-3 border rounded-lg bg-gray-50">
                        <p class="text-gray-800 font-medium"><?php echo $row['notification']; ?></p>
                        <span class="text-sm text-gray-500"><?php echo date("F j, Y", strtotime($row['date'])); ?></span>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="p-8 bg-black text-gray-400">
        <div class="container mx-auto flex flex-col md:flex-row justify-between">
            <div>
                <h3 class="text-lg font-bold text-white">About Us</h3>
                <p>The Fitness Factory is dedicated to providing top-tier training and equipment to help you achieve
                    your fitness goals.</p>
            </div>
            <div>
                <h3 class="text-lg font-bold text-white">Opening Hours</h3>
                <p>Mon - Sat: 6 AM - 10 PM</p>
            </div>
            <!-- Social Media Links -->
            <div class="flex space-x-4 mt-4 md:mt-0">
                <a href="https://www.instagram.com" target="_blank" class="text-gray-400 hover:text-white text-2xl">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="https://www.facebook.com" target="_blank" class="text-gray-400 hover:text-white text-2xl">
                    <i class="fab fa-facebook"></i>
                </a>
                <a href="https://www.twitter.com" target="_blank" class="text-gray-400 hover:text-white text-2xl">
                    <i class="fab fa-twitter"></i>
                </a>
            </div>
        </div>
        <div class="text-center mt-6 border-t border-gray-700 pt-4">
            <p>&copy; 2025 THE FITNESS FACTORY. All rights reserved.</p>
        </div>
    </footer>

    <!-- Scroll Animation Script -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const elements = document.querySelectorAll(".fade-in");

            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("show");
                    }
                });
            }, { threshold: 0.2 });

            elements.forEach(element => {
                observer.observe(element);
            });
        });
    </script>

    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

</body>

</html>