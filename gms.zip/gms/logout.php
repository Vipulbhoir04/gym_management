<?php
session_start();
include 'connection/connection.php';

if (isset($_SESSION["user_id"])) {
    $user_id = $_SESSION["user_id"];
    $conn->query("UPDATE users SET is_logged_in = FALSE WHERE user_id = '$user_id'");
}

session_destroy();
setcookie("login_token", "", time() - 3600, "/"); // Remove token
header("Location: login.php");
exit();

?>