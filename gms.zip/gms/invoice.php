<?php
include 'connection/connection.php';

if (!isset($_GET['payment_id'])) {
    echo "Invalid request.";
    exit();
}

$payment_id = $_GET['payment_id'];

$query = "SELECT member.name AS name, 
                 member.contact AS contact, 
                 member.email AS email, 
                 membership.type AS type, 
                 payments.amount AS amount, 
                 payments.payment_mode AS payment_mode, 
                 payments.payment_status AS payment_status 
          FROM payments
          JOIN member ON payments.m_id = member.m_id
          JOIN membership ON payments.mem_id = membership.mem_id
          WHERE payments.payment_id = '$payment_id'";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

if (mysqli_num_rows($result) > 0) {
    $data = mysqli_fetch_assoc($result);
} else {
    die("No payment record found for ID: " . $payment_id);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fitness Factory Gym - Invoice</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .invoice-container {
            width: 700px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #ff5733;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .gym-logo img {
            width: 120px;
            height: auto;
        }

        .invoice-title {
            font-size: 24px;
            font-weight: bold;
            text-align: right;
            color: #333;
        }

        .invoice-details {
            margin-top: 20px;
        }

        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .invoice-table th,
        .invoice-table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .invoice-table th {
            background: #ff5733;
            color: white;
        }

        .invoice-footer {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }

        .status-pending {
            color: red;
            font-weight: bold;
        }

        .status-completed {
            color: green;
            font-weight: bold;
        }

        .btn-print {
            display: block;
            width: 100%;
            text-align: center;
            margin-top: 20px;
        }

        .btn-print button {
            background: #ff5733;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .btn-print button:hover {
            background: #d84315;
        }
    </style>
</head>

<body>

    <div class="invoice-container">
        <!-- Header -->
        <div class="invoice-header">
            <div class="gym-logo">
                <img src="img/logo.png" alt="Fitness Factory Gym">
            </div>
            <div class="invoice-title">
                <span>Membership Invoice</span>
                <br>
                <small>Payment ID: <?php echo $payment_id; ?></small>
            </div>
        </div>

        <!-- Invoice Details -->
        <div class="invoice-details">
            <p><strong>Name:</strong> <?php echo $data['name']; ?></p>
            <p><strong>Contact:</strong> <?php echo $data['contact']; ?></p>
            <p><strong>Email:</strong> <?php echo $data['email']; ?></p>
        </div>

        <!-- Payment Table -->
        <table class="invoice-table">
            <thead>
                <tr>
                    <th>Membership Type</th>
                    <th>Amount</th>
                    <th>Payment Mode</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo $data['type']; ?></td>
                    <td>$<?php echo number_format($data['amount'], 2); ?></td>
                    <td><?php echo $data['payment_mode']; ?></td>
                    <td
                        class="<?php echo strtolower($data['payment_status']) === 'pending' ? 'status-pending' : 'status-completed'; ?>">
                        <?php echo ucfirst($data['payment_status']); ?>
                    </td>
                </tr>
            </tbody>
        </table>

        <!-- Print Button -->
        <div class="btn-print">
            <button onclick="window.print()">Print Invoice</button>
        </div>

        <!-- Footer -->
        <div class="invoice-footer">
            <p>Fitness Factory Gym | Contact: +1 234-567-890 | Address: 123 Fitness Street, Lokmanya Nagar, Thane(W)</p>
            <p>Thank you for being a part of our gym. Stay fit and healthy!</p>
        </div>
    </div>

</body>

</html>