<?php
session_start();
include('../gms/connection/connection.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch user data
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE user_id='$user_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    die("Error fetching user data: " . $conn->error);
}

// Update user profile
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Update query
    $update_sql = "UPDATE users SET username='$username', email='$email', psswd='$password' WHERE user_id='$user_id'";
    if ($conn->query($update_sql) === TRUE) {
        $success_message = "Profile updated successfully!";
        echo "<script>setTimeout(function(){ window.location.href = 'home.php'; }, 3000);</script>";
    } else {
        $error_message = "Error updating profile: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Custom Styles -->
    <style>
        body {
            background: url('img/hero/hero-1.jpg') no-repeat center center/cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            text-align: center;
            color: white;
        }

        h2 {
            font-size: 2rem;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 20px;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.5);
        }

        .form-group {
            position: relative;
            width: 320px;
            margin-bottom: 20px;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            padding-left: 40px;
            height: 50px;
            border-radius: 30px;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .form-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
        }

        .btn-update {
            background: #007bff;
            border: none;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
            width: 320px;
            color: white;
            transition: 0.3s;
            border-radius: 30px;
        }

        .btn-update:hover {
            background: #0056b3;
        }

        .btn-home {
            background: #6c757d;
            border: none;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
            width: 320px;
            color: white;
            transition: 0.3s;
            border-radius: 30px;
        }

        .btn-home:hover {
            background: #545b62;
        }

        @media (max-width: 768px) {
            body {
                padding: 20px;
                background-position: center;
            }

            .form-group,
            .btn-update,
            .btn-home {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <h2>User Profile</h2>

    <?php
    if (isset($success_message)) {
        echo '<div class="alert alert-success">' . $success_message . '</div>';
    }

    if (isset($error_message)) {
        echo '<div class="alert alert-danger">' . $error_message . '</div>';
    }
    ?>

    <form action="" method="POST">
        <div class="form-group">
            <i class="fas fa-user"></i>
            <input type="text" name="username" class="form-control" placeholder="Username"
                value="<?php echo $user['username']; ?>" required>
        </div>
        <div class="form-group">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" class="form-control" placeholder="Email Address"
                value="<?php echo $user['email']; ?>" required>
        </div>
        <div class="form-group">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" class="form-control" placeholder="Password"
                value="<?php echo $user['psswd']; ?>" required>
        </div>

        <button type="submit" class="btn-update mb-3">Update Profile</button>
    </form>

    <a href="home.php" class="btn-home">Back to Home</a>

    <!-- JS Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>

</html>