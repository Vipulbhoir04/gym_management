<?php
// Include database connection file and PHPMailer
include '../connection/connection.php';
session_start(); // Start the session
use PHPMailer\PHPMailer\PHPMailer;
require '../vendor/autoload.php';

// Process form data when submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Generate a 6-digit OTP
        $otp = rand(100000, 999999);

        // Save the OTP and email in session
        $_SESSION['otp'] = $otp;
        $_SESSION['email'] = $email;

        // Send OTP to user's email
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // Specify your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'vipulbhoir027@gmail.com';  // Your email address
        $mail->Password = 'znbkspsizlrnliwh';  // Your email password
        $mail->SMTPSecure = 'tls'; 
        $mail->Port = 587; 

        $mail->setFrom('vipulbhoir027@gmail.com', 'Website Demo');
        $mail->addAddress($email);
        $mail->Subject = 'Password Reset OTP';
        $mail->Body    = "Your OTP for password reset is: $otp";

        if ($mail->send()) {
            // Redirect to reset password page
            header("Location: verify_otp.php");
            exit();
        } else {
            $error_message = "Mailer Error: " . $mail->ErrorInfo;
        }
    } else {
        $error_message = "No account found with that email.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to bottom, #1a1a1a, #333333);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: white;
        }
        .container {
            width: 400px;
            padding: 20px;
            background: #2d2d2d;
            border-radius: 0.25rem;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        .floating-placeholder {
            position: relative;
            margin-bottom: 20px;
        }
        .floating-placeholder input {
            border: 1px solid #FFD700;
            padding: 1rem 0.5rem 0.5rem 0.5rem;
            border-radius: 0.25rem;
            background: transparent;
            color: white;
            width: 100%;
        }
        .floating-placeholder label {
            position: absolute;
            top: 1rem;
            left: 0.5rem;
            color: #FFD700;
            padding: 0 0.25rem;
            transition: all 0.2s ease;
            pointer-events: none;
        }
        .floating-placeholder input:focus + label,
        .floating-placeholder input:not(:placeholder-shown) + label {
            top: -0.75rem;
            left: 0.5rem;
            font-size: 1rem;
            color: #FFD700;
            background: #1a1a1a;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #FFD700;
            border: none;
            border-radius: 0.25rem;
            cursor: pointer;
            transition: background 0.3s;
            color: black;
            font-weight: bold;
        }
        button:hover {
            background: #E5C100;
        }
        .message {
            margin-top: 20px;
            text-align: center;
        }
        .success {
            color: #4caf50;
        }
        .error {
            color: #f44336;
        }
        .back-to-home {
            margin-top: 20px;
            display: block;
            text-align: center;
            color: #FFD700;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-2xl font-bold mb-6 text-center">Forgot Password</h2>
        <form method="POST" action="">
            <div class="floating-placeholder">
                <input type="email" name="email" id="email" placeholder=" " required>
                <label for="email">Email</label>
            </div>
            <button type="submit">Send OTP</button>
        </form>
        <?php
        if (!empty($error_message)) {
            echo '<p class="message error">' . $error_message . '</p>';
        }
        ?>
        <a class="back-to-home" href="login.php">Back to Login</a>
    </div>
</body>
</html>
