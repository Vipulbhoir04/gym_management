<?php
session_start();
include('../connection/connection.php');

// Function to generate a unique form_id
function generateFormId($conn) {
    $query = "SELECT MAX(form_id) AS max_id FROM application_form";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $maxId = $row['max_id'];

    if ($maxId) {
        $number = (int)substr($maxId, 5) + 1;
    } else {
        $number = 1;
    }

    return 'F0000' . $number;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $form_id = generateFormId($conn);
    $name = $_POST['name'];
    $email = $_POST['email'];
    $description = $_POST['description'];
    $role = $_POST['role'];
    $user_id = $_SESSION['user_id']; // Assuming the user is logged in

    $query = "INSERT INTO application_form (form_id, name, email, description, role, user_id) VALUES ('$form_id', '$name', '$email', '$description', '$role', '$user_id')";
    if (mysqli_query($conn, $query)) {
        echo "Application submitted successfully.";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Form</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background: linear-gradient(to bottom, #1a1a1a, #333333); /* Dark gradient background */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .form-container {
            padding: 2em;
            background-color: rgba(0, 0, 0, 0.75);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            border-radius: 8px;
            max-width: 700px;
            width: 100%;
            color: white;
            text-align: center;
        }

        .form-container h2 {
            margin-bottom: 1em;
            font-size: 24px;
            color: #FFD700;
        }

        .form-container label {
            display: block;
            margin-bottom: 0.5em;
            color: #FFD700;
            text-align: left;
        }

        .form-container input, .form-container textarea, .form-container select {
            width: 100%;
            padding: 0.5em;
            margin-bottom: 1em;
            border: 1px solid #ccc;
            border-radius: 4px;
            color: #333;
            background-color: #1a1a1a; /* Dark background for input fields */
        }

        .form-container input::placeholder, .form-container textarea::placeholder {
            color: #999; /* Placeholder text color */
        }

        .form-container button {
            background-color: #FFD700;
            color: black;
            padding: 0.75em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%; /* Full width button */
        }

        .form-container button:hover {
            background-color: #FFC700;
        }

        .back-button {
            background-color: #FFD700;
            color: black;
            padding: 0.75em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            width: 200px;
            position: fixed;
            bottom: 20px;
            right: 20px;
        }

        .back-button:hover {
            background-color: #FFC700;
        }
    </style>
</head>
<body>
    <header class="navbar flex items-center justify-between p-4 bg-gray-800 text-white w-full">
        <div class="flex-1 text-center">
            <span class="text-2xl font-bold">THE FITNESS FACTORY</span>
        </div>
    </header>
    <main class="flex flex-col justify-center items-center bg-black bg-opacity-75 p-4 w-full flex-grow">
        <div class="form-container">
            <h2>Join Our Gym</h2>
            <form action="application_form.php" method="post">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" placeholder="Enter your name" required>
                
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
                
                <label for="description">Description:</label>
                <textarea id="description" name="description" rows="4" placeholder="Enter a description" required></textarea>
                
                <label for="role">Role:</label>
                <select id="role" name="role" required>
                    <option value="Instructor">Instructor</option>
                    <option value="Staff">Staff</option>
                    <option value="Admin">Admin</option>
                </select>
                
                <button type="submit">Submit</button>
            </form>
        </div>
    </main>
    <a href="home.php" class="back-button">Back to Home</a>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Display message within the page
            <?php if (!$isLoggedIn): ?>
            $('a[href="profile.php"], a[href="memberships.php"], a[href="instructors.php"]').click(function(event) {
                event.preventDefault();
                alert('Please log in to access this page.');
            });
            <?php endif; ?>
        });
    </script>
</body>
</html>
