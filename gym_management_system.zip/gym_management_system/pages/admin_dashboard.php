<?php
session_start();
include('../connection/connection.php');

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$username = $isLoggedIn ? $_SESSION['username'] : '';

// Check for new application forms
$newApplicationCountQuery = "SELECT COUNT(*) AS count FROM application_form WHERE viewed = 0";
$newApplicationCountResult = mysqli_query($conn, $newApplicationCountQuery);
$newApplicationCountRow = mysqli_fetch_assoc($newApplicationCountResult);
$newApplicationCount = $newApplicationCountRow['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
        }

        header {
            background-color: #1E90FF;
            color: white;
            padding: 1em;
            text-align: center;
        }

        nav {
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            background-color: #333;
            padding-top: 20px;
        }

        nav a {
            padding: 10px 15px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
            position: relative;
        }

        nav a:hover {
            background-color: #575757;
        }

        main {
            margin-left: 250px;
            padding: 1em;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1em;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-left: 250px;
        }

        .profile {
            display: flex;
            align-items: center;
            padding: 0 15px;
            margin-bottom: 20px;
        }

        .profile img {
            border-radius: 50%;
            margin-right: 10px;
        }

        .profile span {
            font-size: 18px;
            color: white;
        }

        .notification {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: red;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
    </header>
    <nav>
        <div class="profile">
            <img src="../images/person-male.png" alt="Profile Icon" class="h-12">
            <span><?php echo $username; ?></span>
        </div>
        <a href="#dashboard">Dashboard</a>
        <a href="#members">Members</a>
        <a href="view_instructors.php">Instructors</a>
        <a href="#trial_period_users">Trial Period Users</a>
        <a href="#memberships">Memberships</a>
        <a href="#lockers">Lockers</a>
        <a href="#equipment">Equipment</a>
        <a href="#notifications">Notifications</a>
        <a href="#feedback">Feedback</a>
        <a href="view_application_forms.php">Application Forms
            <?php if ($newApplicationCount > 0): ?>
            <span class="notification"><?php echo $newApplicationCount; ?></span>
            <?php endif; ?>
        </a>
        <a href="#gallery">Gallery</a>
        <a href="logout.php">Logout</a>
    </nav>
    <main>
        <section id="dashboard">
            <h2>Dashboard</h2>
            <p>Overview of activities...</p>
        </section>
        <section id="members">
            <h2>Members</h2>
            <p>List of members...</p>
        </section>
        <section id="instructors">
            <h2>Instructors</h2>
            <p>List of instructors...</p>
        </section>
        <section id="trial_period_users">
            <h2>Trial Period Users</h2>
            <p>List of trial period users...</p>
        </section>
        <section id="memberships">
            <h2>Memberships</h2>
            <p>Types of memberships...</p>
        </section>
        <section id="lockers">
            <h2>Lockers</h2>
            <p>Locker assignments...</p>
        </section>
        <section id="equipment">
            <h2>Equipment</h2>
            <p>List of equipment...</p>
        </section>
        <section id="notifications">
            <h2>Notifications</h2>
            <p>Recent notifications...</p>
        </section>
        <section id="feedback">
            <h2>Feedback</h2>
            <p>User feedback...</p>
        </section>
        <section id="application_forms">
            <h2>Application Forms</h2>
            <p>List of application forms...</p>
        </section>
        <section id="gallery">
            <h2>Gallery</h2>
            <p>Images and videos...</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 Admin Dashboard</p>
    </footer>
    <script>
        // Add JavaScript functionality here if needed
    </script>
</body>
</html>
