<?php
session_start();
include('../connection/connection.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_id'])) {
    $form_id = $_POST['form_id'];
    $query = "UPDATE application_form SET viewed = 1 WHERE form_id = '$form_id'";
    if (mysqli_query($conn, $query)) {
        header('Location: view_application_forms.php');
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
} else {
    header('Location: view_application_forms.php');
    exit();
}
