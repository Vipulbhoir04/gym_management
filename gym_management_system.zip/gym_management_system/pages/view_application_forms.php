<?php
session_start();
include('../connection/connection.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch application forms from the database
$query = "SELECT * FROM application_form";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Application Forms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #1E90FF;
            color: white;
            padding: 1em;
            text-align: center;
        }

        main {
            padding: 2em;
            flex: 1;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2em;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 1em;
            text-align: left;
        }

        th {
            background-color: #1E90FF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .viewed {
            background-color: #d3ffd3;
        }

        .button-viewed {
            background-color: #ff9800;
            color: white;
            padding: 0.5em 1em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .button-viewed:hover {
            background-color: #e68900;
        }

        .back-button {
            background-color: #1E90FF;
            color: white;
            padding: 0.75em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            width: 200px;
            position: fixed;
            bottom: 20px;
            right: 20px;
        }

        .back-button:hover {
            background-color: #1c86ee;
        }
    </style>
</head>
<body>
    <header>
        <h1>View Application Forms</h1>
    </header>
    <main>
        <h2>Submitted Forms</h2>
        <table>
            <thead>
                <tr>
                    <th>Form ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Description</th>
                    <th>Role</th>
                    <th>User ID</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr class="<?php echo $row['viewed'] ? 'viewed' : ''; ?>">
                    <td><?php echo $row['form_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['description']; ?></td>
                    <td><?php echo $row['role']; ?></td>
                    <td><?php echo $row['user_id']; ?></td>
                    <td>
                        <form action="mark_as_viewed.php" method="post">
                            <input type="hidden" name="form_id" value="<?php echo $row['form_id']; ?>">
                            <button class="button-viewed" type="submit">Mark as Viewed</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
    <a href="admin_dashboard.php" class="back-button">Back to Home</a>
</body>
</html>
