<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructor Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
        }
        
        header {
            background-color: #1E90FF;
            color: white;
            padding: 1em;
            text-align: center;
        }
        
        nav {
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            background-color: #333;
            padding-top: 20px;
        }
        
        nav a {
            padding: 10px 15px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
        }
        
        nav a:hover {
            background-color: #575757;
        }
        
        main {
            margin-left: 250px;
            padding: 1em;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1em;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-left: 250px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Instructor Dashboard</h1>
    </header>
    <nav>
        <a href="#overview">Overview</a>
        <a href="#students">Students</a>
        <a href="#courses">Courses</a>
        <a href="#settings">Settings</a>
    </nav>
    <main>
        <section id="overview">
            <h2>Overview</h2>
            <p>Summary of activities...</p>
        </section>
        <section id="students">
            <h2>Students</h2>
            <p>List of students...</p>
        </section>
        <section id="courses">
            <h2>Courses</h2>
            <p>List of courses...</p>
        </section>
        <section id="settings">
            <h2>Settings</h2>
            <p>Account settings...</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 Instructor Dashboard</p>
    </footer>
    <script>
        // Add JavaScript functionality here if needed
    </script>
</body>
</html>
