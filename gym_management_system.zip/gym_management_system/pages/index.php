<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background: linear-gradient(to bottom, #1a1a1a, #333333); /* Dark gradient background */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .vertical-line {
            border-left: 2px solid #FFD700; /* Golden color */
            padding-left: 10px;
        }

        .highlighted-text {
            color: #FFD700; /* Golden color for text */
        }

        .content-container {
            margin-top: 0; /* Removes space between navbar and main content */
            padding-top: 0; /* Removes padding between navbar and main content */
        }

        .navbar {
            border-bottom: 2px solid #FFD700; /* Golden bottom border */
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); /* Modern shadow effect */
        }

        .nav-item a {
            font-weight: bold;
            font-size: 1.25rem;
            transition: color 0.3s;
        }

        .nav-item a:hover {
            color: #FFD700; /* Golden color on hover */
        }

        .logo img {
            height: 3rem; /* Increase the logo size */
        }

        .profile-icon img {
            height: 3rem; /* Increase the profile icon size */
            transition: transform 0.3s;
        }

        .profile-icon img:hover {
            transform: scale(1.1); /* Slight zoom effect on hover */
        }

        .mobile-nav-button {
            display: block;
            cursor: pointer;
        }

        .mobile-nav-item {
            margin: 1rem 0;
        }

        .mobile-nav-item a {
            font-size: 1.25rem;
            font-weight: bold;
        }

        .message {
            display: none; /* Hide by default */
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: #FFD700; /* Golden background */
            color: black;
            padding: 10px;
            border-radius: 5px;
            z-index: 1000; /* Ensure the message is above other elements */
        }

        #sidebar {
            transform: translateX(-100%);
            transition: transform 0.3s ease-in-out;
        }

        #sidebar.open {
            transform: translateX(0);
        }
    </style>
</head>

<body class="bg-gray-900 text-white">

<?php
session_start();
include('../connection/connection.php');

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$username = $isLoggedIn ? $_SESSION['username'] : '';
?>

<header class="navbar flex items-center justify-between p-4 bg-gray-800 text-white">
    <div class="mobile-nav-button" onclick="toggleSidebar()">
        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
        </svg>
    </div>
    <div class="flex-1 text-center">
        <span class="text-2xl font-bold">THE FITNESS FACTORY</span>
    </div>
    <button class="bg-yellow-500 text-black font-bold py-2 px-4 rounded" onclick="window.location.href='login.php'">Login</button>
</header>

<div id="sidebar" class="fixed top-0 left-0 h-full w-64 bg-gray-800 text-white hidden">
    <nav class="flex flex-col items-start space-y-4 p-4">
        <div class="flex items-center space-x-4 mb-4">
            <img src="../images/person-male.png" alt="Profile Icon" class="h-12 rounded-full">
        </div>
        <div class="mobile-nav-item"><a href="#" class="nav-link" onclick="alert('Please log in to access this page.');">Profile</a></div>
        <div class="mobile-nav-item"><a href="#" class="nav-link" onclick="alert('Please log in to access this page.');">Memberships</a></div>
        <div class="mobile-nav-item"><a href="#" class="nav-link" onclick="alert('Please log in to access this page.');">Instructors</a></div>
        <div class="mobile-nav-item"><a href="gallery.html">Gallery</a></div>
        <div class="mobile-nav-item"><a href="equipments.html">Equipments</a></div>
    </nav>
</div>

<main class="flex flex-col justify-center items-center bg-black bg-opacity-75 p-4 min-h-screen content-container">
    <div id="message-box" class="message"></div>
    <div class="text-center px-4 md:px-0">
        <h1 class="text-5xl md:text-8xl font-bold leading-tight">HEALTHY <span class="highlighted-text">LIFESTYLE</span></h1>
        <p class="mt-4 text-xl md:text-4xl">WITH OUR SPECIAL TRAINING</p>
        <p class="mt-2 text-base md:text-lg text-gray-400 vertical-line">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    </div>
    <div class="w-full text-center mt-8">
        <h2 class="text-3xl md:text-4xl font-bold"><span class="highlighted-text">MEMBERSHIPS</span></h2>
    </div>
    <br>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-1 mt-4 w-full px-4 md:px-0">
        <div class="bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col justify-center items-center w-60 h-80 mx-auto">
            <span class="font-bold text-xl">Regular</span>
            <a href="#regular" class="mt-auto mb-4">
                <i class="fas fa-arrow-right text-yellow-500 text-2xl"></i>
            </a>
        </div>
        <div class="bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col justify-center items-center w-60 h-80 mx-auto">
            <span class="font-bold text-xl">Seasonal</span>
            <a href="#seasonal" class="mt-auto mb-4">
                <i class="fas fa-arrow-right text-yellow-500 text-2xl"></i>
            </a>
        </div>
        <div class="bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col justify-center items-center w-60 h-80 mx-auto">
            <span class="font-bold text-xl">Other</span>
            <a href="#other" class="mt-auto mb-4">
                <i class="fas fa-arrow-right text-yellow-500 text-2xl"></i>
            </a>
        </div>
    </div>
</main>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function toggleSidebar() {
        $('#sidebar').toggleClass('hidden open');
    }

    function showMessage(message) {
        const messageBox = $('#message-box');
        messageBox.text(message).fadeIn();

        setTimeout(() => {
            messageBox.fadeOut();
        }, 4000);
    }

    $(document).ready(function() {
        // Close sidebar when clicking outside of it
        $(document).click(function(event) {
            if (!$(event.target).closest('.mobile-nav-button, #sidebar').length) {
                $('#sidebar').removeClass('open').addClass('hidden');
            }
        });

        $(window).resize(function() {
            if ($(window).width() > 768) {
                $('#sidebar').removeClass('open').addClass('hidden');
            }
        });
    });
</script>

</body>

</html>
