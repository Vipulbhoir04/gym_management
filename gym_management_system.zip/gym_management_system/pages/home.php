<?php
session_start();
include('../connection/connection.php');

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$username = $isLoggedIn ? $_SESSION['username'] : '';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background: linear-gradient(to bottom, #1a1a1a, #333333); /* Dark gradient background */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .vertical-line {
            border-left: 2px solid #FFD700; /* Golden color */
            padding-left: 10px;
        }

        .highlighted-text {
            color: #FFD700; /* Golden color for text */
        }

        .content-container {
            margin-top: 0; /* Removes space between navbar and main content */
            padding-top: 0; /* Removes padding between navbar and main content */
        }

        .navbar {
            border-bottom: 2px solid #FFD700; /* Golden bottom border */
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); /* Modern shadow effect */
        }

        .nav-item a {
            font-weight: bold;
            font-size: 1.25rem;
            transition: color 0.3s;
        }

        .nav-item a:hover {
            color: #FFD700; /* Golden color on hover */
        }

        .logo img {
            height: 3rem; /* Increase the logo size */
        }

        .profile-icon img {
            height: 3rem; /* Increase the profile icon size */
            transition: transform 0.3s;
        }

        .profile-icon img:hover {
            transform: scale(1.1); /* Slight zoom effect on hover */
        }

        .mobile-nav-button {
            display: block;
            cursor: pointer;
        }

        .mobile-nav-item {
            margin: 1rem 0;
        }

        .mobile-nav-item a {
            font-size: 1.25rem;
            font-weight: bold;
            transition: color 0.3s;
        }

        .mobile-nav-item a:hover {
            color: #FFD700; /* Golden color on hover */
        }

        .dropdown {
            display: none;
            flex-direction: column;
            padding-left: 1rem;
        }

        .dropdown-toggle::after {
            content: "\25BC";
            margin-left: 5px;
        }

        .dropdown a {
            display: block;
            font-size: 1.25rem;
            font-weight: bold;
            padding-left: 1rem;
        }

        .dropdown a:hover {
            color: #FFD700;
        }

        .mobile-nav-item:hover .dropdown {
            display: flex;
        }
    </style>
</head>

<body class="bg-gray-900 text-white">

<header class="navbar flex items-center justify-between p-4 bg-gray-800 text-white">
    <div class="mobile-nav-button" onclick="toggleSidebar()">
        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
        </svg>
    </div>
    <div class="flex-1 text-center">
        <span class="text-2xl font-bold">THE FITNESS FACTORY</span>
    </div>
</header>

<div id="sidebar" class="fixed top-0 left-0 h-full w-64 bg-gray-800 text-white hidden">
    <nav class="flex flex-col items-start space-y-4 p-4">
        <div class="flex items-center space-x-4 mb-4">
            <img src="../images/person-male.png" alt="Profile Icon" class="h-12 rounded-full"> <!-- Added profile icon at the top -->
            <?php if ($isLoggedIn): ?>
            <span class="font-bold"><?php echo $username; ?></span>
            <?php endif; ?>
        </div>
        <div class="mobile-nav-item"><a href="profile.php" class="nav-link">Profile</a></div>
        <div class="mobile-nav-item">
            <a href="javascript:void(0);" class="nav-link dropdown-toggle">Memberships</a>
            <div class="dropdown">
                <a href="regular.php">Regular</a>
                <a href="seasonal.php">Seasonal</a>
                <a href="other.php">Other</a>
            </div>
        </div>
        <div class="mobile-nav-item"><a href="instructors.php" class="nav-link">Instructors</a></div>
        <div class="mobile-nav-item"><a href="gallery.php" class="nav-link">Gallery</a></div>
        <div class="mobile-nav-item"><a href="equipments.php" class="nav-link">Equipments</a></div>
        <div class="mobile-nav-item"><a href="application_form.php" class="nav-link">Application Form</a></div>
        <?php if ($isLoggedIn): ?>
        <div class="mobile-nav-item"><a href="logout.php" class="nav-link">Logout</a></div>
        <?php endif; ?>
    </nav>
</div>

<main class="flex flex-col justify-center items-center bg-black bg-opacity-75 p-4 min-h-screen content-container">
    <div id="message-box" class="message"></div>
    <div class="text-center px-4 md:px-0">
        <h1 class="text-5xl md:text-8xl font-bold leading-tight">HEALTHY <span class="highlighted-text">LIFESTYLE</span></h1>
        <p class="mt-4 text-xl md:text-4xl">WITH OUR SPECIAL TRAINING</p>
        <p class="mt-2 text-base md:text-lg text-gray-400 vertical-line">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    </div>
    <div class="w-full text-center mt-8">
        <h2 class="text-3xl md:text-4xl font-bold"><span class="highlighted-text">MEMBERSHIPS</span></h2>
    </div>
    <br>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-1 mt-4 w-full px-4 md:px-0">
        <div class="bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col justify-center items-center w-60 h-80 mx-auto">
            <span class="font-bold text-xl">Regular</span>
            <a href="#regular" class="mt-auto mb-4">
                <i class="fas fa-arrow-right text-yellow-500 text-2xl"></i>
            </a>
        </div>
        <div class="bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col justify-center items-center w-60 h-80 mx-auto">
            <span class="font-bold text-xl">Seasonal</span>
            <a href="#seasonal" class="mt-auto mb-4">
                <i class="fas fa-arrow-right text-yellow-500 text-2xl"></i>
            </a>
        </div>
        <div class="bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col justify-center items-center w-60 h-80 mx-auto">
            <span class="font-bold text-xl">Other</span>
            <a href="#other" class="mt-auto mb-4">
                <i class="fas fa-arrow-right text-yellow-500 text-2xl"></i>
            </a>
        </div>
    </div>
</main>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function toggleSidebar() {
        $('#sidebar').toggleClass('hidden open');
    }

    function showMessage(message) {
        const messageBox = $('#message-box');
        messageBox.text(message).fadeIn();

        setTimeout(() => {
            messageBox.fadeOut();
        }, 4000);
    }

    $(document).ready(function() {
        // Close sidebar when clicking outside of it
        $(document).click(function(event) {
            if (!$(event.target).closest('.mobile-nav-button, #sidebar').length) {
                $('#sidebar').removeClass('open').addClass('hidden');
            }
        });

        $(window).resize(function() {
            if ($(window).width() > 768) {
                $('#sidebar').removeClass('open').addClass('hidden');
            }
        });

        // Display message within the page
        <?php if (!$isLoggedIn): ?>
        $('a[href="profile.php"], a[href="memberships.php"], a[href="instructors.php"]').click(function(event) {
            event.preventDefault();
            alert('Please log in to access this page.');
        });
        <?php endif; ?>
    });
</script>

</body>

</html>
