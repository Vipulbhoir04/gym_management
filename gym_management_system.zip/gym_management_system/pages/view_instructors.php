<?php
session_start();
include('../connection/connection.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch instructors from the database
$query = "SELECT * FROM instructor";
$result = mysqli_query($conn, $query);

// Check if the query was successful
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Instructors</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #1E90FF;
            color: white;
            padding: 1em;
            text-align: center;
        }

        main {
            padding: 2em;
            flex: 1;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2em;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 1em;
            text-align: left;
        }

        th {
            background-color: #1E90FF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .back-button, .add-button {
            background-color: #1E90FF;
            color: white;
            padding: 0.75em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            width: 200px;
            position: fixed;
            bottom: 20px;
        }

        .back-button {
            right: 20px;
        }

        .add-button {
            right: 230px; /* Adjust position next to the back button */
        }

        .back-button:hover, .add-button:hover {
            background-color: #1c86ee;
        }
    </style>
</head>
<body>
    <header>
        <h1>View Instructors</h1>
    </header>
    <main>
        <h2>Gym Instructors</h2>
        <table>
            <thead>
                <tr>
                    <th>Instructor ID</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Specialist</th>
                    <th>Availability</th>
                    <th>User ID</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['ins_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['contact']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['specialist']; ?></td>
                    <td><?php echo $row['availability']; ?></td>
                    <td><?php echo $row['user_id']; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
    <a href="admin_dashboard.php" class="back-button">Back to Home</a>
    <a href="add_instructor.php" class="add-button">Add Instructor</a>
</body>
</html>
