<?php
session_start();
include('../connection/connection.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usrname = $_POST['usrname'];
    $passwordd = $_POST['passwordd'];

    // Query the database to check credentials
    $sql = "SELECT * FROM users WHERE username='$usrname' AND psswd='$passwordd'";
    $result = $conn->query($sql);

    if (!$result) {
        die("Error executing query: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        // Login successful
        $user_id = $result->fetch_assoc()['user_id'];
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $usrname;

        // Initialize the role as empty
        $role = "";

        // Check user role
        $check_member = $conn->query("SELECT * FROM member WHERE user_id='$user_id'");
        $check_instructor = $conn->query("SELECT * FROM instructor WHERE user_id='$user_id'");
        $check_admin_staff = $conn->query("SELECT * FROM admin_staff WHERE user_id='$user_id'");

        if ($check_member->num_rows > 0) {
            $role = "member";
        } elseif ($check_instructor->num_rows > 0) {
            $role = "instructor";
        } elseif ($check_admin_staff->num_rows > 0) {
            $admin_staff_role = $check_admin_staff->fetch_assoc()['role'];
            if ($admin_staff_role == 'Admin') {
                $role = "admin";
            } else {
                $role = "staff";
            }
        }

        // Redirect based on role
        if ($role == "member") {
            $redirect_url = "member_dashboard.php";
        } elseif ($role == "instructor") {
            $redirect_url = "instructor_dashboard.php";
        } elseif ($role == "admin") {
            $redirect_url = "admin_dashboard.php";
        } else {
            $redirect_url = "home.php";
        }

        $success_message = "Login successful! Redirecting...";
        echo '<script type="text/javascript">
            setTimeout(function() {
                window.location.href = "' . $redirect_url . '";
            }, 2000);
        </script>';
    } else {
        // Login failed
        $error_message = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to bottom, #1a1a1a, #333333);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .floating-placeholder {
            position: relative;
        }

        .floating-placeholder input {
            border: 1px solid #FFD700;
            padding: 1rem 0.5rem 0.5rem 0.5rem;
            border-radius: 0.25rem;
            background: transparent;
            color: white;
            width: 100%;
        }

        .floating-placeholder label {
            position: absolute;
            top: 1rem;
            left: 0.5rem;
            color: #FFD700;
            padding: 0 0.25rem;
            transition: all 0.2s ease;
            pointer-events: none;
        }

        .floating-placeholder input:focus+label,
        .floating-placeholder input:not(:placeholder-shown)+label {
            top: -0.75rem;
            left: 0.5rem;
            font-size: 1rem;
            color: #FFD700;
            background: #1a1a1a;
        }

        .password-container {
            position: relative;
        }

        .password-container .toggle-password {
            position: absolute;
            top: 50%;
            right: 0.5rem;
            transform: translateY(-50%);
            cursor: pointer;
            color: #FFD700;
        }

        .message {
            display: none;
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: #FFD700;
            color: black;
            padding: 10px;
            border-radius: 5px;
            z-index: 1000;
        }
    </style>
</head>

<body class="bg-gray-900 text-white flex justify-center items-center min-h-screen">
    <div class="w-full max-w-md bg-gray-800 p-8 rounded-lg shadow-lg">
        <h1 class="text-3xl font-bold mb-6 text-white text-center">Sign In</h1>
        <form method="POST" action="">
            <!--username block-->
            <div class="mb-4 floating-placeholder">
                <input type="text" name="usrname" id="usrname" placeholder=" "
                    class="w-full px-4 py-2 border border-yellow-500 rounded-lg bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-yellow-500">
                <label for="usrname">Username</label>
            </div>
            <!--password block-->
            <div class="mb-6 floating-placeholder password-container">
                <input type="password" name="passwordd" id="passwordd" placeholder=" "
                    class="w-full px-4 py-2 border border-yellow-500 rounded-lg bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-yellow-500">
                <label for="passwordd">Password</label>

                <span class="toggle-password" onclick="togglePassword()">👁️</span>
            </div>
            <button type="submit"
                class="w-full bg-yellow-500 text-black py-2 rounded-lg hover:bg-yellow-600 transition duration-300">Login</button>
            <div class="flex justify-between items-center mt-4 text-gray-400">
                <a href="forget_password.php" class="hover:underline">Forgot Password?</a>
                <a href="register.php" class="text-white hover:underline">Sign Up</a>
            </div>
        </form>
        <?php
        if (isset($success_message)) {
            echo '<p class="text-green-500 text-center mt-4">' . $success_message . '</p>';
        }
        if (isset($error_message)) {
            echo '<p class="text-red-500 text-center mt-4">' . $error_message . '</p>';
        }
        ?>
    </div>
    <script>
        function togglePassword() {
            const passwordField = document.getElementById('passwordd');
            const passwordToggle = document.querySelector('.toggle-password');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordToggle.textContent = '🙈';
            } else {
                passwordField.type = 'password';
                passwordToggle.textContent = '👁️';
            }
        }
    </script>
</body>

</html>
