<?php
session_start();
include('../connection/connection.php');

// Function to generate a unique ins_id
function generateInstructorId($conn) {
    $query = "SELECT MAX(ins_id) AS max_id FROM instructor";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $maxId = $row['max_id'];

    if ($maxId) {
        $number = (int)substr($maxId, 1) + 1;
    } else {
        $number = 1;
    }

    return 'I' . str_pad($number, 4, '0', STR_PAD_LEFT);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ins_id = generateInstructorId($conn);
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $specialist = $_POST['specialist'];
    $availability = implode(',', $_POST['availability']);
    $user_id = $_POST['user_id'];

    $query = "INSERT INTO instructor (ins_id, name, contact, email, specialist, availability, user_id) VALUES ('$ins_id', '$name', '$contact', '$email', '$specialist', '$availability', '$user_id')";
    if (mysqli_query($conn, $query)) {
        echo "Instructor added successfully.";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Instructor</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            padding: 2em;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            max-width: 600px;
            width: 100%;
            text-align: center;
        }

        .form-container h2 {
            margin-bottom: 1em;
            font-size: 24px;
            color: #1E90FF;
        }

        .form-container label {
            display: block;
            margin-bottom: 0.5em;
            text-align: left;
        }

        .form-container input, .form-container select {
            width: 100%;
            padding: 0.5em;
            margin-bottom: 1em;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .multi-select-dropdown {
            position: relative;
            display: inline-block;
            width: 100%;
        }

        .multi-select-label {
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 0.5em;
            width: 100%;
            cursor: pointer;
            text-align: left;
        }

        .multi-select-options {
            display: none;
            position: absolute;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            max-height: 150px;
            overflow-y: auto;
            z-index: 1;
        }

        .multi-select-options label {
            display: flex;
            align-items: center;
            padding: 0.5em;
        }

        .multi-select-options input {
            margin-right: 10px;
            margin-left: 0;
        }

        .form-container button {
            background-color: #1E90FF;
            color: white;
            padding: 0.75em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        .form-container button:hover {
            background-color: #1c86ee;
        }

        .back-button {
            background-color: #1E90FF;
            color: white;
            padding: 0.75em;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            width: 200px;
            position: fixed;
            bottom: 20px;
            right: 20px;
        }

        .back-button:hover {
            background-color: #1c86ee;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Add New Instructor</h2>
        <form action="add_instructor.php" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="contact">Contact:</label>
            <input type="text" id="contact" name="contact" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="specialist">Specialist:</label>
            <input type="text" id="specialist" name="specialist" required>
            
            <label for="availability">Availability:</label>
            <div class="multi-select-dropdown">
                <div class="multi-select-label" onclick="toggleDropdown()">Select Availability</div>
                <div class="multi-select-options">
                    <label><input type="checkbox" name="availability[]" value="Sunday"> Sunday</label>
                    <label><input type="checkbox" name="availability[]" value="Monday"> Monday</label>
                    <label><input type="checkbox" name="availability[]" value="Tuesday"> Tuesday</label>
                    <label><input type="checkbox" name="availability[]" value="Wednesday"> Wednesday</label>
                    <label><input type="checkbox" name="availability[]" value="Thursday"> Thursday</label>
                    <label><input type="checkbox" name="availability[]" value="Friday"> Friday</label>
                    <label><input type="checkbox" name="availability[]" value="Saturday"> Saturday</label>
                </div>
            </div>
            
            <label for="user_id">User ID:</label>
            <input type="text" id="user_id" name="user_id" required>
            
            <button type="submit">Add Instructor</button>
        </form>
    </div>
    <a href="admin_dashboard.php" class="back-button">Back to Home</a>

    <script>
        function toggleDropdown() {
            var dropdown = document.querySelector('.multi-select-options');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        document.addEventListener('click', function(event) {
            var dropdown = document.querySelector('.multi-select-options');
            var label = document.querySelector('.multi-select-label');
            if (!label.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
                updateSelectedOptions();
            }
        });

        document.querySelector('.multi-select-options').addEventListener('click', function(event) {
            event.stopPropagation();
        });

        function updateSelectedOptions() {
            var checkboxes = document.querySelectorAll('.multi-select-options input[type="checkbox"]');
            var selectedOptions = [];
            checkboxes.forEach(function(checkbox) {
                if (checkbox.checked) {
                    selectedOptions.push(checkbox.value);
                }
            });
            document.querySelector('.multi-select-label').textContent = selectedOptions.length > 0 ? selectedOptions.join(', ') : 'Select Availability';
        }
    </script>
</body>
</html>
